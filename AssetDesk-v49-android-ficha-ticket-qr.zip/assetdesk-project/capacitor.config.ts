import type { CapacitorConfig } from '@capacitor/cli';

const serverUrl = process.env.CAPACITOR_SERVER_URL?.trim();
const isHttp = serverUrl?.startsWith('http://') ?? false;

const config: CapacitorConfig = {
  appId: 'com.dubancamilo.assetdesk.field',
  appName: 'AssetDesk Field',
  webDir: 'out',
  server: {
    ...(serverUrl ? { url: serverUrl, cleartext: isHttp } : {}),
    androidScheme: isHttp ? 'http' : 'https',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: '#0a0f1e',
      showSpinner: false,
    },
  },
};

export default config;
