-- AssetDesk authentication, profiles and roles.
-- Apply this migration once in Supabase SQL Editor.
create table if not exists public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  whatsapp text not null,
  role text not null default 'pending' check (role in ('admin', 'technician', 'pending')),
  company_name text not null default '',
  company_logo_url text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists user_profiles_role_idx on public.user_profiles(role);
alter table public.user_profiles enable row level security;

create or replace function public.is_assetdesk_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.handle_new_assetdesk_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.user_profiles (id, full_name, whatsapp, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'whatsapp', ''),
    case when not exists (select 1 from public.user_profiles) then 'admin' else 'pending' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_assetdesk on auth.users;
create trigger on_auth_user_created_assetdesk
after insert on auth.users
for each row execute procedure public.handle_new_assetdesk_user();

-- Users can read and update only their own profile.
drop policy if exists "Users read own AssetDesk profile" on public.user_profiles;
create policy "Users read own AssetDesk profile"
on public.user_profiles for select
using (id = auth.uid() or public.is_assetdesk_admin());

drop policy if exists "Users update own AssetDesk profile" on public.user_profiles;
create policy "Users update own AssetDesk profile"
on public.user_profiles for update
using (id = auth.uid() or public.is_assetdesk_admin())
with check (id = auth.uid() or public.is_assetdesk_admin());

-- Administrators manage roles and company data.
drop policy if exists "Administrators manage AssetDesk profiles" on public.user_profiles;
create policy "Administrators manage AssetDesk profiles"
on public.user_profiles for all
using (public.is_assetdesk_admin())
with check (public.is_assetdesk_admin());

-- Keep the timestamp current on profile edits.
create or replace function public.touch_assetdesk_profile()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists touch_assetdesk_profile on public.user_profiles;
create trigger touch_assetdesk_profile
before update on public.user_profiles
for each row execute procedure public.touch_assetdesk_profile();
