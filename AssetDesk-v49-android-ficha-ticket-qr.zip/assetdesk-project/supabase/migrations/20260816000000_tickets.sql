-- AssetDesk: persistent service tickets used by the public ticket view.
CREATE TABLE IF NOT EXISTS public.tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id TEXT NOT NULL UNIQUE,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  asset_tag TEXT,
  asset_name TEXT,
  category TEXT NOT NULL DEFAULT 'hardware',
  priority TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'open',
  location TEXT,
  assignee TEXT,
  created TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sla_due TIMESTAMPTZ,
  sla_hours_left NUMERIC,
  description TEXT NOT NULL DEFAULT '',
  has_fault_photo BOOLEAN NOT NULL DEFAULT FALSE,
  fault_photo_url TEXT,
  resolution_type TEXT,
  resolution_notes TEXT,
  notes JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_tickets_asset_id ON public.tickets(asset_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON public.tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_priority ON public.tickets(priority);
CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON public.tickets(created_at DESC);
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tickets_all_access ON public.tickets;
CREATE POLICY tickets_all_access ON public.tickets FOR ALL USING (true) WITH CHECK (true);
DROP TRIGGER IF EXISTS tickets_updated_at ON public.tickets;
CREATE TRIGGER tickets_updated_at BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
NOTIFY pgrst, 'reload schema';
