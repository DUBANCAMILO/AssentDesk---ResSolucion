# AssetDesk — estado real y plan de cierre

Fecha: 2026-08-16

## Regla de estado

- **Verificado:** el usuario ejecutó la prueba y reportó resultado.
- **Preparado:** existe código, pero falta probarlo en el entorno real.
- **Falla:** el usuario reportó que no funciona.
- **Pendiente:** no se ha implementado o no se ha iniciado.

## Matriz de situación

| Área | Estado real | Qué se modificó | Qué falta para cerrarla |
|---|---|---|---|
| Build web v16 | Verificado | TypeScript y build pasaron | Repetir tras la última rama estable |
| Build v28/v29 | Preparado, no confirmado | Suspense para `useSearchParams`, QR y PDF | Ejecutar type-check/build del paquete actual |
| QR en el mismo entorno | Parcialmente verificado | URL de ficha, búsqueda rápida, parada inmediata del loop | Probar etiqueta nueva y descarga real |
| QR desde otro dispositivo | Falla/no cerrado | QR con parámetro PDF y host configurado | Usar el origen/IP existente del usuario y probar con celular |
| PDF de ficha | Funciona en algunas pruebas | `jsPDF`, botón de exportación y auto-descarga por QR | Confirmar descarga al escanear en celular |
| Velocidad QR | Preparado | Cámara 640×480, menor intervalo, sin llamadas duplicadas | Medir en celular real |
| Formulario de equipos | Demasiado largo | Secciones existentes, foto y campos técnicos | Crear formulario básico corto + modo avanzado |
| Excel | Preparado, sin validación visual final | Hoja Ficha técnica, Resumen, filtro, congelar encabezado, columnas | Abrir en Excel y validar colores/formato |
| IP | Verificado en prueba del usuario | Consulta directa, aviso ocupado y sincronización | Probar impresoras/cámaras y conflictos simultáneos |
| WiFi | Implementado | SSID, contraseña visible/oculta, QR de red | Validar campos reales y permisos |
| Bajas | Descarga reportada como funcional | Informe y PDF directo | Validar documento institucional completo |
| Mantenimientos | Descarga reportada como funcional | Informe PDF e historial programado | Agregar checklist técnico por equipo escaneado |
| Traslados | Falla reportada | Manejo de error, PDF directo y listado inferior | Aplicar migración, crear un registro y verificar listado |
| Etiquetas | Implementado | Óptimo/Buen estado y demás estados | Validar nombre definitivo institucional |
| Escáner flotante | Preparado | Componente global en `AppLayout`, entrada automática a cámara | Confirmar tras build estable |
| Notificaciones | Preparado | Contador, realtime, marcado leído | Prueba contra Realtime real |
| Auth/roles | Pendiente | `AuthContext` tipado | Proteger rutas y cerrar RLS |
| Android | No iniciado | Dependencias Capacitor y configuración base | Elegir empaquetado hosted/static y generar proyecto |
| APK | No generado | No existe APK confirmado | Android Studio + SDK + `android/` + build |
| iPhone | No iniciado | Dependencia iOS preparada | Mac + Xcode |
| NAS/edge/videojuegos | Fuera de alcance inmediato | No iniciado | Empezar solo después del piloto AssetDesk |

## Cierre P0 — no avanzar a NAS/edge todavía

1. No cambiar la IP existente del usuario.
2. No generar más módulos visuales.
3. Ejecutar type-check y build del paquete vigente.
4. Aplicar migración de traslados en Supabase.
5. Crear un activo de prueba, una IP, un mantenimiento, una baja y un traslado.
6. Generar una etiqueta QR nueva.
7. Escanearla desde el celular.
8. Confirmar ficha visible y PDF descargado.
9. Confirmar listado y descarga del traslado.
10. Abrir Excel en Microsoft Excel y revisar formato.

## Formulario corto objetivo

### Básico obligatorio

- placa;
- marca;
- modelo;
- serial;
- tipo de equipo;
- estado;
- IP;
- usuario responsable;
- área;
- ubicación;
- foto.

### Avanzado opcional

- CPU;
- RAM;
- disco;
- sistema operativo;
- garantía;
- MAC;
- red;
- periféricos;
- observaciones;
- datos de compra.

## QR para auditoría

El resultado objetivo es:

1. escanear;
2. abrir la ficha del activo;
3. iniciar el PDF completo;
4. dejar visible la ficha en pantalla;
5. permitir descargar nuevamente el PDF.

Un QR no puede hacer accesible un servidor que el dispositivo no puede alcanzar. La IP/origen existente debe mantenerse y ser accesible desde el celular. No se debe reemplazar por una dirección improvisada.

## Ruta Android después de P0

1. Confirmar Android Studio, SDK, Build Tools, Platform Tools y JDK 17.
2. Confirmar estrategia de Capacitor: origen web hospedado o exportación estática.
3. Ejecutar `npx cap doctor`.
4. Ejecutar `npx cap add android`.
5. Ejecutar `npx cap sync android`.
6. Abrir con `npx cap open android`.
7. Probar cámara, QR, PDF, fotos y Supabase.
8. Generar APK debug.
9. Generar AAB firmado cuando el piloto sea estable.

## Criterio para declarar AssetDesk listo para piloto

- QR funciona desde el celular;
- PDF de ficha se descarga;
- IP avisa ocupación y sincroniza;
- baja y mantenimiento descargan documentos;
- traslado se guarda, aparece en listado y se descarga;
- formulario básico no obliga a diligenciar campos irrelevantes;
- Excel se abre con estructura legible;
- build limpio después de las correcciones;
- se conserva la IP/origen real del usuario;
- se documenta el resultado de cada prueba.
