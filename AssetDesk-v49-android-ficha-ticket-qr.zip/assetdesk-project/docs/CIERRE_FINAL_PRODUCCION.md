# AssetDesk — cierre final de producción

Fecha de corte: 2026-08-16

## Cómo leer esta ficha

- **Verificado:** el usuario lo probó y confirmó el resultado.
- **Corregido, pendiente de repetir:** hay cambio de código, pero falta la prueba final.
- **Bloqueado:** depende de Supabase, permisos, red o hardware.
- **Pendiente:** todavía no se implementa.

## Matriz de pruebas

| ID | Área | Prueba concreta | Resultado actual | Próxima acción | Criterio de aprobación |
|---|---|---|---|---|---|
| WEB-01 | Build | `npm run type-check` | Verificado en una versión anterior; repetir tras v29 | Ejecutar comando | Sin errores |
| WEB-02 | Build | `npm run build` | v28 falló por Suspense; corregido en v28/v29 | Repetir build | Sin `Failed to compile` |
| WEB-03 | Activo fijo | Crear activo básico con campos obligatorios | Parcial | Probar formulario corto | Guarda sin campos técnicos innecesarios |
| WEB-04 | Activo fijo | Guardar todos los campos técnicos | Preparado | Probar modo avanzado | No se pierde ningún campo |
| WEB-05 | Impresora | Crear impresora con sus campos propios | Preparado | Probar módulo impresoras | Guarda y aparece en inventario de impresoras |
| WEB-06 | Foto | Tomar/subir foto | Verificado parcialmente | Probar desde navegador y Android | Foto visible en ficha y PDF |
| WEB-07 | IP | Crear activo con IP libre | Verificado por el usuario | Repetir con dato real | IP queda ocupada y vinculada |
| WEB-08 | IP | Crear activo con IP ocupada | Verificado por el usuario | Probar con otro tipo de dispositivo | Muestra aviso y no roba la IP |
| WEB-09 | IP | Cambiar/liberar IP | Preparado | Probar actualización y baja | Registro y activo quedan sincronizados |
| WEB-10 | QR | Generar QR nuevo | Preparado | Generar etiqueta nueva | QR contiene ficha del activo |
| WEB-11 | QR | Escanear en computador | Parcialmente verificado | Repetir | Abre ficha completa |
| WEB-12 | QR | Escanear desde celular | Falla no cerrado | Usar el origen/IP existente | Ficha abre en menos de unos segundos |
| WEB-13 | QR/PDF | Descargar PDF después del escaneo | Corregido, pendiente de repetir | Escanear QR nuevo | PDF se descarga y la ficha queda visible |
| WEB-14 | Excel | Exportar ficha técnica | Preparado | Abrir en Excel | Dos hojas, encabezados y columnas legibles |
| WEB-15 | Bajas | Crear baja | Reportado funcional | Repetir con activo real | Guarda, actualiza estado y genera PDF |
| WEB-16 | Bajas | Descargar informe de bajas | Reportado funcional | Repetir filtrado | Archivo abre y contiene registros |
| WEB-17 | Mantenimiento | Crear programación | Pendiente de prueba completa | Crear registro | Aparece en listado |
| WEB-18 | Mantenimiento | Marcar equipo revisado | Pendiente | Registrar resultado por equipo | Historial conserva qué se hizo |
| WEB-19 | Mantenimiento | Descargar informe | Reportado funcional, validar contenido | Descargar con registros | Informe no sale vacío |
| WEB-20 | Traslados | Guardar traslado | Falla reportada | Aplicar migración y guardar | Mensaje de éxito visible |
| WEB-21 | Traslados | Listar traslados guardados | Corregido, pendiente de repetir | Actualizar listado | Registro permanece después de recargar |
| WEB-22 | Traslados | Descargar traslado existente | Corregido, pendiente de repetir | Pulsar Descargar | PDF se descarga sin popup |
| WEB-23 | Notificaciones | Crear/recibir notificación | Preparado | Probar Realtime | Campana y lista se actualizan |
| AND-01 | Android | Android Studio y SDK | Android Studio instalado según usuario | Ejecutar `npx cap doctor` | Herramientas detectadas |
| AND-02 | Android | Proyecto nativo | No generado | Definir origen web y ejecutar `npx cap add android` | Carpeta `android` abre en Android Studio |
| AND-03 | Android | Cámara/QR | No probado | Ejecutar en teléfono | Escanea y abre PDF |
| AND-04 | Android | APK | No generado | `gradlew.bat assembleDebug` | APK instalable |
| IOS-01 | iPhone | Simulador | No disponible en Windows | Usar Mac/Xcode | Proyecto compila |

## Registro de cierre

| Fecha | ID | Equipo/navegador | Resultado | Evidencia |
|---|---|---|---|---|
|  |  |  |  |  |

## Bloqueos conocidos

1. La aplicación debe conservar la IP/origen que ya funciona para el usuario.
2. Un celular debe poder alcanzar ese origen para que un QR con URL funcione.
3. La migración de traslados debe estar aplicada en Supabase.
4. La compilación iOS exige macOS y Xcode; no se resuelve con una máquina virtual de iPhone en Windows.
5. Capacitor necesita una estrategia definida: origen web accesible o exportación estática.

## Orden obligatorio antes del APK

1. WEB-01 y WEB-02.
2. WEB-07 a WEB-13.
3. WEB-20 a WEB-22.
4. AND-01 y AND-02.
5. AND-03 y AND-04.

## Decisión de producción

No declarar “listo” si alguna prueba QR, PDF, IP o traslado aparece como falla. Registrar el error concreto y repetir únicamente ese flujo.
