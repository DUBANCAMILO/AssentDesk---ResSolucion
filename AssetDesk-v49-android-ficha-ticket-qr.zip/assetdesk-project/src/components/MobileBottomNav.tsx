'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Bell, ClipboardList, MoreHorizontal, QrCode, Settings, Wrench, X, FileText, Wifi, Users, Archive, Printer, Camera, MessageSquare, Search, Monitor, Layers, BarChart2, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export default function MobileBottomNav() {
  const pathname = usePathname();
  const { profile } = useAuth();
  const [moreOpen, setMoreOpen] = useState(false);
  const [menuQuery, setMenuQuery] = useState('');
  const isTechnician = profile?.role === 'technician';

  const primaryItems = [
    { href: '/tecnico', label: 'Escanear', icon: QrCode },
    { href: '/', label: 'Inventario', icon: ClipboardList },
    { href: '/mantenimientos', label: 'Mantenimiento', icon: Wrench },
    { href: '/notificaciones', label: 'Avisos', icon: Bell },
  ];

  const moreItems = isTechnician
    ? [{ href: '/configuracion', label: 'Configuración', icon: Settings }]
    : [
        { href: '/', label: 'Inventario de activos', icon: Monitor },
        { href: '/impresoras', label: 'Impresoras', icon: Printer },
        { href: '/camaras', label: 'Cámaras y DVR', icon: Camera },
        { href: '/equipos', label: 'Gestión de equipos', icon: Layers },
        { href: '/bajas', label: 'Bajas', icon: Archive },
        { href: '/mantenimientos', label: 'Mantenimientos', icon: Calendar },
        { href: '/analytics', label: 'Panel de análisis', icon: BarChart2 },
        { href: '/reportes', label: 'Reportes PDF', icon: FileText },
        { href: '/ip-management', label: 'Gestión de IPs', icon: Wifi },
        { href: '/usuarios', label: 'Usuarios y roles', icon: Users },
        { href: '/notificaciones', label: 'Avisos', icon: Bell },
        { href: '/ticket-management-console', label: 'Tickets', icon: MessageSquare },
        { href: '/configuracion', label: 'Configuración', icon: Settings },
      ];

  const visibleMoreItems = moreItems.filter((item) => item.label.toLowerCase().includes(menuQuery.trim().toLowerCase()));

  return (
    <>
      {moreOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Más opciones">
          <button type="button" aria-label="Cerrar menú" className="absolute inset-0 bg-black/60" onClick={() => setMoreOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[78vh] overflow-y-auto rounded-t-3xl border-t border-border bg-card px-4 pb-[calc(1rem+env(safe-area-inset-bottom))] pt-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Menú completo</p>
                <h2 className="mt-1 text-lg font-semibold text-foreground">{isTechnician ? 'Herramientas de campo' : 'Administración'}</h2>
              </div>
              <button type="button" aria-label="Cerrar menú" onClick={() => setMoreOpen(false)} className="rounded-xl p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"><X size={20} /></button>
            </div>
            <label className="mb-3 flex items-center gap-2 rounded-2xl border border-border bg-secondary/40 px-3 py-2.5 text-muted-foreground">
              <Search size={17} />
              <input value={menuQuery} onChange={(event) => setMenuQuery(event.target.value)} placeholder="Buscar módulo..." className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground" />
            </label>
            <div className="grid grid-cols-2 gap-2">
              {visibleMoreItems.map(({ href, label, icon: Icon }) => {
                const active = pathname === href || pathname.startsWith(`${href}/`);
                return (
                  <Link key={href} href={href} onClick={() => setMoreOpen(false)} className={`flex min-h-14 items-center gap-3 rounded-2xl border px-3 py-3 text-sm font-medium transition-colors ${active ? 'border-primary/50 bg-primary/15 text-primary' : 'border-border bg-secondary/40 text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
                    <Icon size={19} className="shrink-0" />
                    <span className="leading-tight">{label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <nav aria-label="Navegación móvil" className="fixed inset-x-0 bottom-0 z-40 flex h-[calc(4.25rem+env(safe-area-inset-bottom))] items-start justify-around border-t border-border bg-card/95 px-1 pt-2 pb-[env(safe-area-inset-bottom)] shadow-[0_-8px_24px_rgba(0,0,0,.24)] backdrop-blur md:hidden">
        {primaryItems.map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`);
          return (
            <Link key={href} href={href} aria-current={active ? 'page' : undefined} className={`flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1 text-[10px] font-medium transition-colors ${active ? 'text-primary' : 'text-muted-foreground'}`}>
              <span className={`rounded-xl px-3 py-1 ${active ? 'bg-primary/15' : ''}`}><Icon size={19} strokeWidth={active ? 2.4 : 1.8} /></span>
              <span className="truncate">{label}</span>
            </Link>
          );
        })}
        <button type="button" aria-label="Abrir menú completo" onClick={() => setMoreOpen(true)} className={`flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1 text-[10px] font-medium transition-colors ${moreOpen ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className={`rounded-xl px-3 py-1 ${moreOpen ? 'bg-primary/15' : ''}`}><MoreHorizontal size={19} /></span>
          <span className="truncate">Más</span>
        </button>
      </nav>
    </>
  );
}

