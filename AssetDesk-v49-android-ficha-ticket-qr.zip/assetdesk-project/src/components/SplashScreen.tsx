'use client';

import React, { useEffect, useState } from 'react';
export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // Animate progress bar
    const steps = [10, 30, 55, 75, 90, 100];
    let i = 0;
    const interval = setInterval(() => {
      if (i < steps.length) {
        setProgress(steps[i]);
        i++;
      } else {
        clearInterval(interval);
        // Start fade out after reaching 100%
        setTimeout(() => {
          setFadeOut(true);
          setTimeout(onDone, 500);
        }, 300);
      }
    }, 280);
    return () => clearInterval(interval);
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[200] flex flex-col items-center justify-center bg-background transition-opacity duration-500 ${fadeOut ? 'opacity-0' : 'opacity-100'}`}
    >
      {/* Background subtle gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background pointer-events-none" />

      <div className="relative flex flex-col items-center gap-6 px-8">
        {/* Marca animada: la N vuelve a entrar suavemente mientras carga */}
        <div className="relative splash-logo-motion" aria-label="AssetDesk cargando">
          <div className="splash-n-shell w-24 h-24 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shadow-2xl shadow-primary/20">
            <span className="splash-n" aria-hidden="true">N</span>
          </div>
          <div className="absolute inset-0 rounded-2xl border border-primary/30 animate-ping opacity-30" />
        </div>

        {/* App name */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground tracking-tight">AssetDesk</h1>
          <p className="text-sm text-muted-foreground mt-1">Gestión de Activos TI</p>
        </div>

        {/* Progress bar */}
        <div className="w-56">
          <div className="h-1 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-[10px] text-muted-foreground text-center mt-2">Cargando sistema...</p>
        </div>
      </div>

      {/* Version */}
      <p className="absolute bottom-6 text-[10px] text-muted-foreground">v2.0 · AssetDesk TI</p>
    </div>
  );
}
