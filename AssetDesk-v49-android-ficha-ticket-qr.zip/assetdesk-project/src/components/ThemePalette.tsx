'use client';

import { useEffect, useState } from 'react';
import { Check, Palette } from 'lucide-react';

const themes = [
  { name: 'Azul AssetDesk', primary: '#3b82f6', accent: '#f59e0b' },
  { name: 'Índigo', primary: '#6366f1', accent: '#22d3ee' },
  { name: 'Esmeralda', primary: '#10b981', accent: '#f59e0b' },
  { name: 'Violeta', primary: '#8b5cf6', accent: '#ec4899' },
];

export default function ThemePalette() {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(themes[0].name);

  useEffect(() => {
    const saved = window.localStorage.getItem('assetdesk-theme');
    const theme = themes.find((item) => item.name === saved) || themes[0];
    document.documentElement.style.setProperty('--primary', theme.primary);
    document.documentElement.style.setProperty('--ring', theme.primary);
    document.documentElement.style.setProperty('--accent', theme.accent);
    setSelected(theme.name);
  }, []);

  const applyTheme = (theme: typeof themes[number]) => {
    document.documentElement.style.setProperty('--primary', theme.primary);
    document.documentElement.style.setProperty('--ring', theme.primary);
    document.documentElement.style.setProperty('--accent', theme.accent);
    window.localStorage.setItem('assetdesk-theme', theme.name);
    setSelected(theme.name);
    setOpen(false);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label="Cambiar colores del sistema"
        title="Cambiar colores"
        className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <Palette size={16} />
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-56 rounded-xl border border-border bg-card p-2 shadow-2xl">
          <p className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Color del sistema</p>
          {themes.map((theme) => (
            <button
              type="button"
              key={theme.name}
              onClick={() => applyTheme(theme)}
              className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left text-xs text-foreground transition-colors hover:bg-secondary"
            >
              <span className="flex gap-1"><i className="h-4 w-4 rounded-full" style={{ backgroundColor: theme.primary }} /><i className="h-4 w-4 rounded-full" style={{ backgroundColor: theme.accent }} /></span>
              <span className="flex-1">{theme.name}</span>
              {selected === theme.name && <Check size={14} className="text-primary" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
