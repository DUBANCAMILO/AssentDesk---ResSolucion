'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Sidebar from './Sidebar';
import MobileBottomNav from './MobileBottomNav';
import FloatingScanner from './FloatingScanner';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter, usePathname } from 'next/navigation';

const SplashScreen = dynamic(() => import('./SplashScreen'), { ssr: false });

interface AppLayoutProps {
  children: React.ReactNode;
}

// Track if splash has been shown in this session
let splashShownThisSession = false;

export default function AppLayout({ children }: AppLayoutProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { session, profile, loading: authLoading } = useAuth();
  const [showSplash, setShowSplash] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (authLoading) return;
    if (!session && pathname !== '/login' && pathname !== '/registro') {
      router.replace('/login');
      return;
    }
    if (session && profile?.role === 'technician' && pathname !== '/tecnico') {
      router.replace('/tecnico');
    }
  }, [authLoading, pathname, profile?.role, router, session]);

  useEffect(() => {
    setMounted(true);
    if (!splashShownThisSession) {
      splashShownThisSession = true;
      setShowSplash(true);
    }
  }, []);

  const handleSplashDone = () => {
    setShowSplash(false);
  };

  if (authLoading || !session) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-sm text-muted-foreground">Cargando sesión...</div>;
  }

  if (profile?.role === 'pending') {
    return <div className="min-h-screen bg-background flex items-center justify-center px-4"><div className="max-w-md rounded-2xl border border-border bg-card p-6 text-center"><h1 className="text-lg font-semibold text-foreground">Cuenta pendiente de aprobación</h1><p className="mt-2 text-sm text-muted-foreground">La administradora debe asignarte el rol de Técnico o Administradora antes de ingresar.</p></div></div>;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {mounted && showSplash && <SplashScreen onDone={handleSplashDone} />}
      <Sidebar />
      <main className="min-w-0 w-full flex-1 overflow-y-auto overflow-x-hidden flex flex-col pb-16 pt-[env(safe-area-inset-top)] md:overflow-hidden md:pb-0 md:pt-0">
        {children}
      </main>
      <MobileBottomNav />
      <FloatingScanner />
    </div>
  );
}