'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import { Monitor, ChevronLeft, ChevronRight, ChevronDown, Settings, Bell, User, Users, Wifi, Archive, Wrench, BarChart2, Layers, Printer, Camera, Calendar, FileText, MessageCircle, LogOut } from 'lucide-react';
import { notificationService } from '@/lib/services/assetService';
import { useAuth } from '@/contexts/AuthContext';

const SUPPORT_WHATSAPP = '573172954058';

const navGroups = [
  {
    label: 'Inventario',
    items: [
      { href: '/', icon: Monitor, label: 'Inventario de Activos' },
      { href: '/impresoras', icon: Printer, label: 'Inventario de Impresoras' },
      { href: '/camaras', icon: Camera, label: 'Cámaras y DVR' },
      { href: '/equipos', icon: Layers, label: 'Gestión de Equipos' },
      { href: '/bajas', icon: Archive, label: 'Módulo de Bajas' },
    ],
  },
  {
    label: 'Mantenimiento',
    items: [
      { href: '/mantenimientos', icon: Calendar, label: 'Mantenimientos' },
    ],
  },
  {
    label: 'Análisis',
    items: [
      { href: '/analytics', icon: BarChart2, label: 'Panel de Análisis' },
      { href: '/reportes', icon: FileText, label: 'Reportes PDF' },
    ],
  },
  {
    label: 'Red',
    items: [
      { href: '/ip-management', icon: Wifi, label: 'Gestión de IPs' },
    ],
  },
  {
    label: 'Campo',
    items: [
      { href: '/tecnico', icon: Wrench, label: 'Vista Técnico' },
    ],
  },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({ Inventario: true, Mantenimiento: true });
  const pathname = usePathname();
  const { user, profile, signOut } = useAuth();

  useEffect(() => {
    notificationService?.getUnreadCount()?.then(setUnreadCount);
    const interval = setInterval(() => {
      notificationService?.getUnreadCount()?.then(setUnreadCount);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside
      className="relative hidden md:flex flex-col h-screen bg-card border-r border-border transition-all duration-300 ease-in-out shrink-0"
      style={{ width: collapsed ? '64px' : '240px' }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-border h-16 overflow-hidden">
        <AppLogo size={32} />
        {!collapsed && (
          <div className="overflow-hidden">
            <span className="font-semibold text-base text-foreground whitespace-nowrap tracking-tight block">AssetDesk</span>
            <span className="text-[10px] text-muted-foreground whitespace-nowrap">Gestión de Activos TI</span>
          </div>
        )}
      </div>
      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-[72px] z-10 w-6 h-6 rounded-full bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary transition-colors duration-150"
        aria-label={collapsed ? 'Expandir sidebar' : 'Colapsar sidebar'}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
      {/* Nav groups */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden py-3 scrollbar-thin">
        {navGroups?.map((group) => {
          const groupActive = group.items.some((item) => pathname === item.href);
          const groupOpen = collapsed || openGroups[group.label] || groupActive;
          return (
            <div key={`group-${group.label}`} className="mb-2">
              {!collapsed && (
                <button
                  type="button"
                  onClick={() => setOpenGroups((current) => ({ ...current, [group.label]: !groupOpen }))}
                  className={`flex w-full items-center justify-between px-4 py-2 text-[10px] font-semibold uppercase tracking-widest transition-colors ${groupActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
                  <span>{group.label}</span>
                  <ChevronDown size={12} className={`transition-transform ${groupOpen ? 'rotate-180' : ''}`} />
                </button>
              )}
              {groupOpen && group.items.map((item) => {
                const isActive = pathname === item.href;
                const NavIcon = item.icon;
                return (
                  <Link
                    key={`nav-${item.href}`}
                    href={item.href}
                    title={collapsed ? item.label : undefined}
                    className={`relative mx-2 mb-0.5 flex items-center gap-3 rounded-lg px-3 py-2 transition-all duration-150 group ${isActive ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
                    {isActive && <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-primary" />}
                    <NavIcon size={17} className={`shrink-0 ${isActive ? 'text-primary' : ''}`} />
                    {!collapsed && <span className="whitespace-nowrap text-sm font-medium">{item.label}</span>}
                    {collapsed && <span className="pointer-events-none absolute left-full z-50 ml-2 whitespace-nowrap rounded border border-border bg-secondary px-2 py-1 text-xs text-foreground opacity-0 transition-opacity group-hover:opacity-100">{item.label}</span>}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>
      {/* Bottom actions */}
      <div className="border-t border-border p-3 space-y-1">
        <Link href="/notificaciones"
          title={collapsed ? 'Notificaciones' : undefined}
          className={`relative w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 group ${pathname === '/notificaciones' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
          <Bell size={18} className="shrink-0" />
          {!collapsed && <span className="text-sm font-medium">Notificaciones</span>}
          {unreadCount > 0 && !collapsed && (
            <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-red-500 text-white">{unreadCount}</span>
          )}
          {unreadCount > 0 && collapsed && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          )}
          {collapsed && (
            <span className="absolute left-full ml-2 px-2 py-1 text-xs bg-secondary text-foreground rounded border border-border whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 z-50">
              Notificaciones
            </span>
          )}
        </Link>

        <Link href="/configuracion"
          title={collapsed ? 'Configuración' : undefined}
          className={`relative w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 group ${pathname === '/configuracion' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
          <Settings size={18} className="shrink-0" />
          {!collapsed && <span className="text-sm font-medium">Configuración</span>}
          {collapsed && (
            <span className="absolute left-full ml-2 px-2 py-1 text-xs bg-secondary text-foreground rounded border border-border whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 z-50">
              Configuración
            </span>
          )}
        </Link>

        <Link
          href="/usuarios"
          title={collapsed ? 'Usuarios y roles' : undefined}
          className={`relative w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 group ${pathname === '/usuarios' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
          <Users size={18} className="shrink-0" />
          {!collapsed && <span className="text-sm font-medium">Usuarios y roles</span>}
          {collapsed && <span className="absolute left-full ml-2 px-2 py-1 text-xs bg-secondary text-foreground rounded border border-border whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 z-50">Usuarios y roles</span>}
        </Link>

        <a
          href={`https://wa.me/${SUPPORT_WHATSAPP}?text=${encodeURIComponent('Hola, necesito soporte con AssetDesk.')}`}
          target="_blank"
          rel="noreferrer"
          title="Soporte por WhatsApp"
          className={`relative w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 group text-muted-foreground hover:text-green-400 hover:bg-green-500/10 ${collapsed ? 'justify-center' : ''}`}>
          <span className="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#25D366] text-white shadow-sm shadow-green-500/30">
            <MessageCircle size={15} strokeWidth={2.5} />
            <span className="absolute -bottom-0.5 -right-1 rounded bg-white px-0.5 text-[7px] font-black leading-3 text-[#128C7E]">WA</span>
          </span>
          {!collapsed && <span className="text-sm font-medium">Soporte WhatsApp</span>}
          {collapsed && (
            <span className="absolute left-full ml-2 px-2 py-1 text-xs bg-secondary text-foreground rounded border border-border whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 z-50">
              Soporte WhatsApp
            </span>
          )}
        </a>

        <div className={`flex items-center gap-3 px-3 py-2 mt-1 rounded-lg hover:bg-secondary transition-colors duration-150 cursor-pointer ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <User size={14} className="text-primary" />
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-foreground truncate">{profile?.full_name || user?.email || 'Usuario AssetDesk'}</p>
              <p className="text-[10px] text-muted-foreground truncate">{profile?.role === 'technician' ? 'Técnico' : profile?.role === 'pending' ? 'Pendiente de aprobación' : 'Administradora TI'}</p>
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={() => void signOut()}
          title="Cerrar sesión"
          className={`mt-1 flex w-full items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-colors hover:bg-red-500/10 hover:text-red-400 ${collapsed ? 'justify-center' : ''}`}>
          <LogOut size={17} className="shrink-0" />
          {!collapsed && <span className="text-sm font-medium">Cerrar sesión</span>}
        </button>
      </div>
    </aside>
  );
}