import { saveOrShareFile } from '@/lib/nativeFiles';

export async function downloadTablePdf(
  title: string,
  columns: string[],
  rows: string[][],
  filename: string,
): Promise<void> {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const margin = 12;
  const pageWidth = 297;
  const pageHeight = 210;
  const usableWidth = pageWidth - margin * 2;
  const columnWidth = usableWidth / Math.max(columns.length, 1);
  let y = margin;

  const drawHeader = () => {
    doc.setFillColor(30, 30, 46);
    doc.rect(0, 0, pageWidth, 24, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.text(title, margin, 10);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`AssetDesk · ${new Date().toLocaleString('es-CO')}`, margin, 17);
    y = 31;
  };

  const drawTableHeader = () => {
    doc.setFillColor(225, 232, 250);
    doc.rect(margin, y, usableWidth, 8, 'F');
    doc.setTextColor(30, 30, 46);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    columns.forEach((column, index) => doc.text(column, margin + index * columnWidth + 2, y + 5));
    y += 10;
  };

  drawHeader();
  drawTableHeader();
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);

  rows.forEach((row, rowIndex) => {
    const lines = row.map((value) => doc.splitTextToSize(String(value || '—'), columnWidth - 4).slice(0, 3) as string[]);
    const height = Math.max(7, ...lines.map((value) => value.length * 3.2 + 3));
    if (y + height > pageHeight - 14) {
      doc.addPage();
      drawHeader();
      drawTableHeader();
    }
    if (rowIndex % 2 === 0) {
      doc.setFillColor(249, 250, 253);
      doc.rect(margin, y - 2, usableWidth, height, 'F');
    }
    doc.setTextColor(45, 45, 55);
    lines.forEach((value, index) => doc.text(value, margin + index * columnWidth + 2, y + 3));
    doc.setDrawColor(225, 225, 232);
    doc.line(margin, y + height - 2, margin + usableWidth, y + height - 2);
    y += height;
  });

  doc.setTextColor(110, 110, 120);
  doc.setFontSize(7);
  doc.text(`Registros: ${rows.length}`, margin, pageHeight - 7);
  const finalName = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
  const pdfBlob = doc.output('blob') as Blob;
  await saveOrShareFile(pdfBlob, finalName, `Informe AssetDesk: ${title}`);
}
