/** Single source of truth for QR links across web, Android and future iOS builds. */
export function getSiteUrl(): string {
  const browserOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim().replace(/\/$/, '');
  // In the browser, use the origin that is actually serving the app. This
  // prevents stale local or historical environment URLs from being printed
  // into new labels. Production QRs therefore use the public app origin.
  return browserOrigin || configured || '';
}

export function getAssetQrUrl(assetId: string, _autoDownloadPdf = false): string {
  const base = getSiteUrl();
  // QR codes must open the interactive technical sheet. From there the user
  // can view the asset, history and maintenance actions on any device.
  return `${base}/asset/${encodeURIComponent(assetId)}`;
}
