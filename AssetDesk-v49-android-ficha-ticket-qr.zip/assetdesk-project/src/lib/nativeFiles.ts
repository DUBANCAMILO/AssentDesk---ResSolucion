import { Capacitor } from '@capacitor/core';

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = String(reader.result || '');
      resolve(result.includes(',') ? result.split(',')[1] : result);
    };
    reader.onerror = () => reject(reader.error || new Error('No se pudo preparar el archivo'));
    reader.readAsDataURL(blob);
  });
}

export async function saveOrShareFile(blob: Blob, filename: string, title = 'Compartir desde AssetDesk'): Promise<void> {
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }

  const [{ Filesystem, Directory }, { Share }] = await Promise.all([
    import('@capacitor/filesystem'),
    import('@capacitor/share'),
  ]);
  const data = await blobToBase64(blob);
  const stored = await Filesystem.writeFile({
    path: `assetdesk/${filename}`,
    data,
    directory: Directory.Cache,
    recursive: true,
  });

  await Share.share({
    title,
    text: filename,
    files: stored.uri ? [stored.uri] : undefined,
    dialogTitle: title,
  });
}

export async function shareText(title: string, text: string, url?: string): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    const { Share } = await import('@capacitor/share');
    await Share.share({ title, text, url, dialogTitle: 'Compartir desde AssetDesk' });
    return;
  }

  if (navigator.share) {
    await navigator.share({ title, text, url });
    return;
  }

  await navigator.clipboard.writeText([text, url].filter(Boolean).join('\n'));
}
