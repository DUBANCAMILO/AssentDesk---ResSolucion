'use client';

import React, { useState, useEffect } from 'react';
import { Capacitor } from '@capacitor/core';
import {
  X, Cpu, HardDrive, Network, MapPin, User, Wrench, Monitor,
  Printer, Keyboard, Share2, Printer as PrintIcon, Shield, Zap,
  FileDown, CheckCircle,
} from 'lucide-react';
import { type Asset, assetService, type AssetHistory } from '@/lib/services/assetService';
import { QRCodeSVG } from 'qrcode.react';
import AppImage from '@/components/ui/AppImage';
import { getAssetQrUrl } from '@/lib/qr';
import { saveOrShareFile, shareText } from '@/lib/nativeFiles';

interface Props {
  asset: Asset;
  onClose: () => void;
}

async function shareThermalTicketAsPng(qrDataUrl: string, asset: Asset, size: { wPx: number; hPx: number }) {
  const scale = 2;
  const canvas = document.createElement('canvas');
  canvas.width = size.wPx * scale;
  canvas.height = size.hPx * scale;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('No se pudo preparar el ticket');
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  const qr = new Image();
  await new Promise<void>((resolve, reject) => {
    qr.onload = () => resolve();
    qr.onerror = () => reject(new Error('No se pudo cargar el QR'));
    qr.src = qrDataUrl;
  });
  const padding = 10 * scale;
  const qrSize = Math.min(canvas.width - padding * 2, canvas.height * 0.44);
  context.imageSmoothingEnabled = false;
  context.drawImage(qr, (canvas.width - qrSize) / 2, padding, qrSize, qrSize);
  const lineY = canvas.height * 0.52;
  context.strokeStyle = '#9ca3af';
  context.lineWidth = scale;
  context.beginPath(); context.moveTo(padding, lineY); context.lineTo(canvas.width - padding, lineY); context.stroke();
  context.fillStyle = '#111111';
  context.textAlign = 'left';
  context.font = `bold ${11 * scale}px monospace`;
  context.fillText(`${asset.marca || ''} ${asset.modelo || ''}`.trim().slice(0, 28), padding, canvas.height * 0.62);
  context.fillStyle = '#1d4ed8';
  context.font = `bold ${11 * scale}px monospace`;
  context.fillText(asset.placa || 'ACTIVO', padding, canvas.height * 0.72);
  context.fillStyle = '#111111';
  context.font = `${9 * scale}px monospace`;
  context.fillText(`S/N: ${asset.serial || 'N/A'}`.slice(0, 30), padding, canvas.height * 0.82);
  context.fillText(`IP: ${asset.direccion_ip || 'N/A'}`.slice(0, 30), padding, canvas.height * 0.91);
  const logo = new Image();
  try {
    await new Promise<void>((resolve, reject) => { logo.onload = () => resolve(); logo.onerror = () => reject(new Error('logo')); logo.src = '/assets/images/app_logo.png'; });
    const logoW = canvas.width * 0.22;
    const logoH = logoW * (logo.height / Math.max(logo.width, 1));
    context.drawImage(logo, canvas.width - logoW - padding, canvas.height - logoH - padding, logoW, logoH);
  } catch { /* el ticket sigue siendo válido sin logo */ }
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error('No se pudo generar el ticket')), 'image/png'));
  await saveOrShareFile(blob, `ticket_${asset.placa || asset.id}.png`, 'Enviar ticket a Eleph-label');
}

function InfoRow({ label, value, mono = false }: { label: string; value?: string | number | null; mono?: boolean }) {
  if (!value) return null;
  return (
    <div className="flex justify-between items-start gap-3 py-1.5 border-b border-border/40 last:border-0">
      <span className="text-[11px] text-muted-foreground shrink-0">{label}</span>
      <span className={`text-[11px] text-foreground text-right ${mono ? 'font-mono' : 'font-medium'}`}>{String(value)}</span>
    </div>
  );
}

function Sec({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-secondary/40 border border-border/60 rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 bg-secondary/60 border-b border-border/40">
        <span className="text-muted-foreground">{icon}</span>
        <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">{title}</span>
      </div>
      <div className="px-4 py-2">{children}</div>
    </div>
  );
}

const historyColors: Record<string, string> = {
  assigned: 'text-blue-400 bg-blue-500/10',
  maintenance: 'text-amber-400 bg-amber-500/10',
  component_change: 'text-violet-400 bg-violet-500/10',
  status_change: 'text-red-400 bg-red-500/10',
  created: 'text-green-400 bg-green-500/10',
  updated: 'text-cyan-400 bg-cyan-500/10',
  baja: 'text-red-500 bg-red-500/10',
  reactivated: 'text-emerald-400 bg-emerald-500/10',
};

const statusColors = {
  operational: 'bg-green-500/10 border-green-500/30 text-green-400',
  maintenance: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
  critical: 'bg-red-500/10 border-red-500/30 text-red-400',
  decommissioned: 'bg-gray-500/10 border-gray-500/30 text-gray-400',
};

const statusLabels: Record<string, string> = {
  operational: 'OPERATIVO',
  maintenance: 'MANTENIMIENTO',
  critical: 'CRÍTICO',
  decommissioned: 'DADO DE BAJA',
};

/** Generate a real QR code data URL using qrcode library */
async function getQRDataURL(value: string, size = 120): Promise<string> {
  try {
    const QRCode = (await import('qrcode')).default;
    return await QRCode.toDataURL(value, {
      width: size,
      margin: 1,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });
  } catch {
    // Fallback: render via canvas using qrcode.react approach
    return '';
  }
}

export default function QRTechSheet({ asset, onClose }: Props) {
  const [activeTab, setActiveTab] = useState<'specs' | 'assignment' | 'network' | 'history'>('specs');
  const [history, setHistory] = useState<AssetHistory[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [showTicketSizeModal, setShowTicketSizeModal] = useState(false);

  useEffect(() => {
    if (activeTab === 'history' && asset.id) {
      setLoadingHistory(true);
      assetService.getHistory(asset.id).then(h => {
        setHistory(h);
        setLoadingHistory(false);
      });
    }
  }, [activeTab, asset.id]);

  // ── Share handler ────────────────────────────────────────────────────────
  const handleShare = async () => {
    const text = [
      `📋 ${asset.marca || ''} ${asset.modelo || ''}`,
      `Placa: ${asset.placa || 'N/A'}`,
      `S/N: ${asset.serial || 'N/A'}`,
      `Estado: ${statusLabels[asset.status || 'operational']}`,
      asset.usuario_responsable ? `Usuario: ${asset.usuario_responsable}` : '',
      asset.area ? `Área: ${asset.area}` : '',
      asset.ubicacion ? `Ubicación: ${asset.ubicacion}` : '',
      asset.direccion_ip ? `IP: ${asset.direccion_ip}` : '',
      asset.mac_address ? `MAC: ${asset.mac_address}` : '',
    ].filter(Boolean).join('\n');

    try {
      await shareText(`Equipo ${asset.placa}`, text);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    } catch {
      try {
        await navigator.clipboard.writeText(text);
        setShareSuccess(true);
        setTimeout(() => setShareSuccess(false), 2000);
      } catch {
        alert(text);
      }
    }
  };

  // ── Ticket print with size selector ─────────────────────────────────────
  const TICKET_SIZES = [
    { label: 'Institucional AssetDesk (46 × 58 mm)', w: '46mm', h: '58mm', wPx: 174, hPx: 219 },
    { label: 'Pequeño (1" × 2")', w: '25.4mm', h: '50.8mm', wPx: 96, hPx: 192 },
    { label: 'Mediano (1.5" × 3")', w: '38.1mm', h: '76.2mm', wPx: 144, hPx: 288 },
    { label: 'Grande (2" × 4")', w: '50.8mm', h: '101.6mm', wPx: 192, hPx: 384 },
  ];

  const handlePrintTicket = () => {
    setShowTicketSizeModal(true);
  };

  const doPrintTicket = async (size: typeof TICKET_SIZES[0]) => {
    setShowTicketSizeModal(false);
    const qrValue = getAssetQrUrl(asset.id);
    const qrDataUrl = await getQRDataURL(qrValue, 140);
    if (Capacitor.isNativePlatform()) {
      await shareThermalTicketAsPng(qrDataUrl, asset, size);
      return;
    }
    const isInstitutional = size.w === '46mm';
    const qrMm = isInstitutional ? 23 : 14;

    const ticketHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  @page { size: ${size.w} ${size.h}; margin: 0; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { width: ${size.w}; height: ${size.h}; overflow: hidden; font-family: 'Courier New', monospace; font-size: 5.5pt; color: #000; background: #fff; }
  .ticket { width: ${size.w}; height: ${size.h}; display: flex; flex-direction: ${isInstitutional ? 'column' : 'row'}; align-items: stretch; padding: ${isInstitutional ? '2.2mm' : '1mm'}; gap: ${isInstitutional ? '1.4mm' : '0.8mm'}; background: ${isInstitutional ? 'linear-gradient(145deg,#fff 0%,#eef2ff 100%)' : '#fff'}; }
  .qr-box { width: ${qrMm}mm; height: ${qrMm}mm; align-self: ${isInstitutional ? 'center' : 'flex-start'}; flex-shrink: 0; display: flex; align-items: center; justify-content: center; padding: ${isInstitutional ? '1mm' : '0.5mm'}; background:#fff; border-radius:1.5mm; }
  .qr-box img { width: ${isInstitutional ? qrMm - 2 : qrMm}mm; height: ${isInstitutional ? qrMm - 2 : qrMm}mm; image-rendering: pixelated; }
  .info { flex: 1; display: flex; flex-direction: column; justify-content: flex-start; gap: ${isInstitutional ? '1.1mm' : '0.8mm'}; overflow: hidden; min-width: 0; border-top: ${isInstitutional ? '0.3pt solid #9ca3af' : '0'}; padding-top: ${isInstitutional ? '1.5mm' : '0'}; }
  .brand { font-size: ${isInstitutional ? '8.5pt' : '6pt'}; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .placa { font-size: ${isInstitutional ? '7.5pt' : '5.5pt'}; font-weight: bold; color: #1e3a8a; }
  .line { font-size: ${isInstitutional ? '6.2pt' : '4.5pt'}; color: #444; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .app-mark { display:flex; align-items:center; justify-content:center; gap:1.2mm; font-size:5.5pt; color:#334155; font-weight:bold; }
  .app-mark img { width:5mm; height:5mm; object-fit:contain; }
  @media print { html, body { width: ${size.w}; height: ${size.h}; } }
</style>
</head>
<body>
<div class="ticket">
  <div class="qr-box">
    ${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR" />` : `<div style="width:${qrMm}mm;height:${qrMm}mm;border:0.5pt solid #ccc;display:flex;align-items:center;justify-content:center;font-size:4pt;">QR</div>`}
  </div>
  <div class="info">
    <div class="brand">${(asset.marca || '') + ' ' + (asset.modelo || '')}</div>
    <div class="placa">${asset.placa || ''}</div>
    <div class="line">S/N: ${asset.serial || 'N/A'}</div>
    <div class="line">IP: ${asset.direccion_ip || 'N/A'}</div>
    <div class="line">${asset.usuario_responsable || ''}</div>
    <div class="line">${asset.ubicacion || asset.area || ''}</div>
  </div>
  <div class="app-mark"><img src="/assets/images/app_logo.png" alt="AssetDesk"/>AssetDesk</div>
</div>
<script>setTimeout(function(){ window.print(); window.close(); }, 500);</script>
</body>
</html>`;

    const win = window.open('', '_blank', 'width=300,height=200');
    if (win) { win.document.write(ticketHtml); win.document.close(); }
  };

  // ── Full sheet print with real QR + image ────────────────────────────────
  const handlePrintSheet = async () => {
    // Android blocks popup print windows inside the WebView. Use the native
    // PDF/share flow instead so the user can save or choose a print app.
    if (Capacitor.isNativePlatform()) {
      await handleExportPDF();
      return;
    }
    const qrValue = getAssetQrUrl(asset.id);
    const qrDataUrl = await getQRDataURL(qrValue, 120);
    const statusLabel = statusLabels[asset.status || 'operational'];

    const row = (label: string, value: string | undefined | null) =>
      value ? `<div class="row"><span class="label">${label}</span><span class="value">${value}</span></div>` : '';

    const sheetHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Ficha Técnica — ${asset.placa || asset.marca}</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; font-size: 9.5px; color: #111; background: #fff; }
  .header { display: flex; gap: 14px; align-items: flex-start; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 10px; }
  .header-left { display: flex; flex-direction: column; align-items: center; gap: 6px; }
  .qr-img { width: 72px; height: 72px; border: 1px solid #eee; border-radius: 4px; image-rendering: pixelated; }
  .photo-img { width: 72px; height: 72px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd; }
  .header-info h1 { font-size: 15px; font-weight: bold; }
  .header-info .sub { font-size: 10px; color: #555; margin-top: 2px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 8px; font-weight: bold; background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; margin-top: 4px; }
  .sections { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .section { border: 1px solid #ddd; border-radius: 5px; overflow: hidden; }
  .section.full { grid-column: 1 / -1; }
  .section-title { background: #f0f0f5; padding: 4px 8px; font-size: 8px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; color: #555; border-bottom: 1px solid #ddd; }
  .section-body { padding: 4px 8px; }
  .row { display: flex; justify-content: space-between; padding: 2.5px 0; border-bottom: 1px solid #f0f0f0; font-size: 9px; }
  .row:last-child { border-bottom: none; }
  .label { color: #777; }
  .value { font-weight: 500; text-align: right; max-width: 58%; word-break: break-word; }
  .obs { margin-top: 8px; padding: 6px 8px; background: #fffde7; border: 1px solid #ffe082; border-radius: 5px; font-size: 8.5px; }
  .obs-title { font-weight: bold; color: #f57f17; margin-bottom: 2px; font-size: 8px; }
  .footer { margin-top: 10px; border-top: 1px solid #ddd; padding-top: 6px; display: flex; justify-content: space-between; font-size: 7.5px; color: #999; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style>
</head>
<body>
<div class="header">
  <div class="header-left">
    ${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR" class="qr-img" />` : `<div class="qr-img" style="display:flex;align-items:center;justify-content:center;font-size:7px;color:#999;border:1px solid #ddd;">QR</div>`}
    ${asset.foto_url ? `<img src="${asset.foto_url}" alt="Foto" class="photo-img" />` : ''}
  </div>
  <div class="header-info" style="flex:1;">
    <h1>${asset.marca || ''} ${asset.modelo || ''}</h1>
    <div class="sub">Placa: <strong>${asset.placa || 'N/A'}</strong> &nbsp;|&nbsp; S/N: ${asset.serial || 'N/A'}</div>
    <div class="sub">Sede: ${asset.sede || 'N/A'} &nbsp;|&nbsp; Área: ${asset.area || 'N/A'} &nbsp;|&nbsp; Tipo: ${asset.tipo_equipo || 'N/A'}</div>
    <div class="sub">Usuario: ${asset.usuario_responsable || 'N/A'} &nbsp;|&nbsp; Ubicación: ${asset.ubicacion || 'N/A'}</div>
    <span class="badge">${statusLabel}</span>
  </div>
</div>
<div class="sections">
  <div class="section">
    <div class="section-title">Procesador y Memoria</div>
    <div class="section-body">
      ${row('CPU', [asset.procesador_marca, asset.procesador_tipo, asset.procesador_velocidad].filter(Boolean).join(' '))}
      ${row('Núcleos/Hilos', asset.procesador_nucleos)}
      ${row('Generación', asset.procesador_generacion)}
      ${row('RAM', [asset.ram_capacidad, asset.ram_tipo].filter(Boolean).join(' '))}
      ${row('Slots RAM', asset.ram_slots_totales ? `${asset.ram_slots_totales} total, ${asset.ram_slots_libres || '?'} libres` : null)}
      ${row('Disco 1', [asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' '))}
      ${row('Interfaz Disco', asset.disco_interfaz)}
      ${row('Disco 2', [asset.disco2_capacidad, asset.disco2_tecnologia].filter(Boolean).join(' '))}
    </div>
  </div>
  <div class="section">
    <div class="section-title">Sistema Operativo y Software</div>
    <div class="section-body">
      ${row('S.O.', asset.sistema_operativo)}
      ${row('Build / SP', asset.service_pack)}
      ${row('Arquitectura', asset.arquitectura)}
      ${row('Office', asset.office_version)}
      ${row('Antivirus', asset.antivirus)}
      ${row('BIOS / UEFI', asset.bios_version)}
      ${row('TPM', asset.tpm_version)}
      ${row('Secure Boot', asset.secure_boot)}
    </div>
  </div>
  <div class="section">
    <div class="section-title">GPU y Pantalla</div>
    <div class="section-body">
      ${row('GPU', [asset.gpu_tipo, asset.gpu_marca, asset.gpu_modelo, asset.gpu_vram].filter(Boolean).join(' '))}
      ${row('Pantalla', [asset.display_tamano ? `${asset.display_tamano}"` : '', asset.display_resolucion].filter(Boolean).join(' '))}
      ${row('Panel', asset.display_tipo)}
      ${row('Frecuencia', asset.display_frecuencia)}
      ${row('Táctil', asset.display_tactil)}
    </div>
  </div>
  <div class="section">
    <div class="section-title">Asignación y Compra</div>
    <div class="section-body">
      ${row('Técnico', asset.tecnico_instalador)}
      ${row('F. Asignación', asset.fecha_asignacion)}
      ${row('Proveedor', asset.proveedor)}
      ${row('Orden Compra', asset.orden_compra)}
      ${row('F. Compra', asset.fecha_compra)}
      ${row('Garantía hasta', asset.garantia_vencimiento)}
      ${row('Tipo Garantía', asset.garantia_tipo)}
    </div>
  </div>
  <div class="section">
    <div class="section-title">Red</div>
    <div class="section-body">
      ${row('Hostname', asset.nombre_equipo)}
      ${row('IP', asset.direccion_ip)}
      ${row('MAC', asset.mac_address)}
      ${row('Subred', asset.subred)}
      ${row('Gateway', asset.gateway)}
      ${row('DNS', [asset.dns_primario, asset.dns_secundario].filter(Boolean).join(' / '))}
      ${row('Puerto Switch', asset.puerto_switch)}
      ${row('Wi-Fi', asset.wifi_estandar)}
    </div>
  </div>
  <div class="section">
    <div class="section-title">Conectividad y Periféricos</div>
    <div class="section-body">
      ${row('USB-A', asset.puertos_usb)}
      ${row('USB-C', asset.puertos_usb_c)}
      ${row('HDMI/DP', asset.puertos_hdmi)}
      ${row('Thunderbolt', asset.puertos_thunderbolt)}
      ${row('Bluetooth', asset.bluetooth)}
      ${row('Monitor', [asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' '))}
      ${row('Teclado', asset.teclado_marca)}
      ${row('Mouse', asset.mouse_marca)}
    </div>
  </div>
  ${(asset.bateria_estado || asset.bateria_capacidad) ? `
  <div class="section">
    <div class="section-title">Batería</div>
    <div class="section-body">
      ${row('Estado', asset.bateria_estado)}
      ${row('Capacidad', asset.bateria_capacidad)}
      ${row('Ciclos', asset.bateria_ciclos)}
      ${row('Modelo', asset.bateria_modelo)}
    </div>
  </div>` : ''}
  ${(asset.impresora_marca || asset.impresora_modelo) ? `
  <div class="section">
    <div class="section-title">Impresora</div>
    <div class="section-body">
      ${row('Marca', asset.impresora_marca)}
      ${row('Modelo', asset.impresora_modelo)}
      ${row('Tipo', asset.impresora_tipo)}
      ${row('Serial', asset.impresora_serial)}
    </div>
  </div>` : ''}
</div>
${asset.observaciones ? `<div class="obs"><div class="obs-title">Observaciones</div>${asset.observaciones}</div>` : ''}
${asset.recomendaciones ? `<div class="obs" style="background:#e3f2fd;border-color:#90caf9;margin-top:6px;"><div class="obs-title" style="color:#1565c0;">Recomendaciones</div>${asset.recomendaciones}</div>` : ''}
<div class="footer">
  <span>AssetDesk — Ficha Técnica</span>
  <span>Generado: ${new Date().toLocaleDateString('es-CO')}</span>
  <span>Placa: ${asset.placa || 'N/A'} | S/N: ${asset.serial || 'N/A'}</span>
</div>
<script>setTimeout(function(){ window.print(); window.close(); }, 600);</script>
</body>
</html>`;

    const win = window.open('', '_blank');
    if (win) { win.document.write(sheetHtml); win.document.close(); }
  };

  // ── jsPDF export with real QR + image ────────────────────────────────────
  const handleExportPDF = async () => {
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const margin = 14;
      const pageW = 210;
      const contentW = pageW - margin * 2;
      let y = margin;

      const qrValue = getAssetQrUrl(asset.id);
      const qrDataUrl = await getQRDataURL(qrValue, 220);

      // ── Header band ──────────────────────────────────────────────────────
      doc.setFillColor(30, 30, 46);
      doc.rect(0, 0, pageW, 40, 'F');

      // QR code (top-right in header)
      if (qrDataUrl) {
        doc.addImage(qrDataUrl, 'PNG', pageW - margin - 30, 5, 30, 30);
      }

      // Equipment photo (top-left in header)
      if (asset.foto_url) {
        try {
          const imgData = await fetch(asset.foto_url)
            .then(r => r.blob())
            .then(blob => new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.onerror = reject;
              reader.readAsDataURL(blob);
            }));
          doc.addImage(imgData, 'JPEG', margin, 5, 30, 30);
        } catch { /* CORS skip */ }
      }

      // Title in header
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(15);
      doc.setFont('helvetica', 'bold');
      doc.text(`${asset.marca || ''} ${asset.modelo || ''}`, margin + 34, 16);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(180, 180, 200);
      doc.text(`Placa: ${asset.placa || 'N/A'}   S/N: ${asset.serial || 'N/A'}`, margin + 34, 23);
      doc.text(`Sede: ${asset.sede || 'N/A'}   Área: ${asset.area || 'N/A'}`, margin + 34, 29);

      // Status badge
      const statusLabel = statusLabels[asset.status || 'operational'];
      const badgeColors: Record<string, [number, number, number]> = {
        operational: [34, 197, 94], maintenance: [245, 158, 11],
        critical: [239, 68, 68], decommissioned: [107, 114, 128],
      };
      const [r, g, b] = badgeColors[asset.status || 'operational'];
      doc.setFillColor(r, g, b);
      doc.roundedRect(margin + 34, 31, 30, 5, 1, 1, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text(statusLabel, margin + 49, 34.5, { align: 'center' });

      y = 46;
      doc.setTextColor(30, 30, 30);

      // ── Helper: draw a section with alternating rows ─────────────────────
      const drawSection = (title: string, rows: [string, string][], colOffset = 0, colWidth = contentW) => {
        if (y > 265) { doc.addPage(); y = margin; }
        doc.setFillColor(245, 245, 250);
        doc.rect(margin + colOffset, y, colWidth, 7, 'F');
        doc.setDrawColor(220, 220, 230);
        doc.rect(margin + colOffset, y, colWidth, 7, 'S');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(80, 80, 100);
        doc.text(title.toUpperCase(), margin + colOffset + 3, y + 5);
        y += 8;

        const validRows = rows.filter(([, v]) => v && v !== 'N/A');
        validRows.forEach(([label, value], idx) => {
          if (y > 270) { doc.addPage(); y = margin; }
          const rowH = 6;
          if (idx % 2 === 0) {
            doc.setFillColor(252, 252, 255);
            doc.rect(margin + colOffset, y, colWidth, rowH, 'F');
          }
          doc.setDrawColor(235, 235, 240);
          doc.line(margin + colOffset, y + rowH, margin + colOffset + colWidth, y + rowH);
          doc.setFontSize(8);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(120, 120, 140);
          doc.text(label, margin + colOffset + 3, y + 4.2);
          doc.setTextColor(30, 30, 30);
          doc.setFont('helvetica', 'bold');
          const maxW = colWidth - 45;
          const truncated = doc.splitTextToSize(value, maxW)[0];
          doc.text(truncated, margin + colOffset + 42, y + 4.2);
          y += rowH;
        });
        y += 4;
      };

      // ── Two-column layout ────────────────────────────────────────────────
      const col1W = (contentW - 4) / 2;
      const col2W = (contentW - 4) / 2;
      const col2Offset = col1W + 4;
      const yBefore = y;

      drawSection('Procesador y Memoria', [
        ['CPU', [asset.procesador_marca, asset.procesador_tipo, asset.procesador_velocidad].filter(Boolean).join(' ') || 'N/A'],
        ['Núcleos / Hilos', asset.procesador_nucleos || 'N/A'],
        ['Generación', asset.procesador_generacion || 'N/A'],
        ['RAM', [asset.ram_capacidad, asset.ram_tipo].filter(Boolean).join(' ') || 'N/A'],
        ['Slots RAM', asset.ram_slots_totales ? `${asset.ram_slots_totales} total, ${asset.ram_slots_libres || '?'} libres` : 'N/A'],
        ['Disco 1', [asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' ') || 'N/A'],
        ['Interfaz Disco', asset.disco_interfaz || 'N/A'],
        ['Disco 2', [asset.disco2_capacidad, asset.disco2_tecnologia].filter(Boolean).join(' ') || 'N/A'],
        ['S.O.', asset.sistema_operativo || 'N/A'],
        ['Build / SP', asset.service_pack || 'N/A'],
        ['Arquitectura', asset.arquitectura || 'N/A'],
        ['Office', asset.office_version || 'N/A'],
        ['Antivirus', asset.antivirus || 'N/A'],
        ['GPU', [asset.gpu_tipo, asset.gpu_marca, asset.gpu_modelo, asset.gpu_vram].filter(Boolean).join(' ') || 'N/A'],
        ['BIOS / UEFI', asset.bios_version || 'N/A'],
        ['TPM', asset.tpm_version || 'N/A'],
        ['Secure Boot', asset.secure_boot || 'N/A'],
      ], 0, col1W);

      const yAfterLeft = y;
      y = yBefore;

      drawSection('Asignación y Compra', [
        ['Usuario', asset.usuario_responsable || 'N/A'],
        ['Área', asset.area || 'N/A'],
        ['Ubicación', asset.ubicacion || 'N/A'],
        ['Sede', asset.sede || 'N/A'],
        ['Técnico', asset.tecnico_instalador || 'N/A'],
        ['F. Asignación', asset.fecha_asignacion || 'N/A'],
        ['Proveedor', asset.proveedor || 'N/A'],
        ['Orden Compra', asset.orden_compra || 'N/A'],
        ['F. Compra', asset.fecha_compra || 'N/A'],
        ['Garantía hasta', asset.garantia_vencimiento || 'N/A'],
        ['Tipo Garantía', asset.garantia_tipo || 'N/A'],
      ], col2Offset, col2W);

      y = Math.max(yAfterLeft, y);

      // ── Full-width sections ──────────────────────────────────────────────
      drawSection('Red', [
        ['Hostname', asset.nombre_equipo || 'N/A'],
        ['Dirección IP', asset.direccion_ip || 'N/A'],
        ['MAC Address', asset.mac_address || 'N/A'],
        ['Subred', asset.subred || 'N/A'],
        ['Gateway', asset.gateway || 'N/A'],
        ['DNS Primario', asset.dns_primario || 'N/A'],
        ['DNS Secundario', asset.dns_secundario || 'N/A'],
        ['Puerto Switch', asset.puerto_switch || 'N/A'],
      ]);

      drawSection('Periféricos', [
        ['Monitor', [asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' ') || 'N/A'],
        ['Teclado', asset.teclado_marca || 'N/A'],
        ['Mouse', asset.mouse_marca || 'N/A'],
        ['Web Cam', asset.web_cam || 'N/A'],
        ['Impresora', [asset.impresora_marca, asset.impresora_modelo].filter(Boolean).join(' ') || 'N/A'],
        ['S/N Impresora', asset.impresora_serial || 'N/A'],
      ]);

      // ── Observations ─────────────────────────────────────────────────────
      if (asset.observaciones) {
        if (y > 255) { doc.addPage(); y = margin; }
        const obsLines = doc.splitTextToSize(asset.observaciones, contentW - 8);
        const obsH = obsLines.length * 5 + 12;
        doc.setFillColor(255, 253, 230);
        doc.setDrawColor(255, 224, 130);
        doc.roundedRect(margin, y, contentW, obsH, 2, 2, 'FD');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(180, 100, 0);
        doc.text('OBSERVACIONES', margin + 4, y + 6);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(80, 60, 0);
        doc.text(obsLines, margin + 4, y + 12);
        y += obsH + 4;
      }

      if (asset.recomendaciones) {
        if (y > 255) { doc.addPage(); y = margin; }
        const recLines = doc.splitTextToSize(asset.recomendaciones, contentW - 8);
        const recH = recLines.length * 5 + 12;
        doc.setFillColor(230, 245, 255);
        doc.setDrawColor(130, 200, 255);
        doc.roundedRect(margin, y, contentW, recH, 2, 2, 'FD');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0, 80, 160);
        doc.text('RECOMENDACIONES', margin + 4, y + 6);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(0, 50, 100);
        doc.text(recLines, margin + 4, y + 12);
        y += recH + 4;
      }

      // ── Footer on every page ─────────────────────────────────────────────
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFillColor(245, 245, 250);
        doc.rect(0, 285, pageW, 12, 'F');
        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(140, 140, 160);
        doc.text('AssetDesk — Sistema de Gestión de Activos', margin, 291);
        doc.text(`Generado: ${new Date().toLocaleDateString('es-CO')}`, pageW / 2, 291, { align: 'center' });
        doc.text(`Página ${i} de ${totalPages}`, pageW - margin, 291, { align: 'right' });
      }

      const filename = `ficha_${asset.placa || asset.id || 'activo'}.pdf`;
      await saveOrShareFile(doc.output('blob') as Blob, filename, `Ficha técnica: ${asset.placa || asset.id}`);
    } catch (err) {
      console.error('jsPDF export error:', err);
      alert('Error al generar PDF. Intenta de nuevo.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card border border-border rounded-2xl flex flex-col max-h-[92vh] mx-4 shadow-2xl">

        {/* Header */}
        <div className="px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-start gap-4">
            {/* Real QR Code — encodes full URL for auto-redirect on scan */}
            <div className="bg-white p-2 rounded-xl border border-border shrink-0">
              <QRCodeSVG
                value={getAssetQrUrl(asset.id)}
                size={72}
                level="M"
                includeMargin={false}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="font-mono text-xs text-primary font-bold">{asset.placa || asset.tag}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${statusColors[asset.status || 'operational']}`}>
                  {statusLabels[asset.status || 'operational']}
                </span>
              </div>
              <h2 className="text-base font-bold text-foreground leading-tight">{asset.marca} {asset.modelo}</h2>
              <p className="text-xs text-muted-foreground mt-0.5">S/N: <span className="font-mono">{asset.serial}</span></p>
              {asset.sede && <p className="text-xs text-muted-foreground">{asset.sede}</p>}
            </div>
            <div className="flex gap-1.5">
              {/* Working share button */}
              <button
                onClick={handleShare}
                title={shareSuccess ? 'Copiado!' : 'Compartir información'}
                className={`p-1.5 rounded-lg transition-colors ${shareSuccess ? 'text-green-400 bg-green-500/10' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
                {shareSuccess ? <CheckCircle size={14} /> : <Share2 size={14} />}
              </button>
              <button
                onClick={handlePrintTicket}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                title="Imprimir Ticket 12×30mm">
                <PrintIcon size={14} />
              </button>
              <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border px-5 shrink-0 overflow-x-auto">
          {([
            { key: 'specs', label: 'Especificaciones' },
            { key: 'assignment', label: 'Asignación' },
            { key: 'network', label: 'Red' },
            { key: 'history', label: 'Historial' },
          ] as const).map((tab) => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`px-3 py-3 text-xs font-medium whitespace-nowrap transition-colors border-b-2 -mb-px ${
                activeTab === tab.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-3">

          {activeTab === 'specs' && (
            <>
              {asset.foto_url && (
                <div className="rounded-xl overflow-hidden border border-border">
                  <AppImage src={asset.foto_url} alt={`Foto de ${asset.marca} ${asset.modelo}`} width={960} height={320} unoptimized className="w-full h-40 object-cover" />
                </div>
              )}
              <Sec title="Procesador" icon={<Cpu size={12} />}>
                <InfoRow label="Marca" value={asset.procesador_marca} />
                <InfoRow label="Tipo / Modelo" value={asset.procesador_tipo} />
                <InfoRow label="Velocidad" value={asset.procesador_velocidad} />
                <InfoRow label="Núcleos / Hilos" value={asset.procesador_nucleos} />
                <InfoRow label="Generación" value={asset.procesador_generacion} />
              </Sec>
              <Sec title="Memoria y Almacenamiento" icon={<HardDrive size={12} />}>
                <InfoRow label="RAM" value={asset.ram_capacidad} />
                <InfoRow label="Tipo RAM" value={asset.ram_tipo} />
                <InfoRow label="Slots" value={asset.ram_slots_totales ? `${asset.ram_slots_totales} total, ${asset.ram_slots_libres || '?'} libres` : undefined} />
                <InfoRow label="Disco 1" value={[asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' ')} />
                <InfoRow label="Interfaz" value={asset.disco_interfaz} />
                <InfoRow label="Disco 2" value={[asset.disco2_capacidad, asset.disco2_tecnologia].filter(Boolean).join(' ')} />
              </Sec>
              {(asset.gpu_marca || asset.gpu_modelo) && (
                <Sec title="Tarjeta Gráfica" icon={<Zap size={12} />}>
                  <InfoRow label="Tipo" value={asset.gpu_tipo} />
                  <InfoRow label="Marca GPU" value={asset.gpu_marca} />
                  <InfoRow label="Modelo GPU" value={asset.gpu_modelo} />
                  <InfoRow label="VRAM" value={asset.gpu_vram} />
                </Sec>
              )}
              {(asset.display_tamano || asset.display_resolucion) && (
                <Sec title="Pantalla" icon={<Monitor size={12} />}>
                  <InfoRow label="Tamaño" value={asset.display_tamano ? `${asset.display_tamano}"` : undefined} />
                  <InfoRow label="Resolución" value={asset.display_resolucion} />
                  <InfoRow label="Panel" value={asset.display_tipo} />
                  <InfoRow label="Frecuencia" value={asset.display_frecuencia} />
                  <InfoRow label="Táctil" value={asset.display_tactil} />
                </Sec>
              )}
              {(asset.bateria_estado || asset.bateria_capacidad) && (
                <Sec title="Batería" icon={<Zap size={12} />}>
                  <InfoRow label="Estado" value={asset.bateria_estado} />
                  <InfoRow label="Capacidad" value={asset.bateria_capacidad} />
                  <InfoRow label="Ciclos" value={asset.bateria_ciclos} />
                  <InfoRow label="Modelo" value={asset.bateria_modelo} />
                </Sec>
              )}
              <Sec title="Sistema Operativo" icon={<Shield size={12} />}>
                <InfoRow label="S.O." value={asset.sistema_operativo} />
                <InfoRow label="Build / SP" value={asset.service_pack} />
                <InfoRow label="Arquitectura" value={asset.arquitectura} />
                <InfoRow label="Office / Suite" value={asset.office_version} />
                <InfoRow label="Antivirus" value={asset.antivirus} />
                <InfoRow label="BIOS / UEFI" value={asset.bios_version} />
                <InfoRow label="TPM" value={asset.tpm_version} />
                <InfoRow label="Secure Boot" value={asset.secure_boot} />
              </Sec>
              {(asset.puertos_usb || asset.wifi_estandar || asset.bluetooth) && (
                <Sec title="Conectividad" icon={<Network size={12} />}>
                  <InfoRow label="USB-A" value={asset.puertos_usb} />
                  <InfoRow label="USB-C" value={asset.puertos_usb_c} />
                  <InfoRow label="HDMI / DP" value={asset.puertos_hdmi} />
                  <InfoRow label="Thunderbolt" value={asset.puertos_thunderbolt} />
                  <InfoRow label="Wi-Fi" value={asset.wifi_estandar} />
                  <InfoRow label="Bluetooth" value={asset.bluetooth} />
                  <InfoRow label="Lector Tarjetas" value={asset.lector_tarjetas} />
                </Sec>
              )}
              <Sec title="Periféricos" icon={<Keyboard size={12} />}>
                <InfoRow label="Monitor" value={[asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' ')} />
                <InfoRow label="Teclado" value={asset.teclado_marca} />
                <InfoRow label="Mouse" value={asset.mouse_marca} />
                <InfoRow label="Web Cam" value={asset.web_cam} />
              </Sec>
              {(asset.impresora_marca || asset.impresora_modelo) && (
                <Sec title="Impresora" icon={<Printer size={12} />}>
                  <InfoRow label="Marca" value={asset.impresora_marca} />
                  <InfoRow label="Modelo" value={asset.impresora_modelo} />
                  <InfoRow label="Tipo" value={asset.impresora_tipo} />
                </Sec>
              )}
              {asset.observaciones && (
                <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3">
                  <p className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider mb-1">Observaciones</p>
                  <p className="text-xs text-muted-foreground">{asset.observaciones}</p>
                </div>
              )}
            </>
          )}

          {activeTab === 'assignment' && (
            <>
              <Sec title="Ubicación Actual" icon={<MapPin size={12} />}>
                <InfoRow label="Ubicación" value={asset.ubicacion} />
                <InfoRow label="Área / Unidad" value={asset.area} />
                <InfoRow label="Sede" value={asset.sede} />
              </Sec>
              <Sec title="Responsable" icon={<User size={12} />}>
                <InfoRow label="Usuario Asignado" value={asset.usuario_responsable} />
                <InfoRow label="Fecha de Asignación" value={asset.fecha_asignacion} />
              </Sec>
              <Sec title="Instalación y Compra" icon={<Wrench size={12} />}>
                <InfoRow label="Técnico Instalador" value={asset.tecnico_instalador} />
                <InfoRow label="Proveedor" value={asset.proveedor} />
                <InfoRow label="Orden de Compra" value={asset.orden_compra} />
                <InfoRow label="Fecha Compra" value={asset.fecha_compra} />
                <InfoRow label="Garantía hasta" value={asset.garantia_vencimiento} />
                <InfoRow label="Tipo Garantía" value={asset.garantia_tipo} />
              </Sec>
            </>
          )}

          {activeTab === 'network' && (
            <Sec title="Configuración de Red" icon={<Network size={12} />}>
              <InfoRow label="Hostname" value={asset.nombre_equipo} mono />
              <InfoRow label="Dirección IP" value={asset.direccion_ip} mono />
              <InfoRow label="Máscara de Subred" value={asset.subred || '255.255.255.0'} mono />
              <InfoRow label="Puerta de Enlace" value={asset.gateway || '192.168.1.1'} mono />
              <InfoRow label="DNS Primario" value={asset.dns_primario} mono />
              <InfoRow label="DNS Secundario" value={asset.dns_secundario} mono />
              <InfoRow label="MAC Address" value={asset.mac_address} mono />
              <InfoRow label="Puerto Switch" value={asset.puerto_switch} mono />
            </Sec>
          )}

          {activeTab === 'history' && (
            <div className="space-y-2">
              {loadingHistory ? (
                <div className="text-center py-8 text-muted-foreground text-xs">Cargando historial...</div>
              ) : history.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-xs">Sin historial registrado</div>
              ) : history.map(ev => (
                <div key={ev.id} className="flex gap-3 p-3 bg-secondary/30 border border-border/50 rounded-xl">
                  <div className={`text-[9px] font-bold px-2 py-1 rounded-lg shrink-0 ${historyColors[ev.event_type] || 'text-gray-400 bg-gray-500/10'}`}>
                    {ev.event_type?.replace('_', ' ').toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground">{ev.description}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{ev.by_user} · {ev.created_at ? new Date(ev.created_at).toLocaleDateString('es-CO') : ''}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-border shrink-0 flex items-center justify-between gap-2 flex-wrap">
          <button onClick={handlePrintSheet}
            className="flex items-center gap-2 px-3 py-1.5 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
            <PrintIcon size={13} /> Imprimir Ficha
          </button>
          <button onClick={handleExportPDF}
            className="flex items-center gap-2 px-3 py-1.5 text-xs bg-blue-500/10 border border-blue-500/30 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-colors">
            <FileDown size={13} /> Exportar PDF
          </button>
          <button onClick={handlePrintTicket}
            className="flex items-center gap-2 px-3 py-1.5 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-lg transition-colors">
            <PrintIcon size={13} /> Imprimir Ticket
          </button>
        </div>
      </div>

      {/* Ticket Size Selector Modal */}
      {showTicketSizeModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowTicketSizeModal(false)} />
          <div className="relative w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Tamaño de Impresión</h3>
              <button onClick={() => setShowTicketSizeModal(false)}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={15} />
              </button>
            </div>
            <p className="text-xs text-muted-foreground mb-4">Selecciona el tamaño del ticket antes de imprimir:</p>
            <div className="space-y-2">
              {TICKET_SIZES.map((size) => (
                <button
                  key={size.label}
                  onClick={() => doPrintTicket(size)}
                  className="w-full flex items-center justify-between px-4 py-3 text-xs bg-secondary border border-border hover:border-primary/50 hover:bg-primary/5 rounded-xl transition-colors text-left group">
                  <span className="font-medium text-foreground group-hover:text-primary">{size.label}</span>
                  <span className="text-muted-foreground font-mono">{size.w} × {size.h}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowTicketSizeModal(false)}
              className="mt-4 w-full px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors">
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
