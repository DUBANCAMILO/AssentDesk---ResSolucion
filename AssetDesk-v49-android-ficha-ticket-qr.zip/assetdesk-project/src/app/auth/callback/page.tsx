'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Loader2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

function AuthCallbackContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState('');

  useEffect(() => {
    const code = searchParams.get('code');
    if (!code) { router.replace('/login'); return; }
    createClient().auth.exchangeCodeForSession(code).then(({ error: exchangeError }) => {
      if (exchangeError) setError('No se pudo confirmar el correo. Solicita un nuevo enlace.');
      else router.replace('/');
    });
  }, [router, searchParams]);

  return (
    <main className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="text-center text-sm text-muted-foreground">
        {error ? <p className="text-red-300">{error}</p> : <><Loader2 size={24} className="mx-auto mb-3 animate-spin text-primary" /><p>Confirmando tu cuenta...</p></>}
      </div>
    </main>
  );
}

export default function AuthCallbackPage() {
  return <Suspense fallback={<main className="min-h-screen bg-background flex items-center justify-center text-sm text-muted-foreground">Confirmando cuenta...</main>}><AuthCallbackContent /></Suspense>;
}
