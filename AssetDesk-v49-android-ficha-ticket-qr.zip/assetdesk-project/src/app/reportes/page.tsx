'use client';

import React, { useState, useCallback } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import {
  FileText, Download, RefreshCw, Calendar, CheckCircle,
  Monitor, Printer, Camera, Wrench, AlertTriangle, BarChart2, Network,
} from 'lucide-react';
import { assetService, printerService, cameraService, maintenanceService, ipService } from '@/lib/services/assetService';
const MONTHS = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
];

function pad(n: number) { return String(n).padStart(2, '0'); }

function formatDate(d: Date) {
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

export default function ReportsPage() {
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [includeAssets, setIncludeAssets] = useState(true);
  const [includePrinters, setIncludePrinters] = useState(true);
  const [includeCameras, setIncludeCameras] = useState(true);
  const [includeMaintenance, setIncludeMaintenance] = useState(true);
  const [includeIPs, setIncludeIPs] = useState(true);

  const years = [new Date().getFullYear(), new Date().getFullYear() - 1];

  const generatePDF = useCallback(async () => {
    setGenerating(true);
    setGenerated(false);

    const [assets, printers, cameras, maintenances, ips] = await Promise.all([
      includeAssets ? assetService.getAll() : Promise.resolve([]),
      includePrinters ? printerService.getAll() : Promise.resolve([]),
      includeCameras ? cameraService.getAll() : Promise.resolve([]),
      includeMaintenance ? maintenanceService.getAll() : Promise.resolve([]),
      includeIPs ? ipService.getAll() : Promise.resolve([]),
    ]);

    const now = new Date();
    const monthName = MONTHS[selectedMonth];
    const reportTitle = `Reporte Mensual de Inventario TI — ${monthName} ${selectedYear}`;

    // Build HTML for PDF
    const statusLabel: Record<string, string> = {
      operational: 'Operativo', maintenance: 'Mantenimiento',
      critical: 'Crítico', decommissioned: 'Dado de Baja',
    };
    const statusColor: Record<string, string> = {
      operational: '#22c55e', maintenance: '#f97316', critical: '#ef4444', decommissioned: '#6b7280',
    };
    const estadoLabel: Record<string, string> = {
      pendiente: 'Pendiente', en_proceso: 'En Proceso', completado: 'Completado', cancelado: 'Cancelado',
    };

    const assetRows = assets.map(a => `
      <tr>
        <td>${a.placa || '—'}</td>
        <td>${a.marca || '—'} ${a.modelo || ''}</td>
        <td>${a.tipo_equipo || '—'}</td>
        <td>${a.area || '—'}</td>
        <td>${a.usuario_responsable || '—'}</td>
        <td style="color:${statusColor[a.status || 'operational']};font-weight:600">${statusLabel[a.status || 'operational']}</td>
        <td>${a.direccion_ip || '—'}</td>
      </tr>`).join('');

    const printerRows = printers.map(p => `
      <tr>
        <td>${p.placa || '—'}</td>
        <td>${p.nombre}</td>
        <td>${p.marca || '—'} ${p.modelo || ''}</td>
        <td>${p.area || '—'}</td>
        <td style="color:${statusColor[p.status || 'operational']};font-weight:600">${statusLabel[p.status || 'operational']}</td>
        <td>${p.direccion_ip || '—'}</td>
      </tr>`).join('');

    const cameraRows = cameras.map(c => `
      <tr>
        <td>${c.placa || '—'}</td>
        <td>${c.nombre}</td>
        <td>${c.tipo || '—'}</td>
        <td>${c.area || '—'}</td>
        <td>${c.resolucion || '—'}</td>
        <td style="color:${statusColor[c.status || 'operational']};font-weight:600">${statusLabel[c.status || 'operational']}</td>
        <td>${c.direccion_ip || '—'}</td>
      </tr>`).join('');

    const maintenanceRows = maintenances.map(m => `
      <tr>
        <td>${m.asset_name || '—'}</td>
        <td>${m.asset_placa || '—'}</td>
        <td>${m.tipo_mantenimiento}</td>
        <td>${m.fecha_programada}</td>
        <td>${m.tecnico_asignado || '—'}</td>
        <td style="font-weight:600">${estadoLabel[m.estado] || m.estado}</td>
        <td>${m.prioridad.charAt(0).toUpperCase() + m.prioridad.slice(1)}</td>
      </tr>`).join('');

    const ipRows = ips.map(ip => `
      <tr>
        <td>${ip.direccion_ip || '—'}</td>
        <td>${ip.nombre || '—'}</td>
        <td>${ip.tipo_dispositivo || '—'}</td>
        <td>${ip.area || '—'}</td>
        <td>${ip.mac_address || '—'}</td>
        <td style="font-weight:600">${ip.status || '—'}</td>
        <td>${ip.observaciones || '—'}</td>
      </tr>`).join('');

    const html = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"/>
<title>${reportTitle}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; color: #1e293b; background: #fff; padding: 32px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #6366f1; padding-bottom: 16px; margin-bottom: 24px; }
  .header-left h1 { font-size: 18px; font-weight: 700; color: #6366f1; }
  .header-left p { color: #64748b; font-size: 11px; margin-top: 4px; }
  .header-right { text-align: right; color: #64748b; font-size: 10px; }
  .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
  .summary-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center; }
  .summary-card .num { font-size: 24px; font-weight: 700; color: #6366f1; }
  .summary-card .lbl { font-size: 10px; color: #64748b; margin-top: 2px; }
  .section { margin-bottom: 28px; }
  .section-title { font-size: 13px; font-weight: 700; color: #1e293b; border-left: 3px solid #6366f1; padding-left: 10px; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
  table { width: 100%; border-collapse: collapse; font-size: 10px; }
  th { background: #f1f5f9; color: #475569; font-weight: 600; padding: 7px 10px; text-align: left; border-bottom: 1px solid #e2e8f0; text-transform: uppercase; font-size: 9px; letter-spacing: 0.05em; }
  td { padding: 6px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; }
  tr:nth-child(even) td { background: #f8fafc; }
  .footer { margin-top: 32px; border-top: 1px solid #e2e8f0; padding-top: 12px; display: flex; justify-content: space-between; color: #94a3b8; font-size: 9px; }
  @media print { body { padding: 16px; } }
</style>
</head>
<body>
<div class="header">
  <div class="header-left">
    <h1>AssetDesk — Reporte de Inventario TI</h1>
    <p>${monthName} ${selectedYear} · Generado el ${formatDate(now)}</p>
  </div>
  <div class="header-right">
    <div>Departamento de Tecnología</div>
    <div>Reporte Mensual Oficial</div>
  </div>
</div>

<div class="summary">
  ${includeAssets ? `<div class="summary-card"><div class="num">${assets.length}</div><div class="lbl">Equipos de Cómputo</div></div>` : ''}
  ${includePrinters ? `<div class="summary-card"><div class="num">${printers.length}</div><div class="lbl">Impresoras</div></div>` : ''}
  ${includeCameras ? `<div class="summary-card"><div class="num">${cameras.length}</div><div class="lbl">Cámaras / DVR</div></div>` : ''}
  ${includeMaintenance ? `<div class="summary-card"><div class="num">${maintenances.filter(m => m.estado === 'pendiente').length}</div><div class="lbl">Mantenimientos Pendientes</div></div>` : ''}
  ${includeIPs ? `<div class="summary-card"><div class="num">${ips.length}</div><div class="lbl">Registros de Red</div></div>` : ''}
</div>

${includeAssets && assets.length > 0 ? `
<div class="section">
  <div class="section-title">Inventario de Equipos de Cómputo (${assets.length})</div>
  <table>
    <thead><tr><th>Placa</th><th>Marca / Modelo</th><th>Tipo</th><th>Área</th><th>Responsable</th><th>Estado</th><th>IP</th></tr></thead>
    <tbody>${assetRows}</tbody>
  </table>
</div>` : ''}

${includePrinters && printers.length > 0 ? `
<div class="section">
  <div class="section-title">Inventario de Impresoras (${printers.length})</div>
  <table>
    <thead><tr><th>Placa</th><th>Nombre</th><th>Marca / Modelo</th><th>Área</th><th>Estado</th><th>IP</th></tr></thead>
    <tbody>${printerRows}</tbody>
  </table>
</div>` : ''}

${includeCameras && cameras.length > 0 ? `
<div class="section">
  <div class="section-title">Inventario de Cámaras y DVR (${cameras.length})</div>
  <table>
    <thead><tr><th>Placa</th><th>Nombre</th><th>Tipo</th><th>Área</th><th>Resolución</th><th>Estado</th><th>IP</th></tr></thead>
    <tbody>${cameraRows}</tbody>
  </table>
</div>` : ''}

${includeMaintenance && maintenances.length > 0 ? `
<div class="section">
  <div class="section-title">Mantenimientos Programados (${maintenances.length})</div>
  <table>
    <thead><tr><th>Activo</th><th>Placa</th><th>Tipo</th><th>Fecha</th><th>Técnico</th><th>Estado</th><th>Prioridad</th></tr></thead>
    <tbody>${maintenanceRows}</tbody>
  </table>
</div>` : ''}

${includeIPs && ips.length > 0 ? `
<div class="section">
  <div class="section-title">Gestión de IPs y conectividad (${ips.length})</div>
  <table>
    <thead><tr><th>Dirección IP</th><th>Equipo / Nombre</th><th>Tipo</th><th>Área</th><th>MAC</th><th>Estado</th><th>Observaciones</th></tr></thead>
    <tbody>${ipRows}</tbody>
  </table>
</div>` : ''}

<div class="footer">
  <span>AssetDesk — Sistema de Gestión de Activos TI</span>
  <span>Reporte generado automáticamente · ${formatDate(now)}</span>
</div>
</body>
</html>`;

    // Open in new window and trigger print
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
      win.focus();
      setTimeout(() => { win.print(); }, 500);
    }

    setGenerating(false);
    setGenerated(true);
    setTimeout(() => setGenerated(false), 3000);
  }, [selectedMonth, selectedYear, includeAssets, includePrinters, includeCameras, includeMaintenance, includeIPs]);

  return (
    <AppLayout>
      <Topbar title="Reportes PDF" subtitle="Generación automática de reportes mensuales de inventario" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Config panel */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Calendar size={15} className="text-primary" />
                Configurar Reporte
              </h3>

              <div>
                <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Mes</label>
                <select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))}
                  className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary">
                  {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Año</label>
                <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))}
                  className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary">
                  {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-muted-foreground mb-2 uppercase tracking-wide">Secciones a incluir</label>
                <div className="space-y-2">
                  {[
                    { label: 'Equipos de Cómputo', value: includeAssets, set: setIncludeAssets, icon: Monitor },
                    { label: 'Impresoras', value: includePrinters, set: setIncludePrinters, icon: Printer },
                    { label: 'Cámaras y DVR', value: includeCameras, set: setIncludeCameras, icon: Camera },
                    { label: 'Mantenimientos', value: includeMaintenance, set: setIncludeMaintenance, icon: Wrench },
                    { label: 'Gestión de IPs', value: includeIPs, set: setIncludeIPs, icon: Network },
                  ].map(item => {
                    const ItemIcon = item.icon;
                    return (
                      <label key={item.label} className="flex items-center gap-3 cursor-pointer group">
                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${item.value ? 'bg-primary border-primary' : 'border-border bg-secondary'}`}
                          onClick={() => item.set(!item.value)}>
                          {item.value && <CheckCircle size={10} className="text-white" />}
                        </div>
                        <ItemIcon size={13} className="text-muted-foreground" />
                        <span className="text-xs text-foreground">{item.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <button
                onClick={generatePDF}
                disabled={generating}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50">
                {generating ? (
                  <><RefreshCw size={15} className="animate-spin" />Generando...</>
                ) : generated ? (
                  <><CheckCircle size={15} />¡Reporte Generado!</>
                ) : (
                  <><Download size={15} />Generar Reporte PDF</>
                )}
              </button>
            </div>
          </div>

          {/* Preview info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-4">
                <FileText size={15} className="text-primary" />
                Vista Previa del Reporte
              </h3>
              <div className="bg-secondary rounded-xl p-6 space-y-4">
                {/* Mock report preview */}
                <div className="flex items-start justify-between border-b border-border pb-4">
                  <div>
                    <div className="h-4 w-48 bg-primary/20 rounded mb-2" />
                    <div className="h-3 w-32 bg-border rounded" />
                  </div>
                  <div className="text-right">
                    <div className="h-3 w-24 bg-border rounded mb-1" />
                    <div className="h-3 w-20 bg-border rounded" />
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  {[Monitor, Printer, Camera, Wrench].map((Icon, i) => (
                    <div key={i} className="bg-card border border-border rounded-lg p-3 text-center">
                      <Icon size={16} className="text-primary mx-auto mb-1" />
                      <div className="h-5 w-8 bg-primary/20 rounded mx-auto mb-1" />
                      <div className="h-2 w-16 bg-border rounded mx-auto" />
                    </div>
                  ))}
                </div>
                {[1, 2, 3].map(i => (
                  <div key={i} className="space-y-2">
                    <div className="h-3 w-40 bg-primary/15 rounded" />
                    <div className="space-y-1">
                      {[1, 2, 3].map(j => (
                        <div key={j} className="flex gap-2">
                          {[1, 2, 3, 4, 5].map(k => (
                            <div key={k} className="h-2 flex-1 bg-border rounded" />
                          ))}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-3 flex items-center gap-2">
                <AlertTriangle size={12} className="text-amber-400" />
                El reporte se abrirá en una nueva pestaña. Usa Ctrl+P / Cmd+P para guardar como PDF.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                <BarChart2 size={15} className="text-primary" />
                Contenido del Reporte
              </h3>
              <div className="space-y-2">
                {[
                  { icon: Monitor, label: 'Inventario completo de equipos de cómputo con estado y ubicación', active: includeAssets },
                  { icon: Printer, label: 'Listado de impresoras con IPs y estado de conectividad', active: includePrinters },
                  { icon: Camera, label: 'Inventario de cámaras y DVR con resolución y área', active: includeCameras },
                  { icon: Wrench, label: 'Mantenimientos programados, pendientes y completados', active: includeMaintenance },
                  { icon: Network, label: 'Inventario de IPs, MAC, estado y conectividad', active: includeIPs },
                ].map((item, i) => {
                  const ItemIcon = item.icon;
                  return (
                    <div key={i} className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${item.active ? 'bg-primary/5 border border-primary/20' : 'bg-secondary opacity-50'}`}>
                      <ItemIcon size={14} className={item.active ? 'text-primary' : 'text-muted-foreground'} />
                      <span className="text-xs text-foreground">{item.label}</span>
                      {item.active && <CheckCircle size={12} className="text-green-400 ml-auto shrink-0" />}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
