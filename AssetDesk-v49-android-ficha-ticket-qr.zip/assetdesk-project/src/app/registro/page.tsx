'use client';

import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { CheckCircle2, Eye, EyeOff, Loader2, LockKeyhole, Mail, Phone, UserRound } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';
import { useAuth } from '@/contexts/AuthContext';

export default function RegisterPage() {
  const router = useRouter();
  const { signUp } = useAuth();
  const [fullName, setFullName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    setMessage('');
    if (whatsapp.replace(/\D/g, '').length < 7) {
      setError('El WhatsApp es obligatorio para completar el registro.');
      return;
    }
    setSaving(true);
    try {
      await signUp(email.trim(), password, { fullName: fullName.trim(), whatsapp: whatsapp.trim() });
      setMessage('Cuenta creada. Revisa tu correo para confirmar la cuenta antes de ingresar.');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No se pudo crear la cuenta.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <main className="min-h-screen bg-background flex items-center justify-center px-4 py-8">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background pointer-events-none" />
      <section className="relative w-full max-w-md rounded-3xl border border-border bg-card/95 p-7 shadow-2xl shadow-primary/10">
        <div className="flex flex-col items-center text-center mb-6">
          <AppLogo size={48} />
          <h1 className="mt-3 text-xl font-bold text-foreground">Crear cuenta AssetDesk</h1>
          <p className="mt-1 text-xs text-muted-foreground">La primera cuenta queda como administradora principal.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <label className="block space-y-1"><span className="text-xs font-semibold text-foreground">Nombre completo</span><span className="relative block"><UserRound size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input required value={fullName} onChange={(event) => setFullName(event.target.value)} className="w-full rounded-xl border border-border bg-secondary py-2.5 pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary" /></span></label>
          <label className="block space-y-1"><span className="text-xs font-semibold text-foreground">WhatsApp obligatorio</span><span className="relative block"><Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input required value={whatsapp} onChange={(event) => setWhatsapp(event.target.value)} placeholder="Ej. +57..." className="w-full rounded-xl border border-border bg-secondary py-2.5 pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary" /></span></label>
          <label className="block space-y-1"><span className="text-xs font-semibold text-foreground">Correo electrónico</span><span className="relative block"><Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="w-full rounded-xl border border-border bg-secondary py-2.5 pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary" /></span></label>
          <label className="block space-y-1"><span className="text-xs font-semibold text-foreground">Contraseña</span><span className="relative block"><LockKeyhole size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input required minLength={6} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="w-full rounded-xl border border-border bg-secondary py-2.5 pl-9 pr-10 text-sm text-foreground outline-none focus:border-primary" /><button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showPassword ? <EyeOff size={14} /> : <Eye size={14} />}</button></span></label>
          {error && <p className="rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-xs text-red-300">{error}</p>}
          {message && <p className="flex items-start gap-2 rounded-xl border border-green-500/20 bg-green-500/10 p-3 text-xs text-green-300"><CheckCircle2 size={15} className="shrink-0" />{message}</p>}
          <button disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-50">{saving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}{saving ? 'Creando cuenta...' : 'Crear cuenta'}</button>
        </form>
        <div className="mt-5 border-t border-border pt-4 text-center text-xs text-muted-foreground">¿Ya tienes cuenta? <Link href="/login" className="font-semibold text-primary hover:underline">Ingresar</Link></div>
      </section>
    </main>
  );
}
