'use client';

import { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, RefreshCw, Shield, UserRound, Users } from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { createClient } from '@/lib/supabase/client';

type Profile = {
  id: string;
  full_name?: string;
  whatsapp?: string;
  role?: string;
  company_name?: string;
  created_at?: string;
};

export default function UsersPage() {
  const supabase = createClient();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const loadProfiles = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('user_profiles').select('*').order('created_at', { ascending: false });
    if (!error) setProfiles((data || []) as Profile[]);
    setLoading(false);
  };

  useEffect(() => { void loadProfiles(); }, []);

  const updateRole = async (id: string, role: string) => {
    setSaving(id);
    const { error } = await supabase.from('user_profiles').update({ role }).eq('id', id);
    setSaving(null);
    if (error) { setMessage('No se pudo actualizar el rol.'); return; }
    setMessage('Rol actualizado correctamente.');
    await loadProfiles();
    window.setTimeout(() => setMessage(''), 2500);
  };

  return (
    <AppLayout>
      <Topbar title="Usuarios y roles" subtitle="Administración de accesos de AssetDesk" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">
        <div className="flex items-center justify-between gap-3">
          <div><h2 className="text-sm font-semibold text-foreground">Personal registrado</h2><p className="text-xs text-muted-foreground mt-1">Los registros nuevos quedan pendientes hasta que la administradora asigne un rol.</p></div>
          <button onClick={() => void loadProfiles()} className="rounded-lg border border-border bg-secondary p-2 text-muted-foreground hover:text-foreground"><RefreshCw size={14} /></button>
        </div>
        {message && <div className="flex items-center gap-2 rounded-xl border border-green-500/20 bg-green-500/10 p-3 text-xs text-green-300"><CheckCircle2 size={14} />{message}</div>}
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          {loading ? <div className="flex items-center justify-center gap-2 p-12 text-sm text-muted-foreground"><Loader2 size={16} className="animate-spin" />Cargando usuarios...</div> : profiles.length === 0 ? <div className="p-12 text-center text-sm text-muted-foreground">No hay perfiles. Aplica la migración de autenticación y registra la primera cuenta.</div> : <div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="border-b border-border bg-secondary/30 text-left text-muted-foreground"><th className="px-4 py-3">Usuario</th><th className="px-4 py-3">WhatsApp</th><th className="px-4 py-3">Rol</th><th className="px-4 py-3">Fecha</th></tr></thead><tbody>{profiles.map((profile) => <tr key={profile.id} className="border-b border-border/50"><td className="px-4 py-3"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-primary"><UserRound size={14} /></div><div><p className="font-semibold text-foreground">{profile.full_name || 'Sin nombre'}</p><p className="text-[10px] text-muted-foreground">{profile.id}</p></div></div></td><td className="px-4 py-3 text-muted-foreground">{profile.whatsapp || 'Pendiente'}</td><td className="px-4 py-3"><label className="flex items-center gap-2"><Shield size={13} className="text-primary" /><select value={profile.role || 'pending'} onChange={(event) => void updateRole(profile.id, event.target.value)} disabled={saving === profile.id} className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"><option value="admin">Administradora</option><option value="technician">Técnico</option><option value="pending">Pendiente</option></select></label></td><td className="px-4 py-3 text-muted-foreground">{profile.created_at ? new Date(profile.created_at).toLocaleDateString('es-CO') : '—'}</td></tr>)}</tbody></table></div>}
        </div>
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 text-xs text-muted-foreground"><Users size={15} className="mb-2 text-primary" /><p>La primera cuenta creada queda como administradora principal. Las siguientes cuentas se registran como pendientes hasta que aquí se asigne Administradora o Técnico.</p></div>
      </div>
    </AppLayout>
  );
}
