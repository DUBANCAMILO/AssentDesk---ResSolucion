'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import {
  Search, X, Server, Router, Layers, Eye, ChevronUp, ChevronDown, ChevronsUpDown,
  Monitor, Network, Wifi, WifiOff, Tag, Plus, RefreshCw, Trash2, Share2, CheckCircle,
  AlertCircle, Edit2, Globe, Smartphone
} from 'lucide-react';
import { ipService, wifiService, type WifiNetwork } from '@/lib/services/assetService';
import { createClient } from '@/lib/supabase/client';
import { QRCodeSVG } from 'qrcode.react';

interface IPRecord {
  id: string;
  direccion_ip: string;
  asset_id?: string;
  nombre?: string;
  area?: string;
  tipo_dispositivo?: string;
  mac_address?: string;
  subred?: string;
  gateway?: string;
  dns_primario?: string;
  dns_secundario?: string;
  puerto_switch?: string;
  tipo_asignacion?: string;
  status?: string;
  observaciones?: string;
}

const DEVICE_ICONS: Record<string, React.ReactNode> = {
  PC: <Monitor size={12} />,
  Impresora: <Layers size={12} />,
  Servidor: <Server size={12} />,
  Switch: <Network size={12} />,
  Router: <Router size={12} />,
  NAS: <Server size={12} />,
  Smartphone: <Smartphone size={12} />,
  Tablet: <Smartphone size={12} />,
  IoT: <Globe size={12} />,
};

const STATUS_COLORS: Record<string, string> = {
  ocupada: 'text-green-400 bg-green-500/10 border-green-500/20',
  disponible: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  reservada: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
};

const WIFI_STATUS_COLORS: Record<string, string> = {
  activa: 'text-green-400 bg-green-500/10 border-green-500/20',
  inactiva: 'text-gray-400 bg-gray-500/10 border-gray-500/20',
  mantenimiento: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
};

type SortKey = 'direccion_ip' | 'status' | 'nombre' | 'area';
type SortDir = 'asc' | 'desc';
type ActiveTab = 'ips' | 'wifi';

const EMPTY_IP_FORM = {
  direccion_ip: '',
  nombre: '',
  area: '',
  tipo_dispositivo: 'PC',
  mac_address: '',
  subred: '255.255.255.0',
  gateway: '192.168.1.1',
  dns_primario: '',
  dns_secundario: '',
  puerto_switch: '',
  tipo_asignacion: 'DHCP',
  observaciones: '',
  status: 'disponible',
};

const EMPTY_WIFI_FORM: Omit<WifiNetwork, 'id' | 'created_at' | 'updated_at'> = {
  nombre: '',
  ssid: '',
  password: '',
  seguridad: 'WPA2',
  banda: '2.4 GHz',
  canal: '',
  velocidad_max: '',
  router_marca: '',
  router_modelo: '',
  router_ip: '',
  area: '',
  sede: '',
  status: 'activa',
  observaciones: '',
};

function buildWifiQRString(ssid: string, password: string, security: string): string {
  const sec = security.startsWith('WPA') ? 'WPA' : security === 'WEP' ? 'WEP' : 'nopass';
  const escapedSSID = ssid.replace(/[\\;,"]/g, (c) => `\\${c}`);
  const escapedPass = password.replace(/[\\;,"]/g, (c) => `\\${c}`);
  return `WIFI:T:${sec};S:${escapedSSID};P:${escapedPass};;`;
}

export default function IPManagementPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('ips');

  // ── IP State ──────────────────────────────────────────────────────────────
  const [ips, setIps] = useState<IPRecord[]>([]);
  const [loadingIPs, setLoadingIPs] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('direccion_ip');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selectedIP, setSelectedIP] = useState<IPRecord | null>(null);
  const [editingIP, setEditingIP] = useState<IPRecord | null>(null);
  const [showAddIP, setShowAddIP] = useState(false);
  const [newIP, setNewIP] = useState({ ...EMPTY_IP_FORM });
  const [savingIP, setSavingIP] = useState(false);
  const [saveIPError, setSaveIPError] = useState<string | null>(null);
  const [saveIPSuccess, setSaveIPSuccess] = useState(false);
  const [syncingInventoryIPs, setSyncingInventoryIPs] = useState(false);
  const [page, setPage] = useState(1);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const perPage = 15;

  // ── WiFi State ────────────────────────────────────────────────────────────
  const [wifiNetworks, setWifiNetworks] = useState<WifiNetwork[]>([]);
  const [loadingWifi, setLoadingWifi] = useState(true);
  const [wifiSearch, setWifiSearch] = useState('');
  const [showAddWifi, setShowAddWifi] = useState(false);
  const [editingWifi, setEditingWifi] = useState<WifiNetwork | null>(null);
  const [newWifi, setNewWifi] = useState({ ...EMPTY_WIFI_FORM });
  const [savingWifi, setSavingWifi] = useState(false);
  const [saveWifiError, setSaveWifiError] = useState<string | null>(null);
  const [saveWifiSuccess, setSaveWifiSuccess] = useState(false);
  const [selectedWifi, setSelectedWifi] = useState<WifiNetwork | null>(null);
  const [showWifiPassword, setShowWifiPassword] = useState<Record<string, boolean>>({});

  // ── Load IPs ──────────────────────────────────────────────────────────────
  const loadIPs = useCallback(async () => {
    setLoadingIPs(true);
    const data = await ipService.getAll();
    setIps(data as IPRecord[]);
    setLoadingIPs(false);
  }, []);

  const loadWifi = useCallback(async () => {
    setLoadingWifi(true);
    const data = await wifiService.getAll();
    setWifiNetworks(data);
    setLoadingWifi(false);
  }, []);

  useEffect(() => {
    loadIPs();
    loadWifi();
    const supabase = createClient();
    const channel = supabase
      .channel('ip_wifi_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'ip_addresses' }, () => loadIPs())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wifi_networks' }, () => loadWifi())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadIPs, loadWifi]);

  // ── IP Filtering ──────────────────────────────────────────────────────────
  const filteredIPs = useMemo(() => {
    let data = [...ips];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(ip =>
        ip.direccion_ip.includes(q) ||
        (ip.nombre || '').toLowerCase().includes(q) ||
        (ip.area || '').toLowerCase().includes(q) ||
        (ip.mac_address || '').toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'all') data = data.filter(ip => ip.status === statusFilter);
    data.sort((a, b) => {
      if (sortKey === 'direccion_ip') {
        const aOctets = a.direccion_ip.split('.').map(Number);
        const bOctets = b.direccion_ip.split('.').map(Number);
        for (let i = 0; i < 4; i++) {
          if (aOctets[i] !== bOctets[i]) return sortDir === 'asc' ? aOctets[i] - bOctets[i] : bOctets[i] - aOctets[i];
        }
        return 0;
      }
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [ips, search, statusFilter, sortKey, sortDir]);

  const totalPages = Math.ceil(filteredIPs.length / perPage);
  const paginated = filteredIPs.slice((page - 1) * perPage, page * perPage);

  const filteredWifi = useMemo(() => {
    if (!wifiSearch) return wifiNetworks;
    const q = wifiSearch.toLowerCase();
    return wifiNetworks.filter(w =>
      w.nombre.toLowerCase().includes(q) ||
      w.ssid.toLowerCase().includes(q) ||
      (w.area || '').toLowerCase().includes(q)
    );
  }, [wifiNetworks, wifiSearch]);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  // ── IP CRUD ───────────────────────────────────────────────────────────────
  const validateIP = (ip: string) => /^(\d{1,3}\.){3}\d{1,3}$/.test(ip.trim());

  const handleAddIP = async () => {
    if (!newIP.direccion_ip.trim()) { setSaveIPError('La dirección IP es obligatoria'); return; }
    const normalizedIP = newIP.direccion_ip.trim();
    if (!validateIP(normalizedIP)) { setSaveIPError('Formato de IP inválido (ej: 192.168.1.100)'); return; }
    if (ips.some((item) => item.direccion_ip.trim() === normalizedIP)) {
      setSaveIPError(`La IP ${normalizedIP} ya está registrada y no se puede duplicar.`);
      return;
    }
    setSavingIP(true); setSaveIPError(null);
    try {
      const result = await ipService.create(newIP as unknown as Record<string, unknown>);
      if (result) {
        setSaveIPSuccess(true);
        setTimeout(() => { setShowAddIP(false); setSaveIPSuccess(false); setNewIP({ ...EMPTY_IP_FORM }); }, 800);
        loadIPs();
      } else {
        setSaveIPError('No se pudo guardar. Verifica que la IP no esté duplicada.');
      }
    } catch { setSaveIPError('Error al guardar. Intenta de nuevo.'); }
    finally { setSavingIP(false); }
  };

  const handleUpdateIP = async () => {
    if (!editingIP) return;
    if (!validateIP(editingIP.direccion_ip)) { setSaveIPError('Formato de IP inválido'); return; }
    setSavingIP(true); setSaveIPError(null);
    try {
      const result = await ipService.update(editingIP.id, editingIP as unknown as Record<string, unknown>);
      if (result) {
        setSaveIPSuccess(true);
        setTimeout(() => { setEditingIP(null); setSaveIPSuccess(false); }, 800);
        loadIPs();
      } else { setSaveIPError('No se pudo actualizar.'); }
    } catch { setSaveIPError('Error al actualizar.'); }
    finally { setSavingIP(false); }
  };

  const handleDeleteIP = async (id: string) => {
    if (!confirm('¿Eliminar este registro de IP?')) return;
    await ipService.delete(id);
    setSelectedIP(null);
    loadIPs();
  };

  const handleSyncInventoryIPs = async () => {
    setSyncingInventoryIPs(true);
    try {
      const count = await ipService.reconcileFromAssets();
      setSaveIPError(`${count} IP${count === 1 ? '' : 's'} sincronizada${count === 1 ? '' : 's'} desde el inventario.`);
      await loadIPs();
    } catch (error) {
      setSaveIPError(error instanceof Error ? error.message : 'No se pudieron sincronizar las IPs.');
    } finally {
      setSyncingInventoryIPs(false);
    }
  };

  const handleShare = async (ip: IPRecord) => {
    const text = [`IP: ${ip.direccion_ip}`, ip.nombre ? `Nombre: ${ip.nombre}` : '', ip.area ? `Área: ${ip.area}` : '',
      ip.tipo_dispositivo ? `Tipo: ${ip.tipo_dispositivo}` : '', ip.mac_address ? `MAC: ${ip.mac_address}` : '',
      ip.status ? `Estado: ${ip.status}` : ''].filter(Boolean).join('\n');
    if (navigator.share) { try { await navigator.share({ title: `IP ${ip.direccion_ip}`, text }); return; } catch { /* fallback */ } }
    try { await navigator.clipboard.writeText(text); setCopiedId(ip.id); setTimeout(() => setCopiedId(null), 2000); } catch { alert(text); }
  };

  // ── WiFi CRUD ─────────────────────────────────────────────────────────────
  const handleAddWifi = async () => {
    if (!newWifi.ssid.trim()) { setSaveWifiError('El SSID es obligatorio'); return; }
    if (!newWifi.nombre.trim()) { setSaveWifiError('El nombre es obligatorio'); return; }
    setSavingWifi(true); setSaveWifiError(null);
    try {
      const result = await wifiService.create(newWifi);
      if (result) {
        setSaveWifiSuccess(true);
        setTimeout(() => { setShowAddWifi(false); setSaveWifiSuccess(false); setNewWifi({ ...EMPTY_WIFI_FORM }); }, 800);
        loadWifi();
      } else { setSaveWifiError('No se pudo guardar la red WiFi.'); }
    } catch { setSaveWifiError('Error al guardar.'); }
    finally { setSavingWifi(false); }
  };

  const handleUpdateWifi = async () => {
    if (!editingWifi) return;
    setSavingWifi(true); setSaveWifiError(null);
    try {
      const result = await wifiService.update(editingWifi.id, editingWifi);
      if (result) {
        setSaveWifiSuccess(true);
        setTimeout(() => { setEditingWifi(null); setSaveWifiSuccess(false); }, 800);
        loadWifi();
      } else { setSaveWifiError('No se pudo actualizar.'); }
    } catch { setSaveWifiError('Error al actualizar.'); }
    finally { setSavingWifi(false); }
  };

  const handleDeleteWifi = async (id: string) => {
    if (!confirm('¿Eliminar esta red WiFi?')) return;
    await wifiService.delete(id);
    setSelectedWifi(null);
    loadWifi();
  };

  const metrics = useMemo(() => ({
    total: ips.length,
    ocupadas: ips.filter(ip => ip.status === 'ocupada').length,
    disponibles: ips.filter(ip => ip.status === 'disponible').length,
    reservadas: ips.filter(ip => ip.status === 'reservada').length,
  }), [ips]);

  const wifiMetrics = useMemo(() => ({
    total: wifiNetworks.length,
    activas: wifiNetworks.filter(w => w.status === 'activa').length,
    inactivas: wifiNetworks.filter(w => w.status === 'inactiva').length,
  }), [wifiNetworks]);

  // ── Shared field component ────────────────────────────────────────────────
  const inputCls = 'w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary';
  const selectCls = 'w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary';
  const labelCls = 'block text-[11px] text-muted-foreground mb-1 font-medium';

  return (
    <AppLayout>
      <Topbar title="Gestión de Red" subtitle="Administración de IPs y redes WiFi" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Tabs */}
        <div className="flex gap-1 bg-secondary/50 border border-border rounded-xl p-1 w-fit">
          {([
            { key: 'ips', label: 'Direcciones IP', icon: <Network size={14} /> },
            { key: 'wifi', label: 'Redes WiFi', icon: <Wifi size={14} /> },
          ] as const).map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg transition-colors ${activeTab === tab.key ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>

        {/* ── IP TAB ── */}
        {activeTab === 'ips' && (
          <>
            {/* Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Total IPs', value: metrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Network },
                { label: 'Ocupadas', value: metrics.ocupadas, color: 'text-green-400', bg: 'bg-green-500/10', icon: Wifi },
                { label: 'Disponibles', value: metrics.disponibles, color: 'text-blue-400', bg: 'bg-blue-500/10', icon: WifiOff },
                { label: 'Reservadas', value: metrics.reservadas, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: Tag },
              ].map(m => {
                const MIcon = m.icon;
                return (
                  <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                    <div className={`p-2.5 rounded-xl ${m.bg}`}><MIcon size={16} className={m.color} /></div>
                    <div>
                      <p className={`text-2xl font-bold font-mono ${m.color}`}>{m.value}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{m.label}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Utilization bar */}
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Utilización de Red</p>
                <span className="text-xs text-muted-foreground">{metrics.total > 0 ? Math.round((metrics.ocupadas / metrics.total) * 100) : 0}% ocupado</span>
              </div>
              <div className="h-2 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-500 to-primary rounded-full transition-all duration-500"
                  style={{ width: `${metrics.total > 0 ? (metrics.ocupadas / metrics.total) * 100 : 0}%` }} />
              </div>
              <div className="flex items-center gap-4 mt-2 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500 inline-block" />Ocupadas: {metrics.ocupadas}</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />Disponibles: {metrics.disponibles}</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />Reservadas: {metrics.reservadas}</span>
              </div>
            </div>

            {/* IP Table */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-border">
                <div className="relative flex-1 min-w-48">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
                    placeholder="Buscar por IP, nombre, área, MAC..."
                    className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {['all', 'ocupada', 'disponible', 'reservada'].map(f => (
                    <button key={f} onClick={() => { setStatusFilter(f); setPage(1); }}
                      className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${statusFilter === f ? 'bg-primary/15 border-primary/30 text-primary' : 'bg-secondary border-border text-muted-foreground hover:text-foreground'}`}>
                      {f === 'all' ? 'Todas' : f.charAt(0).toUpperCase() + f.slice(1)}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <button onClick={handleSyncInventoryIPs} disabled={syncingInventoryIPs} title="Sincronizar IPs desde inventario"
                    className="flex items-center gap-2 px-3 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg disabled:opacity-50">
                    <RefreshCw size={13} className={syncingInventoryIPs ? 'animate-spin' : ''} /> Sincronizar inventario
                  </button>
                  <button onClick={loadIPs} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
                    <RefreshCw size={14} />
                  </button>
                  <button onClick={() => { setNewIP({ ...EMPTY_IP_FORM }); setSaveIPError(null); setSaveIPSuccess(false); setShowAddIP(true); }}
                    className="flex items-center gap-2 px-3 py-2 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                    <Plus size={13} /> Nueva IP
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border bg-secondary/30">
                      {[
                        { key: 'direccion_ip', label: 'Dirección IP' },
                        { key: null, label: 'Dispositivo' },
                        { key: 'nombre', label: 'Nombre' },
                        { key: 'area', label: 'Área' },
                        { key: null, label: 'MAC' },
                        { key: null, label: 'Asignación' },
                        { key: 'status', label: 'Estado' },
                        { key: null, label: 'Acciones' },
                      ].map((col, i) => (
                        <th key={i}
                          className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider text-[10px] ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                          onClick={() => col.key && handleSort(col.key as SortKey)}>
                          <div className="flex items-center gap-1">{col.label}{col.key && <SortIcon col={col.key as SortKey} />}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {loadingIPs ? (
                      <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                        <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando IPs...
                      </td></tr>
                    ) : paginated.length === 0 ? (
                      <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">No se encontraron registros</td></tr>
                    ) : paginated.map((ip, idx) => (
                      <tr key={ip.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors ${idx % 2 === 0 ? '' : 'bg-secondary/10'}`}>
                        <td className="px-4 py-3 font-mono text-primary font-semibold">{ip.direccion_ip}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            {DEVICE_ICONS[ip.tipo_dispositivo || 'PC'] || <Monitor size={12} />}
                            <span>{ip.tipo_dispositivo || 'PC'}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-foreground">{ip.nombre || <span className="text-muted-foreground">—</span>}</td>
                        <td className="px-4 py-3 text-muted-foreground">{ip.area || '—'}</td>
                        <td className="px-4 py-3 font-mono text-muted-foreground text-[10px]">{ip.mac_address || '—'}</td>
                        <td className="px-4 py-3 text-muted-foreground">{ip.tipo_asignacion || '—'}</td>
                        <td className="px-4 py-3">
                          <span className={`text-[10px] font-semibold px-2 py-1 rounded-lg border ${STATUS_COLORS[ip.status || 'disponible'] || 'text-muted-foreground bg-secondary border-border'}`}>
                            {(ip.status || 'disponible').charAt(0).toUpperCase() + (ip.status || 'disponible').slice(1)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            <button onClick={() => setSelectedIP(ip)} title="Ver detalle"
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                              <Eye size={14} />
                            </button>
                            <button onClick={() => { setEditingIP({ ...ip }); setSaveIPError(null); setSaveIPSuccess(false); }} title="Editar"
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10 transition-colors">
                              <Edit2 size={14} />
                            </button>
                            <button onClick={() => handleShare(ip)} title={copiedId === ip.id ? 'Copiado!' : 'Compartir'}
                              className={`p-1.5 rounded-lg transition-colors ${copiedId === ip.id ? 'text-green-400 bg-green-500/10' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
                              {copiedId === ip.id ? <CheckCircle size={14} /> : <Share2 size={14} />}
                            </button>
                            <button onClick={() => handleDeleteIP(ip.id)} title="Eliminar"
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                  <span className="text-xs text-muted-foreground">{filteredIPs.length} registros · Página {page} de {totalPages}</span>
                  <div className="flex gap-1">
                    <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                      className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">Anterior</button>
                    <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                      className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">Siguiente</button>
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* ── WIFI TAB ── */}
        {activeTab === 'wifi' && (
          <>
            {/* WiFi Metrics */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: 'Total Redes', value: wifiMetrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Wifi },
                { label: 'Activas', value: wifiMetrics.activas, color: 'text-green-400', bg: 'bg-green-500/10', icon: Wifi },
                { label: 'Inactivas', value: wifiMetrics.inactivas, color: 'text-gray-400', bg: 'bg-gray-500/10', icon: WifiOff },
              ].map(m => {
                const MIcon = m.icon;
                return (
                  <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                    <div className={`p-2.5 rounded-xl ${m.bg}`}><MIcon size={16} className={m.color} /></div>
                    <div>
                      <p className={`text-2xl font-bold font-mono ${m.color}`}>{m.value}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{m.label}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* WiFi toolbar */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-48">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input value={wifiSearch} onChange={e => setWifiSearch(e.target.value)}
                  placeholder="Buscar por nombre, SSID, área..."
                  className="w-full pl-8 pr-3 py-2 text-xs bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
              </div>
              <button onClick={loadWifi} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
                <RefreshCw size={14} />
              </button>
              <button onClick={() => { setNewWifi({ ...EMPTY_WIFI_FORM }); setSaveWifiError(null); setSaveWifiSuccess(false); setShowAddWifi(true); }}
                className="flex items-center gap-2 px-3 py-2 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                <Plus size={13} /> Nueva Red WiFi
              </button>
            </div>

            {/* WiFi Cards Grid */}
            {loadingWifi ? (
              <div className="text-center py-12 text-muted-foreground text-xs">
                <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando redes WiFi...
              </div>
            ) : filteredWifi.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground text-xs bg-card border border-border rounded-xl">
                <Wifi size={32} className="mx-auto mb-3 opacity-30" />
                <p>No hay redes WiFi registradas</p>
                <button onClick={() => setShowAddWifi(true)} className="mt-3 text-primary hover:underline">Agregar primera red</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredWifi.map(wifi => (
                  <div key={wifi.id} className="bg-card border border-border rounded-xl overflow-hidden hover:border-primary/30 transition-colors">
                    <div className="px-4 py-3 border-b border-border flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`p-1.5 rounded-lg ${wifi.status === 'activa' ? 'bg-green-500/10' : 'bg-gray-500/10'}`}>
                          <Wifi size={14} className={wifi.status === 'activa' ? 'text-green-400' : 'text-gray-400'} />
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-foreground">{wifi.nombre}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">{wifi.ssid}</p>
                        </div>
                      </div>
                      <span className={`text-[10px] font-semibold px-2 py-1 rounded-lg border ${WIFI_STATUS_COLORS[wifi.status] || 'text-muted-foreground bg-secondary border-border'}`}>
                        {wifi.status.charAt(0).toUpperCase() + wifi.status.slice(1)}
                      </span>
                    </div>
                    <div className="p-4 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Seguridad</span>
                        <span className="font-medium text-foreground">{wifi.seguridad}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Banda</span>
                        <span className="font-medium text-foreground">{wifi.banda}</span>
                      </div>
                      {wifi.area && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Área</span>
                          <span className="font-medium text-foreground">{wifi.area}</span>
                        </div>
                      )}
                      {wifi.velocidad_max && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Velocidad Máx.</span>
                          <span className="font-medium text-foreground">{wifi.velocidad_max}</span>
                        </div>
                      )}
                      {/* Password row */}
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-muted-foreground">Contraseña</span>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-foreground">
                            {showWifiPassword[wifi.id] ? (wifi.password || '—') : '••••••••'}
                          </span>
                          <button onClick={() => setShowWifiPassword(prev => ({ ...prev, [wifi.id]: !prev[wifi.id] }))}
                            className="text-[10px] text-primary hover:underline">
                            {showWifiPassword[wifi.id] ? 'Ocultar' : 'Ver'}
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="px-4 pb-4 flex gap-2">
                      <button onClick={() => setSelectedWifi(wifi)}
                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-lg transition-colors">
                        <Eye size={12} /> Ver QR
                      </button>
                      <button onClick={() => { setEditingWifi({ ...wifi }); setSaveWifiError(null); setSaveWifiSuccess(false); }}
                        className="p-2 rounded-lg text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10 border border-border transition-colors">
                        <Edit2 size={14} />
                      </button>
                      <button onClick={() => handleDeleteWifi(wifi.id)}
                        className="p-2 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 border border-border transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* ── Add IP Modal ── */}
      {showAddIP && (
        <IPFormModal
          title="Agregar Dirección IP"
          form={newIP}
          setForm={setNewIP}
          onSave={handleAddIP}
          onClose={() => setShowAddIP(false)}
          saving={savingIP}
          saveError={saveIPError}
          saveSuccess={saveIPSuccess}
          setSaveError={setSaveIPError}
          inputCls={inputCls}
          selectCls={selectCls}
          labelCls={labelCls}
        />
      )}

      {/* ── Edit IP Modal ── */}
      {editingIP && (
        <IPFormModal
          title="Editar Dirección IP"
          form={editingIP}
          setForm={(update: React.SetStateAction<IPRecord>) => setEditingIP(prev => {
            if (!prev) return null;
            return typeof update === 'function' ? update(prev) : update;
          })}
          onSave={handleUpdateIP}
          onClose={() => setEditingIP(null)}
          saving={savingIP}
          saveError={saveIPError}
          saveSuccess={saveIPSuccess}
          setSaveError={setSaveIPError}
          inputCls={inputCls}
          selectCls={selectCls}
          labelCls={labelCls}
          isEdit
        />
      )}

      {/* ── IP Detail Modal ── */}
      {selectedIP && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedIP(null)} />
          <div className="relative w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h3 className="text-sm font-semibold text-primary font-mono">{selectedIP.direccion_ip}</h3>
              <div className="flex items-center gap-1.5">
                <button onClick={() => handleShare(selectedIP)} title="Compartir"
                  className={`p-1.5 rounded-lg transition-colors ${copiedId === selectedIP.id ? 'text-green-400 bg-green-500/10' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
                  {copiedId === selectedIP.id ? <CheckCircle size={15} /> : <Share2 size={15} />}
                </button>
                <button onClick={() => { setEditingIP({ ...selectedIP }); setSelectedIP(null); setSaveIPError(null); }}
                  className="p-1.5 rounded-lg text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10 transition-colors">
                  <Edit2 size={15} />
                </button>
                <button onClick={() => setSelectedIP(null)}
                  className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                  <X size={16} />
                </button>
              </div>
            </div>
            <div className="p-6 grid grid-cols-2 gap-3 text-xs">
              {([
                ['Nombre', selectedIP.nombre], ['Área', selectedIP.area],
                ['Tipo', selectedIP.tipo_dispositivo], ['MAC', selectedIP.mac_address],
                ['Subred', selectedIP.subred], ['Gateway', selectedIP.gateway],
                ['DNS Primario', selectedIP.dns_primario], ['DNS Secundario', selectedIP.dns_secundario],
                ['Puerto Switch', selectedIP.puerto_switch], ['Tipo Asignación', selectedIP.tipo_asignacion],
                ['Estado', selectedIP.status], ['Observaciones', selectedIP.observaciones],
              ] as [string, string | undefined][]).map(([label, value]) => value ? (
                <div key={label}>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
                  <p className="text-foreground font-medium font-mono">{value}</p>
                </div>
              ) : null)}
            </div>
            <div className="px-6 pb-6 flex gap-3">
              <button onClick={() => setSelectedIP(null)}
                className="flex-1 px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">Cerrar</button>
              <button onClick={() => handleDeleteIP(selectedIP.id)}
                className="flex items-center justify-center gap-2 px-4 py-2 text-xs bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors">
                <Trash2 size={13} /> Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Add WiFi Modal ── */}
      {showAddWifi && (
        <WifiFormModal
          title="Agregar Red WiFi"
          form={newWifi}
          setForm={setNewWifi}
          onSave={handleAddWifi}
          onClose={() => setShowAddWifi(false)}
          saving={savingWifi}
          saveError={saveWifiError}
          saveSuccess={saveWifiSuccess}
          setSaveError={setSaveWifiError}
          inputCls={inputCls}
          selectCls={selectCls}
          labelCls={labelCls}
        />
      )}

      {/* ── Edit WiFi Modal ── */}
      {editingWifi && (
        <WifiFormModal
          title="Editar Red WiFi"
          form={editingWifi}
          setForm={(update: React.SetStateAction<WifiNetwork>) => setEditingWifi(prev => {
            if (!prev) return null;
            return typeof update === 'function' ? update(prev) : update;
          })}
          onSave={handleUpdateWifi}
          onClose={() => setEditingWifi(null)}
          saving={savingWifi}
          saveError={saveWifiError}
          saveSuccess={saveWifiSuccess}
          setSaveError={setSaveWifiError}
          inputCls={inputCls}
          selectCls={selectCls}
          labelCls={labelCls}
          isEdit
        />
      )}

      {/* ── WiFi QR Detail Modal ── */}
      {selectedWifi && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedWifi(null)} />
          <div className="relative w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Wifi size={16} className="text-primary" />
                <h3 className="text-sm font-semibold text-foreground">{selectedWifi.nombre}</h3>
              </div>
              <button onClick={() => setSelectedWifi(null)}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={16} />
              </button>
            </div>
            <div className="p-6 flex flex-col items-center gap-5">
              {/* QR Code */}
              <div className="bg-white p-4 rounded-2xl shadow-inner">
                <QRCodeSVG
                  value={buildWifiQRString(selectedWifi.ssid, selectedWifi.password || '', selectedWifi.seguridad)}
                  size={180}
                  level="M"
                  includeMargin={false}
                />
              </div>
              <p className="text-xs text-muted-foreground text-center">Escanea para conectarte automáticamente</p>

              {/* Network details */}
              <div className="w-full space-y-2 bg-secondary/40 rounded-xl p-4">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">SSID</span>
                  <span className="font-mono font-semibold text-foreground">{selectedWifi.ssid}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-muted-foreground">Contraseña</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-foreground">
                      {showWifiPassword[selectedWifi.id] ? (selectedWifi.password || '—') : '••••••••'}
                    </span>
                    <button onClick={() => setShowWifiPassword(prev => ({ ...prev, [selectedWifi.id]: !prev[selectedWifi.id] }))}
                      className="text-[10px] text-primary hover:underline">
                      {showWifiPassword[selectedWifi.id] ? 'Ocultar' : 'Ver'}
                    </button>
                  </div>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Seguridad</span>
                  <span className="text-foreground">{selectedWifi.seguridad}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Banda</span>
                  <span className="text-foreground">{selectedWifi.banda}</span>
                </div>
                {selectedWifi.router_ip && (
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">IP Router</span>
                    <span className="font-mono text-foreground">{selectedWifi.router_ip}</span>
                  </div>
                )}
              </div>

              {/* Copy password button */}
              <button
                onClick={async () => {
                  if (selectedWifi.password) {
                    try { await navigator.clipboard.writeText(selectedWifi.password); } catch { alert(selectedWifi.password); }
                  }
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-xl transition-colors">
                Copiar Contraseña
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}

// ── IP Form Modal Component ───────────────────────────────────────────────────
type FormRecord = object;

interface IPFormModalProps<T extends FormRecord> {
  title: string;
  form: T;
  setForm: React.Dispatch<React.SetStateAction<T>>;
  onSave: () => void;
  onClose: () => void;
  saving: boolean;
  saveError: string | null;
  saveSuccess: boolean;
  setSaveError: (e: string | null) => void;
  inputCls: string;
  selectCls: string;
  labelCls: string;
  isEdit?: boolean;
}

function IPFormModal<T extends FormRecord>({ title, form, setForm, onSave, onClose, saving, saveError, saveSuccess, setSaveError, inputCls, selectCls, labelCls, isEdit }: IPFormModalProps<T>) {
  const values = form as unknown as Record<string, string | undefined>;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card border border-border rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-primary/10 rounded-lg"><Network size={15} className="text-primary" /></div>
            <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {saveError && (
            <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs">
              <AlertCircle size={14} className="shrink-0" />{saveError}
            </div>
          )}
          {saveSuccess && (
            <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-xs">
              <CheckCircle size={14} className="shrink-0" />{isEdit ? 'IP actualizada correctamente' : 'IP guardada correctamente'}
            </div>
          )}
          <div>
            <label className={labelCls}>Dirección IP <span className="text-red-400">*</span></label>
            <input type="text" value={values.direccion_ip || ''} placeholder="192.168.1.100"
              onChange={e => { setForm(prev => ({ ...prev, direccion_ip: e.target.value })); setSaveError(null); }}
              className={`${inputCls} font-mono`} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Nombre / Hostname', key: 'nombre', placeholder: 'PC-ADMIN-001' },
              { label: 'Área', key: 'area', placeholder: 'Administración' },
              { label: 'MAC Address', key: 'mac_address', placeholder: 'AA:BB:CC:DD:EE:FF' },
              { label: 'Puerto Switch', key: 'puerto_switch', placeholder: 'Gi0/1' },
              { label: 'Subred', key: 'subred', placeholder: '255.255.255.0' },
              { label: 'Gateway', key: 'gateway', placeholder: '192.168.1.1' },
              { label: 'DNS Primario', key: 'dns_primario', placeholder: '8.8.8.8' },
              { label: 'DNS Secundario', key: 'dns_secundario', placeholder: '8.8.4.4' },
            ].map(f => (
              <div key={f.key}>
                <label className={labelCls}>{f.label}</label>
                <input type="text" value={values[f.key] || ''} placeholder={f.placeholder}
                  onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value } as T))}
                  className={inputCls} />
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelCls}>Tipo Dispositivo</label>
              <select value={values.tipo_dispositivo || 'PC'} onChange={e => setForm(prev => ({ ...prev, tipo_dispositivo: e.target.value }))} className={selectCls}>
                {['PC', 'Impresora', 'Servidor', 'Switch', 'Router', 'NAS', 'Smartphone', 'Tablet', 'IoT', 'Otro'].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Asignación</label>
              <select value={values.tipo_asignacion || 'DHCP'} onChange={e => setForm(prev => ({ ...prev, tipo_asignacion: e.target.value }))} className={selectCls}>
                {['DHCP', 'Estática', 'Reservada'].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Estado</label>
              <select value={values.status || 'disponible'} onChange={e => setForm(prev => ({ ...prev, status: e.target.value }))} className={selectCls}>
                <option value="disponible">Disponible</option>
                <option value="ocupada">Ocupada</option>
                <option value="reservada">Reservada</option>
              </select>
            </div>
          </div>
          <div>
            <label className={labelCls}>Observaciones</label>
            <textarea value={values.observaciones || ''} placeholder="Notas adicionales..." rows={2}
              onChange={e => setForm(prev => ({ ...prev, observaciones: e.target.value }))}
              className={`${inputCls} resize-none`} />
          </div>
        </div>
        <div className="flex gap-3 px-6 py-4 border-t border-border shrink-0">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors font-medium">Cancelar</button>
          <button onClick={onSave} disabled={saving || !values.direccion_ip?.trim()}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Guardando...</> : saveSuccess ? <><CheckCircle size={13} /> Guardado</> : <><Plus size={13} /> {isEdit ? 'Actualizar IP' : 'Agregar IP'}</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── WiFi Form Modal Component ─────────────────────────────────────────────────
interface WifiFormModalProps<T extends FormRecord> {
  title: string;
  form: T;
  setForm: React.Dispatch<React.SetStateAction<T>>;
  onSave: () => void;
  onClose: () => void;
  saving: boolean;
  saveError: string | null;
  saveSuccess: boolean;
  setSaveError: (e: string | null) => void;
  inputCls: string;
  selectCls: string;
  labelCls: string;
  isEdit?: boolean;
}

function WifiFormModal<T extends FormRecord>({ title, form, setForm, onSave, onClose, saving, saveError, saveSuccess, setSaveError, inputCls, selectCls, labelCls, isEdit }: WifiFormModalProps<T>) {
  const values = form as unknown as Record<string, string | undefined>;
  const [showPass, setShowPass] = useState(false);
  const wifiQR = values.ssid ? buildWifiQRString(values.ssid, values.password || '', values.seguridad || 'WPA2') : '';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-primary/10 rounded-lg"><Wifi size={15} className="text-primary" /></div>
            <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex gap-6">
            {/* Form fields */}
            <div className="flex-1 space-y-4">
              {saveError && (
                <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs">
                  <AlertCircle size={14} className="shrink-0" />{saveError}
                </div>
              )}
              {saveSuccess && (
                <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-xs">
                  <CheckCircle size={14} className="shrink-0" />{isEdit ? 'Red actualizada' : 'Red guardada correctamente'}
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Nombre de la Red <span className="text-red-400">*</span></label>
                  <input type="text" value={values.nombre || ''} placeholder="WiFi-Oficina-Principal"
                    onChange={e => { setForm(prev => ({ ...prev, nombre: e.target.value })); setSaveError(null); }}
                    className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>SSID <span className="text-red-400">*</span></label>
                  <input type="text" value={values.ssid || ''} placeholder="MiRedWiFi"
                    onChange={e => { setForm(prev => ({ ...prev, ssid: e.target.value })); setSaveError(null); }}
                    className={`${inputCls} font-mono`} />
                </div>
              </div>
              <div>
                <label className={labelCls}>Contraseña</label>
                <div className="relative">
                  <input type={showPass ? 'text' : 'password'} value={values.password || ''} placeholder="Contraseña de la red"
                    onChange={e => setForm(prev => ({ ...prev, password: e.target.value }))}
                    className={`${inputCls} pr-16 font-mono`} />
                  <button type="button" onClick={() => setShowPass(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-primary hover:underline">
                    {showPass ? 'Ocultar' : 'Mostrar'}
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Seguridad</label>
                  <select value={values.seguridad || 'WPA2'} onChange={e => setForm(prev => ({ ...prev, seguridad: e.target.value }))} className={selectCls}>
                    {['WPA3', 'WPA2', 'WPA2/WPA3', 'WPA', 'WEP', 'Abierta'].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Banda</label>
                  <select value={values.banda || '2.4 GHz'} onChange={e => setForm(prev => ({ ...prev, banda: e.target.value }))} className={selectCls}>
                    {['2.4 GHz', '5 GHz', '6 GHz', '2.4 + 5 GHz (Dual Band)', '2.4 + 5 + 6 GHz (Tri Band)'].map(b => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Canal</label>
                  <input type="text" value={values.canal || ''} placeholder="Auto / 6 / 36"
                    onChange={e => setForm(prev => ({ ...prev, canal: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Velocidad Máxima</label>
                  <input type="text" value={values.velocidad_max || ''} placeholder="300 Mbps / 1 Gbps"
                    onChange={e => setForm(prev => ({ ...prev, velocidad_max: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Marca Router</label>
                  <input type="text" value={values.router_marca || ''} placeholder="TP-Link / Cisco / Ubiquiti"
                    onChange={e => setForm(prev => ({ ...prev, router_marca: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Modelo Router</label>
                  <input type="text" value={values.router_modelo || ''} placeholder="Archer AX73"
                    onChange={e => setForm(prev => ({ ...prev, router_modelo: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>IP del Router</label>
                  <input type="text" value={values.router_ip || ''} placeholder="192.168.1.1"
                    onChange={e => setForm(prev => ({ ...prev, router_ip: e.target.value }))} className={`${inputCls} font-mono`} />
                </div>
                <div>
                  <label className={labelCls}>Área / Zona</label>
                  <input type="text" value={values.area || ''} placeholder="Oficina / Sala de Reuniones"
                    onChange={e => setForm(prev => ({ ...prev, area: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Sede</label>
                  <input type="text" value={values.sede || ''} placeholder="Sede Principal"
                    onChange={e => setForm(prev => ({ ...prev, sede: e.target.value }))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Estado</label>
                  <select value={values.status || 'activa'} onChange={e => setForm(prev => ({ ...prev, status: e.target.value }))} className={selectCls}>
                    <option value="activa">Activa</option>
                    <option value="inactiva">Inactiva</option>
                    <option value="mantenimiento">Mantenimiento</option>
                  </select>
                </div>
              </div>
              <div>
                <label className={labelCls}>Observaciones</label>
                <textarea value={values.observaciones || ''} placeholder="Notas adicionales..." rows={2}
                  onChange={e => setForm(prev => ({ ...prev, observaciones: e.target.value }))}
                  className={`${inputCls} resize-none`} />
              </div>
            </div>

            {/* QR Preview */}
            {wifiQR && (
              <div className="w-44 shrink-0 flex flex-col items-center gap-3">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Vista Previa QR</p>
                <div className="bg-white p-3 rounded-xl border border-border shadow-sm">
                  <QRCodeSVG value={wifiQR} size={140} level="M" includeMargin={false} />
                </div>
                <p className="text-[10px] text-muted-foreground text-center">Escanea para conectarte</p>
              </div>
            )}
          </div>
        </div>
        <div className="flex gap-3 px-6 py-4 border-t border-border shrink-0">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors font-medium">Cancelar</button>
          <button onClick={onSave} disabled={saving || !values.ssid?.trim() || !values.nombre?.trim()}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Guardando...</> : saveSuccess ? <><CheckCircle size={13} /> Guardado</> : <><Plus size={13} /> {isEdit ? 'Actualizar Red' : 'Agregar Red WiFi'}</>}
          </button>
        </div>
      </div>
    </div>
  );
}
