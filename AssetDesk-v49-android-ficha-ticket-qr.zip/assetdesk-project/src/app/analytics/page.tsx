'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Monitor, AlertTriangle, TrendingUp, Activity, MapPin, Users, Calendar, RefreshCw, Wrench, FileDown } from 'lucide-react';
import { assetService, type Asset } from '@/lib/services/assetService';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { downloadTablePdf } from '@/lib/pdfReport';

const COLORS = ['#6366f1', '#22c55e', '#f97316', '#ec4899', '#14b8a6', '#eab308', '#8b5cf6', '#3b82f6'];

export default function AnalyticsPage() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const loadData = async () => {
    setLoading(true);
    const data = await assetService.getAll();
    setAssets(data);
    setLastRefresh(new Date());
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const metrics = useMemo(() => {
    const total = assets.length;
    const operational = assets.filter(a => a.status === 'operational').length;
    const critical = assets.filter(a => a.status === 'critical').length;
    const maintenance = assets.filter(a => a.status === 'maintenance').length;
    const healthScore = total > 0 ? Math.round((operational / total) * 100) : 0;
    return { total, operational, critical, maintenance, healthScore };
  }, [assets]);

  const byStatus = useMemo(() => [
    { name: 'Operativo', value: metrics.operational, color: '#22c55e' },
    { name: 'Crítico', value: metrics.critical, color: '#f43f5e' },
    { name: 'Mantenimiento', value: metrics.maintenance, color: '#f97316' },
  ].filter(d => d.value > 0), [metrics]);

  const byType = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { const t = a.tipo_equipo || 'Otro'; counts[t] = (counts[t] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, value]) => ({ name, value }));
  }, [assets]);

  const byBrand = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { const b = a.marca || 'Sin marca'; counts[b] = (counts[b] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, value]) => ({ name, value }));
  }, [assets]);

  const byArea = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { const ar = a.area || 'Sin área'; counts[ar] = (counts[ar] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, value]) => ({ name, value }));
  }, [assets]);

  const byOS = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { const os = a.sistema_operativo || 'Sin OS'; counts[os] = (counts[os] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, value]) => ({ name, value }));
  }, [assets]);

  const byLocation = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { const loc = a.ubicacion || 'Sin ubicación'; counts[loc] = (counts[loc] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, value]) => ({ name, value }));
  }, [assets]);

  const registrationTrend = useMemo(() => {
    const byMonth: Record<string, number> = {};
    assets.forEach(a => {
      if (a.created_at) {
        const d = new Date(a.created_at);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        byMonth[key] = (byMonth[key] || 0) + 1;
      }
    });
    return Object.entries(byMonth).sort().slice(-6).map(([month, count]) => ({ month, count }));
  }, [assets]);

  const topUsers = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => { if (a.usuario_responsable) counts[a.usuario_responsable] = (counts[a.usuario_responsable] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [assets]);

  const handleExportPdf = async () => {
    const rows: string[][] = [
      ['Indicador general', 'Total de activos', String(metrics.total)],
      ['Indicador general', 'Operativos', String(metrics.operational)],
      ['Indicador general', 'Críticos', String(metrics.critical)],
      ['Indicador general', 'En mantenimiento', String(metrics.maintenance)],
      ['Indicador general', 'Salud general', `${metrics.healthScore}%`],
      ...byStatus.map(item => ['Estado', item.name, String(item.value)]),
      ...byType.map(item => ['Tipo de equipo', item.name, String(item.value)]),
      ...byBrand.map(item => ['Marca', item.name, String(item.value)]),
      ...byArea.map(item => ['Área', item.name, String(item.value)]),
      ...byOS.map(item => ['Sistema operativo', item.name, String(item.value)]),
      ...byLocation.map(item => ['Ubicación', item.name, String(item.value)]),
      ...topUsers.map(([user, count]) => ['Usuario responsable', user, String(count)]),
    ];
    await downloadTablePdf(
      'Panel de análisis del inventario TI',
      ['Sección', 'Indicador', 'Valor'],
      rows,
      `analisis_assetdesk_${new Date().toISOString().slice(0, 10)}`,
    );
  };

  if (loading) {
    return (
      <AppLayout>
        <Topbar title="Panel de Análisis" subtitle="Métricas e indicadores del inventario TI" />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <RefreshCw size={32} className="animate-spin text-primary mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Cargando análisis...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <Topbar title="Panel de Análisis" subtitle="Métricas e indicadores del inventario TI" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar size={13} />
            <span>Actualizado: {lastRefresh.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleExportPdf} className="flex items-center gap-2 px-3 py-1.5 text-xs text-primary hover:text-primary-foreground bg-primary/10 hover:bg-primary border border-primary/20 rounded-lg transition-colors">
              <FileDown size={12} />
              Descargar PDF
            </button>
            <button onClick={loadData} className="flex items-center gap-2 px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground bg-secondary border border-border rounded-lg transition-colors">
              <RefreshCw size={12} />
              Actualizar
            </button>
          </div>
        </div>

        {/* Bento KPI dashboard inspired by the requested visual style */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
          <div className="relative overflow-hidden rounded-2xl border border-primary/40 bg-gradient-to-br from-primary/15 via-card to-card p-5 md:col-span-2">
            <div className="flex items-start justify-between">
              <div><p className="text-[11px] font-semibold uppercase tracking-wider text-primary">Total activos TI</p><p className="mt-3 text-5xl font-bold font-mono-data text-foreground">{metrics.total}</p><p className="mt-1 text-xs text-muted-foreground">Inventario completo del parque tecnológico</p></div>
              <div className="rounded-xl border border-primary/30 bg-primary/10 p-3"><Monitor size={20} className="text-primary" /></div>
            </div>
            <div className="mt-5 flex items-center gap-3"><span className="text-xs text-muted-foreground">Tasa operativa</span><div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-primary" style={{ width: `${metrics.healthScore}%` }} /></div><strong className="text-sm text-green-400">{metrics.healthScore}%</strong></div>
            <p className="mt-2 text-[10px] text-muted-foreground">{metrics.operational} de {metrics.total} activos operativos</p>
          </div>
          {[
            { label: 'Operativos', value: metrics.operational, icon: Activity, color: 'text-green-400', bg: 'bg-green-500/10', note: 'En servicio activo' },
            { label: 'Críticos', value: metrics.critical, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10', note: 'Requieren atención' },
            { label: 'En mantenimiento', value: metrics.maintenance, icon: Wrench, color: 'text-amber-400', bg: 'bg-amber-500/10', note: 'Seguimiento técnico' },
            { label: 'Salud general', value: `${metrics.healthScore}%`, icon: TrendingUp, color: 'text-cyan-400', bg: 'bg-cyan-500/10', note: 'Estado del inventario' },
          ].map((k) => (
            <div key={k.label} className="rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/30">
              <div className="mb-4 flex items-center justify-between"><div className={`rounded-xl p-2.5 ${k.bg}`}><k.icon size={17} className={k.color} /></div><span className={`h-2 w-2 rounded-full ${k.color.replace('text-', 'bg-')}`} /></div>
              <p className={`text-3xl font-bold font-mono-data ${k.color}`}>{k.value}</p><p className="mt-1 text-xs font-semibold text-foreground">{k.label}</p><p className="mt-1 text-[10px] text-muted-foreground">{k.note}</p>
            </div>
          ))}
        </div>

        {/* Charts row 1 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Status Pie */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Estado de Activos</h3>
            {byStatus.length > 0 ? (
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={byStatus} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value">
                    {byStatus.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => [v, 'Equipos']} contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">Sin datos</div>}
            <div className="space-y-1.5 mt-2">
              {byStatus.map(s => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} /><span className="text-muted-foreground">{s.name}</span></div>
                  <span className="font-medium text-foreground">{s.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* By Type */}
          <div className="bg-card border border-border rounded-xl p-5 md:col-span-2">
            <h3 className="text-sm font-semibold text-foreground mb-4">Activos por Tipo de Equipo</h3>
            {byType.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={byType} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                  <Bar dataKey="value" name="Equipos" radius={[4, 4, 0, 0]}>
                    {byType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">Sin datos</div>}
          </div>
        </div>

        {/* Charts row 2 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* By Brand */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Distribución por Marca</h3>
            {byBrand.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={byBrand} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} width={70} />
                  <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                  <Bar dataKey="value" name="Equipos" fill="#6366f1" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">Sin datos</div>}
          </div>

          {/* By Area */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Activos por Área</h3>
            {byArea.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={byArea} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} width={80} />
                  <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                  <Bar dataKey="value" name="Equipos" fill="#14b8a6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">Sin datos</div>}
          </div>
        </div>

        {/* Charts row 3 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Registration trend */}
          <div className="bg-card border border-border rounded-xl p-5 md:col-span-2">
            <h3 className="text-sm font-semibold text-foreground mb-4">Tendencia de Registros</h3>
            {registrationTrend.length > 0 ? (
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={registrationTrend} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                  <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                  <Line type="monotone" dataKey="count" name="Registros" stroke="#6366f1" strokeWidth={2} dot={{ fill: '#6366f1', r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">Sin datos de tendencia</div>}
          </div>

          {/* Top users */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2"><Users size={14} />Top Usuarios</h3>
            <div className="space-y-3">
              {topUsers.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4">Sin datos</p>
              ) : topUsers.map(([user, count], i) => (
                <div key={user} className="flex items-center gap-3">
                  <span className="text-xs font-bold text-muted-foreground w-4">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{user}</p>
                    <div className="mt-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${(count / (topUsers[0]?.[1] || 1)) * 100}%` }} />
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-foreground">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* OS & Location */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Sistemas Operativos</h3>
            <div className="space-y-2">
              {byOS.map((os, i) => (
                <div key={os.name} className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-muted-foreground flex-1 truncate">{os.name}</span>
                  <div className="w-24 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(os.value / (byOS[0]?.value || 1)) * 100}%`, backgroundColor: COLORS[i % COLORS.length] }} />
                  </div>
                  <span className="text-xs font-semibold text-foreground w-6 text-right">{os.value}</span>
                </div>
              ))}
              {byOS.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Sin datos</p>}
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2"><MapPin size={14} />Top Ubicaciones</h3>
            <div className="space-y-2">
              {byLocation.map((loc, i) => (
                <div key={loc.name} className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-muted-foreground flex-1 truncate">{loc.name}</span>
                  <div className="w-24 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(loc.value / (byLocation[0]?.value || 1)) * 100}%`, backgroundColor: COLORS[i % COLORS.length] }} />
                  </div>
                  <span className="text-xs font-semibold text-foreground w-6 text-right">{loc.value}</span>
                </div>
              ))}
              {byLocation.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Sin datos</p>}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
