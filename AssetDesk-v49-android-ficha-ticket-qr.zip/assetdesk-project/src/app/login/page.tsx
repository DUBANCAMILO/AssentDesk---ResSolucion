'use client';

import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Loader2, LockKeyhole, Mail, ShieldCheck } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';
import { useAuth } from '@/contexts/AuthContext';

export default function LoginPage() {
  const router = useRouter();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    setSaving(true);
    try {
      await signIn(email.trim(), password);
      router.replace('/');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No se pudo iniciar sesión.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <main className="min-h-screen bg-background flex items-center justify-center px-4 py-8">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background pointer-events-none" />
      <section className="relative w-full max-w-md rounded-3xl border border-border bg-card/95 p-7 shadow-2xl shadow-primary/10">
        <div className="flex flex-col items-center text-center mb-7">
          <AppLogo size={56} />
          <h1 className="mt-4 text-2xl font-bold text-foreground">Bienvenido a AssetDesk</h1>
          <p className="mt-1 text-sm text-muted-foreground">Gestión centralizada de activos TI</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block space-y-1.5">
            <span className="text-xs font-semibold text-foreground">Correo electrónico</span>
            <span className="relative block">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="tu@empresa.com" className="w-full rounded-xl border border-border bg-secondary py-3 pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary" />
            </span>
          </label>
          <label className="block space-y-1.5">
            <span className="text-xs font-semibold text-foreground">Contraseña</span>
            <span className="relative block">
              <LockKeyhole size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input required minLength={6} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Tu contraseña" className="w-full rounded-xl border border-border bg-secondary py-3 pl-9 pr-10 text-sm text-foreground outline-none focus:border-primary" />
              <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}>
                {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </span>
          </label>
          {error && <p className="rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-xs text-red-300">{error}</p>}
          <button disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-50">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <ShieldCheck size={16} />}
            {saving ? 'Ingresando...' : 'Ingresar'}
          </button>
        </form>
        <div className="mt-6 border-t border-border pt-5 text-center">
          <p className="text-xs text-muted-foreground">¿Es tu primera vez?</p>
          <Link href="/registro" className="mt-1 inline-block text-sm font-semibold text-primary hover:underline">Crear cuenta</Link>
        </div>
      </section>
    </main>
  );
}
