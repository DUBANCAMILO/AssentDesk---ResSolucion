import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type AssetRecord = Record<string, unknown>;

type RouteContext = { params: Promise<{ id: string }> };

const text = (value: unknown): string => {
  if (value === null || value === undefined || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'Sí' : 'No';
  return String(value);
};

const label = (key: string): string => key
  .replace(/_/g, ' ')
  .replace(/\b\w/g, (character) => character.toUpperCase());

export async function GET(_request: Request, context: RouteContext) {
  const { id } = await context.params;
  const supabase = await createClient();
  const { data: asset, error } = await supabase
    .from('assets')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error || !asset) {
    return NextResponse.json({ error: 'Activo no encontrado' }, { status: 404 });
  }

  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const record = asset as AssetRecord;
  const pageWidth = 210;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;
  let y = 45;

  const addPageIfNeeded = (height = 12) => {
    if (y + height <= 276) return;
    doc.addPage();
    y = margin;
  };

  const drawSection = (title: string, fields: Array<[string, unknown]>) => {
    const validFields = fields.filter(([, value]) => value !== null && value !== undefined && value !== '');
    if (validFields.length === 0) return;
    addPageIfNeeded(18);
    doc.setFillColor(239, 246, 255);
    doc.setDrawColor(191, 219, 254);
    doc.roundedRect(margin, y, contentWidth, 8, 1.5, 1.5, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 64, 175);
    doc.text(title.toUpperCase(), margin + 4, y + 5.3);
    y += 11;

    validFields.forEach(([field, value], index) => {
      const valueText = text(value);
      const lines = doc.splitTextToSize(valueText, contentWidth - 63).slice(0, 3) as string[];
      const rowHeight = Math.max(7, lines.length * 4 + 3);
      addPageIfNeeded(rowHeight + 2);
      if (index % 2 === 0) {
        doc.setFillColor(249, 250, 253);
        doc.rect(margin, y - 2, contentWidth, rowHeight, 'F');
      }
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(field, margin + 3, y + 3.2);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text(lines, margin + 58, y + 3.2);
      doc.setDrawColor(226, 232, 240);
      doc.line(margin, y + rowHeight - 2, margin + contentWidth, y + rowHeight - 2);
      y += rowHeight;
    });
    y += 5;
  };

  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 35, 'F');
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 32, pageWidth, 3, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(17);
  doc.text('AssetDesk', margin, 14);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(191, 219, 254);
  doc.text('FICHA TÉCNICA COMPLETA DEL ACTIVO', margin, 21);
  doc.setFontSize(8);
  doc.text(`Generado: ${new Date().toLocaleString('es-CO')}`, margin, 28);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(text(record.placa || record.tag || record.id), pageWidth - margin, 15, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(191, 219, 254);
  doc.text(text(record.status || 'Sin estado'), pageWidth - margin, 22, { align: 'right' });

  drawSection('Identificación', [
    ['Placa de inventario', record.placa], ['TAG', record.tag], ['Marca', record.marca],
    ['Modelo', record.modelo], ['Serial', record.serial], ['Tipo de equipo', record.tipo_equipo],
    ['Estado', record.status], ['Sede', record.sede],
  ]);
  drawSection('Asignación y ubicación', [
    ['Usuario responsable', record.usuario_responsable], ['Área', record.area], ['Ubicación', record.ubicacion],
    ['Técnico instalador', record.tecnico_instalador], ['Fecha de asignación', record.fecha_asignacion],
    ['Proveedor', record.proveedor], ['Vencimiento de garantía', record.garantia_vencimiento],
  ]);
  drawSection('Especificaciones técnicas', [
    ['Sistema operativo', record.sistema_operativo], ['Arquitectura', record.arquitectura],
    ['Procesador', [record.procesador_marca, record.procesador_tipo, record.procesador_velocidad].filter(Boolean).join(' ')],
    ['Memoria RAM', [record.ram_capacidad, record.ram_tipo].filter(Boolean).join(' ')],
    ['Disco', [record.disco_capacidad, record.disco_tecnologia].filter(Boolean).join(' ')],
    ['GPU', [record.gpu_marca, record.gpu_modelo, record.gpu_vram].filter(Boolean).join(' ')],
    ['Versión de Office', record.office_version], ['Antivirus', record.antivirus],
  ]);
  drawSection('Red y conectividad', [
    ['Nombre del equipo', record.nombre_equipo], ['Dirección IP', record.direccion_ip],
    ['MAC Address', record.mac_address], ['Subred', record.subred], ['Gateway', record.gateway],
    ['DNS primario', record.dns_primario], ['DNS secundario', record.dns_secundario],
    ['Puerto de switch', record.puerto_switch],
  ]);
  drawSection('Periféricos y observaciones', [
    ['Monitor', [record.monitor_marca, record.monitor_modelo, record.monitor_tamano].filter(Boolean).join(' ')],
    ['Teclado', record.teclado_marca], ['Mouse', record.mouse_marca], ['Web Cam', record.web_cam],
    ['Impresora', [record.impresora_marca, record.impresora_modelo].filter(Boolean).join(' ')],
    ['Observaciones', record.observaciones], ['Recomendaciones', record.recomendaciones],
  ]);

  const totalPages = doc.getNumberOfPages();
  for (let page = 1; page <= totalPages; page += 1) {
    doc.setPage(page);
    doc.setFillColor(248, 250, 252);
    doc.rect(0, 285, pageWidth, 12, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text('AssetDesk · Ficha técnica completa', margin, 291);
    doc.text(`Página ${page} de ${totalPages}`, pageWidth - margin, 291, { align: 'right' });
  }

  const pdf = doc.output('arraybuffer');
  const safeName = String(record.placa || record.tag || id).replace(/[^a-zA-Z0-9_-]/g, '_');
  return new NextResponse(pdf, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="ficha_${safeName}.pdf"`,
      'Cache-Control': 'no-store',
    },
  });
}
