import { createBrowserClient, type CookieOptions } from '@supabase/ssr';

type CookieToSet = { name: string; value: string; options: CookieOptions };

const PFX = 'sb_';

const canUseCookies = (() => {
  let cache: boolean | null = null;
  return () => {
    if (typeof document === 'undefined') return false;
    if (cache !== null) return cache;
    const k = '__sb_test__';
    document.cookie = `${k}=1; Path=/; SameSite=None; Secure`;
    cache = document.cookie.includes(k);
    document.cookie = `${k}=; Path=/; Max-Age=0; SameSite=None; Secure`;
    return cache;
  };
})();

const fromCookies = () =>
  typeof document === 'undefined' ? [] :
  document.cookie.split(';').filter(Boolean).map((c) => {
    const idx = c.trim().indexOf('=');
    const name = idx >= 0 ? c.trim().slice(0, idx) : c.trim();
    const value = idx >= 0 ? decodeURIComponent(c.trim().slice(idx + 1)) : '';
    return { name: name.trim(), value };
  }).filter((c) => c.name);

const fromStorage = () => {
  try {
    return Object.keys(localStorage)
      .filter((k) => k.startsWith(PFX))
      .map((k) => ({ name: k.slice(PFX.length), value: localStorage.getItem(k) || '' }));
  } catch { return []; }
};

const setCookie = (name: string, value: string, options?: Record<string, unknown>) => {
  let s = `${name}=${encodeURIComponent(value)}; Path=${(options?.path as string) || '/'}; SameSite=None; Secure`;
  if (options?.maxAge) s += `; Max-Age=${options.maxAge}`;
  document.cookie = s;
};

const deleteCookie = (name: string) => {
  if (typeof document === 'undefined') return;
  document.cookie = `${name}=; Max-Age=0; Path=/; SameSite=None; Secure`;
};

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      db: { schema: 'public' },
      cookies: {
        getAll: () => canUseCookies() ? fromCookies() : fromStorage(),
        setAll(cookiesToSet: CookieToSet[]) {
          if (typeof document === 'undefined') return;
          if (canUseCookies()) {
            cookiesToSet.forEach(({ name, value, options }) =>
              value ? setCookie(name, value, options as unknown as Record<string, unknown>) : deleteCookie(name)
            );
          } else {
            cookiesToSet.forEach(({ name, value, options }) => {
              try {
                if (value) localStorage.setItem(`${PFX}${name}`, value);
                else localStorage.removeItem(`${PFX}${name}`);
              } catch (error) {
                console.warn('No se pudo actualizar la sesión local de Supabase', error);
              }
              if (value) setCookie(name, value, options as unknown as Record<string, unknown>);
            });
          }
        },
      },
    }
  );
}
