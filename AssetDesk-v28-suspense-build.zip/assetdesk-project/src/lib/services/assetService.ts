import { createClient } from '@/lib/supabase/client';

// Date fields that must never be sent as empty strings to Postgres
const DATE_FIELDS: (keyof Asset)[] = ['fecha_asignacion', 'garantia_vencimiento', 'fecha_compra'];

function sanitizeDates<T extends Partial<Asset>>(asset: T): T {
  const result = { ...asset } as unknown as Record<string, unknown>;
  for (const field of DATE_FIELDS) {
    if (field in result && (result[field] === '' || result[field] === undefined)) {
      result[field] = null;
    }
  }
  return result as T;
}

function normalizeIP(value?: string | null): string {
  return (value || '').trim();
}

function deviceTypeForAsset(asset: Pick<Asset, 'tipo_equipo'>): string {
  const type = (asset.tipo_equipo || '').toLowerCase();
  if (type.includes('impresora') || type.includes('printer')) return 'Impresora';
  if (type.includes('server') || type.includes('servidor')) return 'Servidor';
  if (type.includes('router')) return 'Router';
  return 'PC';
}

async function releaseIPForAsset(ip: string, assetId: string): Promise<void> {
  const normalized = normalizeIP(ip);
  if (!normalized) return;
  const supabase = createClient();
  const { data } = await supabase
    .from('ip_addresses')
    .select('id, asset_id')
    .eq('direccion_ip', normalized)
    .maybeSingle();
  // Never release an IP that belongs to another asset.
  if (!data || (data.asset_id && data.asset_id !== assetId)) return;
  await supabase.from('ip_addresses').update({
    asset_id: null,
    status: 'disponible',
    nombre: '',
    area: '',
    tipo_dispositivo: 'PC',
    mac_address: '',
    observaciones: 'IP liberada al quitarla del equipo',
  }).eq('id', data.id);
}

/** Keep an asset IP and the IP-management registry synchronized in both directions. */
async function syncAssetIP(asset: Asset, previousIP?: string): Promise<void> {
  const current = normalizeIP(asset.direccion_ip);
  const previous = normalizeIP(previousIP);
  if (previous && previous !== current) await releaseIPForAsset(previous, asset.id);
  if (!current) {
    if (previous) await releaseIPForAsset(previous, asset.id);
    return;
  }

  const supabase = createClient();
  const { data: existing } = await supabase
    .from('ip_addresses')
    .select('id, asset_id, status')
    .eq('direccion_ip', current)
    .maybeSingle();

  // Do not silently steal an occupied IP from another linked asset.
  if (existing?.status === 'ocupada' && existing.asset_id && existing.asset_id !== asset.id) {
    console.error(`IP ${current} ya está vinculada a otro activo`);
    return;
  }

  const payload = {
    asset_id: asset.id,
    direccion_ip: current,
    nombre: asset.nombre_equipo || asset.placa || `${asset.marca || ''} ${asset.modelo || ''}`.trim(),
    area: asset.area || '',
    tipo_dispositivo: deviceTypeForAsset(asset),
    mac_address: asset.mac_address || '',
    subred: asset.subred || '255.255.255.0',
    gateway: asset.gateway || '192.168.1.1',
    dns_primario: asset.dns_primario || '',
    dns_secundario: asset.dns_secundario || '',
    puerto_switch: asset.puerto_switch || '',
    tipo_asignacion: 'Estática',
    status: 'ocupada',
    observaciones: `Asignada automáticamente al activo ${asset.placa || asset.id}`,
  };

  if (existing) await supabase.from('ip_addresses').update(payload).eq('id', existing.id);
  else await supabase.from('ip_addresses').insert(payload);
}

export interface Asset {
  id: string;
  placa?: string;
  tag?: string;
  serial?: string;
  n_ficha?: string;
  sede?: string;
  marca?: string;
  modelo?: string;
  n_producto?: string;
  tipo_equipo?: string;
  sistema_operativo?: string;
  service_pack?: string;
  idioma?: string;
  arquitectura?: string;
  licencia_os?: string;
  procesador_marca?: string;
  procesador_tipo?: string;
  procesador_velocidad?: string;
  procesador_nucleos?: string;
  procesador_generacion?: string;
  ram_capacidad?: string;
  ram_tipo?: string;
  ram_slot?: string;
  ram_slots_totales?: string;
  ram_slots_libres?: string;
  disco_capacidad?: string;
  disco_tecnologia?: string;
  disco_interfaz?: string;
  disco_rpm?: string;
  disco2_capacidad?: string;
  disco2_tecnologia?: string;
  unidad_optica?: string;
  unidad_marca?: string;
  teclado_marca?: string;
  mouse_marca?: string;
  web_cam?: string;
  monitor_marca?: string;
  monitor_modelo?: string;
  monitor_tipo?: string;
  monitor_tamano?: string;
  monitor_serial?: string;
  impresora_marca?: string;
  impresora_tipo?: string;
  impresora_serial?: string;
  impresora_modelo?: string;
  impresora_mac?: string;
  nombre_equipo?: string;
  en_red?: string;
  direccion_ip?: string;
  mac_address?: string;
  subred?: string;
  gateway?: string;
  dns_primario?: string;
  dns_secundario?: string;
  puerto_switch?: string;
  usuario_responsable?: string;
  area?: string;
  ubicacion?: string;
  fecha_asignacion?: string;
  tecnico_instalador?: string;
  numero_inventario_anterior?: string;
  garantia_vencimiento?: string;
  garantia_tipo?: string;
  proveedor?: string;
  orden_compra?: string;
  valor_compra?: number;
  fecha_compra?: string;
  office_version?: string;
  antivirus?: string;
  software_adicional?: string;
  gpu_marca?: string;
  gpu_modelo?: string;
  gpu_vram?: string;
  gpu_tipo?: string;
  display_tamano?: string;
  display_resolucion?: string;
  display_tipo?: string;
  display_frecuencia?: string;
  display_tactil?: string;
  bateria_estado?: string;
  bateria_ciclos?: string;
  bateria_capacidad?: string;
  bateria_modelo?: string;
  firmware_version?: string;
  bios_version?: string;
  tpm_version?: string;
  secure_boot?: string;
  puertos_usb?: string;
  puertos_usb_c?: string;
  puertos_hdmi?: string;
  puertos_thunderbolt?: string;
  lector_tarjetas?: string;
  bluetooth?: string;
  wifi_estandar?: string;
  foto_url?: string;
  status?: 'operational' | 'critical' | 'maintenance' | 'decommissioned';
  etiqueta_estado?: string;
  observaciones?: string;
  recomendaciones?: string;
  has_qr?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface AssetHistory {
  id: string;
  asset_id: string;
  event_type: string;
  description: string;
  by_user?: string;
  created_at: string;
}

export interface BajaFormInput {
  motivo: string;
  observaciones: string;
  tecnico: string;
  disposicion: string;
  valoracion_tecnica?: string;
  frecuencia_trabajo?: string;
  factores?: {
    mantenimiento_correctivo?: boolean;
    repuestos_no_comerciales?: boolean;
    costo_reparacion_70?: boolean;
    ciclo_vida?: boolean;
    hurto?: boolean;
    riesgo_usuario?: boolean;
  };
}

export interface WifiNetwork {
  id: string;
  nombre: string;
  ssid: string;
  password?: string;
  seguridad: string;
  banda: string;
  canal?: string;
  velocidad_max?: string;
  router_marca?: string;
  router_modelo?: string;
  router_ip?: string;
  area?: string;
  sede?: string;
  status: string;
  observaciones?: string;
  created_at?: string;
  updated_at?: string;
}

export const assetService = {
  async getAll(): Promise<Asset[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('assets')
      .select('*')
      .neq('status', 'decommissioned')
      .order('created_at', { ascending: false });
    if (error) { console.error('assetService.getAll:', error.message); return []; }
    return data || [];
  },

  async getById(id: string): Promise<Asset | null> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('assets')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) { console.error('assetService.getById:', error.message); return null; }
    return data;
  },

  async getByPlaca(placa: string): Promise<Asset | null> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('assets')
      .select('*')
      .eq('placa', placa)
      .maybeSingle();
    if (error) { console.error('assetService.getByPlaca:', error.message); return null; }
    return data;
  },

  /** Fast QR lookup without loading the entire inventory into the browser. */
  async getByIdentifier(value: string): Promise<Asset | null> {
    const key = value.trim();
    if (!key) return null;
    const byId = await this.getById(key);
    if (byId) return byId;
    const byPlaca = await this.getByPlaca(key);
    if (byPlaca) return byPlaca;
    const supabase = createClient();
    const { data: bySerial } = await supabase.from('assets').select('*').eq('serial', key).maybeSingle();
    if (bySerial) return bySerial;
    const { data: byTag } = await supabase.from('assets').select('*').eq('tag', key).maybeSingle();
    return byTag;
  },

  async create(asset: Omit<Asset, 'id' | 'created_at' | 'updated_at'>): Promise<Asset | null> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('assets')
      .insert(sanitizeDates(asset))
      .select()
      .single();
    if (error) { console.error('assetService.create:', error.message); return null; }
    if (data) {
      await syncAssetIP(data);
      await supabase.from('asset_history').insert({
        asset_id: data.id,
        event_type: 'created',
        description: `Equipo registrado: ${data.marca} ${data.modelo}`,
        by_user: 'Admin',
      });
      await supabase.from('notifications').insert({
        title: 'Equipo Registrado',
        message: `${data.marca} ${data.modelo} (${data.placa}) agregado al inventario`,
        type: 'success',
        asset_id: data.id,
      });
    }
    return data;
  },

  async update(id: string, asset: Partial<Asset>): Promise<Asset | null> {
    const supabase = createClient();
    const previous = await this.getById(id);
    const { data, error } = await supabase
      .from('assets')
      .update(sanitizeDates(asset))
      .eq('id', id)
      .select()
      .single();
    if (error) { console.error('assetService.update:', error.message); return null; }
    if (data) {
      await syncAssetIP(data, previous?.direccion_ip);
      await supabase.from('asset_history').insert({
        asset_id: id,
        event_type: 'updated',
        description: 'Información del equipo actualizada',
        by_user: 'Admin',
      });
      if (asset.status === 'critical') {
        await supabase.from('notifications').insert({
          title: 'Equipo Crítico',
          message: `${data.marca} ${data.modelo} (${data.placa}) cambió a estado crítico`,
          type: 'critical',
          asset_id: id,
        });
      }
    }
    return data;
  },

  async moveToBaja(id: string, form: BajaFormInput): Promise<string | null> {
    const supabase = createClient();
    const asset = await this.getById(id);
    if (!asset) return null;

    const documentNo = `BAJA-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    const factors = form.factores || {};
    // Insert the historical columns first so the app remains compatible until
    // the additive migration is applied. Extended institutional fields follow.
    const { data: bajaRow, error: bajaError } = await supabase.from('bajas').insert({
      asset_id: id,
      acta_numero: documentNo,
      placa: asset.placa,
      tag: asset.tag,
      brand: asset.marca,
      model: asset.modelo,
      serial: asset.serial,
      cpu: `${asset.procesador_marca || ''} ${asset.procesador_tipo || ''}`.trim(),
      ram: asset.ram_capacidad,
      storage: asset.disco_capacidad,
      os: asset.sistema_operativo,
      location: asset.ubicacion,
      last_user: asset.usuario_responsable,
      area: asset.area,
      motivo_baja: form.motivo,
      tecnico_responsable: form.tecnico,
      observaciones: form.observaciones,
      disposicion: form.disposicion,
    }).select('id').single();
    if (bajaError || !bajaRow) { console.error('moveToBaja baja:', bajaError?.message); return null; }

    // These columns are supplied by the new institutional-forms migration.
    // If a deployment has not applied it yet, the base baja remains valid.
    await supabase.from('bajas').update({
      reporte_no: documentNo,
      cantidad: 1,
      ubicacion: asset.ubicacion,
      responsable_analisis_nombre: form.tecnico,
      valoracion_tecnica: form.valoracion_tecnica || '',
      frecuencia_trabajo: form.frecuencia_trabajo || null,
      factor_mantenimiento_correctivo: !!factors.mantenimiento_correctivo,
      factor_repuestos_no_comerciales: !!factors.repuestos_no_comerciales,
      factor_costo_reparacion_70: !!factors.costo_reparacion_70,
      factor_ciclo_vida: !!factors.ciclo_vida,
      factor_hurto: !!factors.hurto,
      factor_riesgo_usuario: !!factors.riesgo_usuario,
    }).eq('id', bajaRow.id);

    await releaseIPForAsset(asset.direccion_ip || '', id);
    await supabase.from('assets').update({ status: 'decommissioned', direccion_ip: null }).eq('id', id);
    await supabase.from('asset_history').insert({
      asset_id: id,
      event_type: 'baja',
      description: `Dado de baja — Documento ${documentNo}. Motivo: ${form.motivo}. ${form.observaciones}`,
      by_user: form.tecnico || 'Admin',
    });
    await supabase.from('notifications').insert({
      title: 'Equipo Dado de Baja',
      message: `${asset.marca} ${asset.modelo} (${asset.placa}) fue dado de baja. Documento ${documentNo}`,
      type: 'warning',
      asset_id: id,
    });

    return documentNo;
  },

  async getHistory(assetId: string): Promise<AssetHistory[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('asset_history')
      .select('*')
      .eq('asset_id', assetId)
      .order('created_at', { ascending: false });
    if (error) { console.error('assetService.getHistory:', error.message); return []; }
    return data || [];
  },

  async uploadPhoto(assetId: string, file: File): Promise<string | null> {
    const supabase = createClient();
    // Always store as .jpg since we compress to JPEG client-side
    const ext = file.type === 'image/jpeg' ? 'jpg' : (file.name.split('.').pop() || 'jpg');
    const path = `assets/${assetId}/photo.${ext}`;
    const { error } = await supabase.storage
      .from('asset-photos')
      .upload(path, file, { upsert: true, contentType: file.type || 'image/jpeg' });
    if (error) {
      console.error('uploadPhoto:', error.message);
      // Try creating bucket if it doesn't exist yet
      return null;
    }
    const { data } = supabase.storage.from('asset-photos').getPublicUrl(path);
    return data.publicUrl;
  },

  async getMetrics() {
    const supabase = createClient();
    const { data, error } = await supabase.from('assets').select('status');
    if (error) return { total: 0, operational: 0, critical: 0, maintenance: 0 };
    const total = data?.length || 0;
    const operational = data?.filter(a => a.status === 'operational').length || 0;
    const critical = data?.filter(a => a.status === 'critical').length || 0;
    const maintenance = data?.filter(a => a.status === 'maintenance').length || 0;
    return { total, operational, critical, maintenance };
  },
};

export const bajaService = {
  async getAll() {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('bajas')
      .select('*')
      .order('fecha_baja', { ascending: false });
    if (error) { console.error('bajaService.getAll:', error.message); return []; }
    return data || [];
  },

  async reactivate(bajaId: string, assetId?: string): Promise<boolean> {
    const supabase = createClient();
    if (assetId) {
      await supabase.from('assets').update({ status: 'maintenance' }).eq('id', assetId);
      await supabase.from('asset_history').insert({
        asset_id: assetId,
        event_type: 'reactivated',
        description: 'Equipo reactivado desde módulo de bajas',
        by_user: 'Admin',
      });
    }
    const { error } = await supabase.from('bajas').delete().eq('id', bajaId);
    return !error;
  },
};

export interface TransferFormInput {
  traslado_no?: string;
  fecha: string;
  servicio_origen: string;
  servicio_destino: string;
  motivo: string;
  area_realiza: string;
  area_otro?: string;
  asset_id?: string;
  nombre_bien: string;
  placa_inventario?: string;
  cantidad: number;
  marca?: string;
  modelo?: string;
  serial?: string;
  estado?: 'bueno' | 'regular' | 'malo';
  vobo_subgerencia: boolean;
  observaciones?: string;
}

export const transferService = {
  async getAll() {
    const supabase = createClient();
    const { data, error } = await supabase.from('traslados').select('*').order('created_at', { ascending: false });
    if (error) { console.error('transferService.getAll:', error.message); return []; }
    return data || [];
  },

  async create(form: TransferFormInput) {
    const supabase = createClient();
    const trasladoNo = form.traslado_no || `TRAS-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    const { data, error } = await supabase.from('traslados').insert({ ...form, traslado_no: trasladoNo, status: 'completado' }).select().single();
    if (error) {
      console.error('transferService.create:', error.message);
      throw new Error(`No se pudo guardar el traslado: ${error.message}`);
    }
    if (data?.asset_id) {
      const assetUpdate: Partial<Asset> = { area: form.servicio_destino };
      const { error: assetError } = await supabase.from('assets').update(assetUpdate).eq('id', data.asset_id);
      if (!assetError) {
        await supabase.from('asset_history').insert({
          asset_id: data.asset_id,
          event_type: 'transferred',
          description: `Traslado ${trasladoNo}: ${form.servicio_origen} → ${form.servicio_destino}`,
          by_user: 'Gestión de Recursos Físicos',
        });
      }
    }
    return data;
  },
};

export const notificationService = {
  async getAll() {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) { console.error('notificationService.getAll:', error.message); return []; }
    return data || [];
  },

  async markRead(id: string) {
    const supabase = createClient();
    await supabase.from('notifications').update({ read: true }).eq('id', id);
  },

  async markAllRead() {
    const supabase = createClient();
    await supabase.from('notifications').update({ read: true }).eq('read', false);
  },

  async getUnreadCount(): Promise<number> {
    const supabase = createClient();
    const { count } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('read', false);
    return count || 0;
  },

  subscribeToNew(callback: (notification: Record<string, unknown>) => void) {
    const supabase = createClient();
    return supabase
      .channel('notifications_new')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, (payload) => {
        callback(payload.new as unknown as Record<string, unknown>);
      })
      .subscribe();
  },
};

export const settingsService = {
  async getAll() {
    const supabase = createClient();
    const { data, error } = await supabase.from('app_settings').select('*').order('category');
    if (error) { console.error('settingsService.getAll:', error.message); return []; }
    return data || [];
  },

  async update(key: string, value: string) {
    const supabase = createClient();
    const { error } = await supabase
      .from('app_settings')
      .update({ value, updated_at: new Date().toISOString() })
      .eq('key', key);
    return !error;
  },

  async getByKey(key: string): Promise<string | null> {
    const supabase = createClient();
    const { data } = await supabase.from('app_settings').select('value').eq('key', key).maybeSingle();
    return data?.value || null;
  },
};

export const ipService = {
  async getByAddress(address: string) {
    const normalized = normalizeIP(address);
    if (!normalized) return null;
    const supabase = createClient();
    const { data, error } = await supabase
      .from('ip_addresses')
      .select('*')
      .eq('direccion_ip', normalized)
      .maybeSingle();
    if (error) {
      console.error('ipService.getByAddress:', error.message);
      return null;
    }
    return data;
  },

  async getAll() {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('ip_addresses')
      .select('*')
      .order('direccion_ip');
    if (error) { console.error('ipService.getAll:', error.message); return []; }
    return data || [];
  },

  async create(ip: Record<string, unknown>) {
    const supabase = createClient();
    const { data, error } = await supabase.from('ip_addresses').insert(ip).select().single();
    if (error) { console.error('ipService.create:', error.message); return null; }
    return data;
  },

  async update(id: string, ip: Record<string, unknown>) {
    const supabase = createClient();
    const { data: before } = await supabase.from('ip_addresses').select('*').eq('id', id).maybeSingle();
    const { data, error } = await supabase.from('ip_addresses').update(ip).eq('id', id).select().single();
    if (error) { console.error('ipService.update:', error.message); return null; }

    // Editing an IP from the network module also updates the linked asset.
    const previousAssetId = before?.asset_id as string | undefined;
    const nextAssetId = data?.asset_id as string | undefined;
    if (previousAssetId && previousAssetId !== nextAssetId) {
      const { data: oldAsset } = await supabase.from('assets').select('direccion_ip').eq('id', previousAssetId).maybeSingle();
      if (oldAsset?.direccion_ip === before?.direccion_ip) {
        await supabase.from('assets').update({ direccion_ip: null }).eq('id', previousAssetId);
      }
    }
    if (nextAssetId) {
      const nextIP = data.status === 'ocupada' ? data.direccion_ip : null;
      await supabase.from('assets').update({
        direccion_ip: nextIP,
        ...(data.mac_address !== undefined ? { mac_address: data.mac_address } : {}),
      }).eq('id', nextAssetId);
      await supabase.from('asset_history').insert({
        asset_id: nextAssetId,
        event_type: 'updated',
        description: nextIP ? `IP actualizada desde Gestión de Red: ${nextIP}` : 'IP liberada desde Gestión de Red',
        by_user: 'Gestión de Red',
      });
    }
    return data;
  },

  async delete(id: string) {
    const supabase = createClient();
    const { data: before } = await supabase.from('ip_addresses').select('asset_id, direccion_ip').eq('id', id).maybeSingle();
    const { error } = await supabase.from('ip_addresses').delete().eq('id', id);
    if (!error && before?.asset_id) {
      const { data: asset } = await supabase.from('assets').select('direccion_ip').eq('id', before.asset_id).maybeSingle();
      if (asset?.direccion_ip === before.direccion_ip) {
        await supabase.from('assets').update({ direccion_ip: null }).eq('id', before.asset_id);
        await supabase.from('asset_history').insert({
          asset_id: before.asset_id,
          event_type: 'updated',
          description: 'Registro de IP eliminado; IP retirada del equipo',
          by_user: 'Gestión de Red',
        });
      }
    }
    return !error;
  },
};

export const wifiService = {
  async getAll(): Promise<WifiNetwork[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('wifi_networks')
      .select('*')
      .order('nombre');
    if (error) { console.error('wifiService.getAll:', error.message); return []; }
    return (data || []) as WifiNetwork[];
  },

  async create(wifi: Omit<WifiNetwork, 'id' | 'created_at' | 'updated_at'>): Promise<WifiNetwork | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('wifi_networks').insert(wifi).select().single();
    if (error) { console.error('wifiService.create:', error.message); return null; }
    return data as WifiNetwork;
  },

  async update(id: string, wifi: Partial<WifiNetwork>): Promise<WifiNetwork | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('wifi_networks').update(wifi).eq('id', id).select().single();
    if (error) { console.error('wifiService.update:', error.message); return null; }
    return data as WifiNetwork;
  },

  async delete(id: string): Promise<boolean> {
    const supabase = createClient();
    const { error } = await supabase.from('wifi_networks').delete().eq('id', id);
    return !error;
  },
};

export interface Printer {
  id: string;
  placa?: string;
  nombre: string;
  marca?: string;
  modelo?: string;
  tipo?: string;
  serial?: string;
  mac_address?: string;
  direccion_ip?: string;
  subred?: string;
  gateway?: string;
  dns_primario?: string;
  dns_secundario?: string;
  puerto_switch?: string;
  tipo_asignacion?: string;
  area?: string;
  sede?: string;
  ubicacion?: string;
  usuario_responsable?: string;
  tecnico_instalador?: string;
  proveedor?: string;
  orden_compra?: string;
  garantia_vencimiento?: string;
  garantia_tipo?: string;
  status?: 'operational' | 'maintenance' | 'critical' | 'decommissioned';
  etiqueta_estado?: string;
  en_red?: string;
  observaciones?: string;
  foto_url?: string;
  created_at?: string;
  updated_at?: string;
}

export const printerService = {
  async getAll(): Promise<Printer[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('printers')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) { console.error('printerService.getAll:', error.message); return []; }
    return (data || []) as Printer[];
  },

  async getById(id: string): Promise<Printer | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('printers').select('*').eq('id', id).maybeSingle();
    if (error) { console.error('printerService.getById:', error.message); return null; }
    return data as Printer | null;
  },

  async create(printer: Omit<Printer, 'id' | 'created_at' | 'updated_at'>): Promise<Printer | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('printers').insert(printer).select().single();
    if (error) { console.error('printerService.create:', error.message); return null; }
    // Sync IP
    if (data && printer.direccion_ip?.trim()) {
      await syncPrinterIP(printer.direccion_ip.trim(), printer.nombre, printer.area, printer.mac_address, 'ocupada');
    }
    return data as Printer;
  },

  async update(id: string, printer: Partial<Printer>): Promise<Printer | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('printers').update(printer).eq('id', id).select().single();
    if (error) { console.error('printerService.update:', error.message); return null; }
    // Sync IP
    if (printer.direccion_ip !== undefined) {
      if (printer.direccion_ip?.trim()) {
        await syncPrinterIP(printer.direccion_ip.trim(), printer.nombre || '', printer.area, printer.mac_address, 'ocupada');
      }
    }
    return data as Printer;
  },

  async delete(id: string): Promise<boolean> {
    const supabase = createClient();
    // Get printer first to free IP
    const printer = await this.getById(id);
    if (printer?.direccion_ip?.trim()) {
      try {
        const allIps = await ipService.getAll();
        const existing = (allIps as Array<{ id: string; direccion_ip: string }>).find(
          r => r.direccion_ip === printer.direccion_ip
        );
        if (existing) {
          await ipService.update(existing.id, { status: 'disponible', nombre: '', observaciones: 'Liberada — impresora eliminada' });
        }
      } catch { /* non-blocking */ }
    }
    const { error } = await supabase.from('printers').delete().eq('id', id);
    return !error;
  },
};

export interface Camera {
  id: string;
  nombre: string;
  placa?: string;
  marca?: string;
  modelo?: string;
  tipo?: string;
  serial?: string;
  mac_address?: string;
  direccion_ip?: string;
  subred?: string;
  gateway?: string;
  dns_primario?: string;
  dns_secundario?: string;
  puerto?: string;
  canal_dvr?: string;
  dvr_nvr_asociado?: string;
  resolucion?: string;
  fps?: string;
  vision_nocturna?: string;
  angulo_vision?: string;
  almacenamiento?: string;
  dias_grabacion?: string;
  area?: string;
  sede?: string;
  ubicacion?: string;
  usuario_responsable?: string;
  tecnico_instalador?: string;
  proveedor?: string;
  orden_compra?: string;
  garantia_vencimiento?: string;
  garantia_tipo?: string;
  status?: 'operational' | 'maintenance' | 'critical' | 'decommissioned';
  en_red?: string;
  observaciones?: string;
  created_at?: string;
  updated_at?: string;
}

export interface MaintenanceSchedule {
  id: string;
  asset_type: 'asset' | 'printer' | 'camera';
  asset_id: string;
  asset_name?: string;
  asset_placa?: string;
  tipo_mantenimiento: string;
  descripcion?: string;
  fecha_programada: string;
  fecha_realizado?: string;
  tecnico_asignado?: string;
  estado: 'pendiente' | 'en_proceso' | 'completado' | 'cancelado';
  prioridad: 'baja' | 'media' | 'alta' | 'critica';
  costo_estimado?: number;
  costo_real?: number;
  observaciones?: string;
  alerta_enviada?: boolean;
  created_at?: string;
  updated_at?: string;
}

export const cameraService = {
  async getAll(): Promise<Camera[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('cameras')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) { console.error('cameraService.getAll:', error.message); return []; }
    return (data || []) as Camera[];
  },

  async getById(id: string): Promise<Camera | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('cameras').select('*').eq('id', id).maybeSingle();
    if (error) { console.error('cameraService.getById:', error.message); return null; }
    return data as Camera | null;
  },

  async create(camera: Omit<Camera, 'id' | 'created_at' | 'updated_at'>): Promise<Camera | null> {
    const supabase = createClient();
    const payload = { ...camera, garantia_vencimiento: camera.garantia_vencimiento || null };
    const { data, error } = await supabase.from('cameras').insert(payload).select().single();
    if (error) { console.error('cameraService.create:', error.message); return null; }
    if (data && camera.direccion_ip?.trim()) {
      await syncDeviceIP(camera.direccion_ip.trim(), camera.nombre, camera.area, camera.mac_address, 'ocupada', 'Cámara/DVR');
    }
    return data as Camera;
  },

  async update(id: string, camera: Partial<Camera>): Promise<Camera | null> {
    const supabase = createClient();
    const payload = { ...camera, garantia_vencimiento: camera.garantia_vencimiento || null };
    const { data, error } = await supabase.from('cameras').update(payload).eq('id', id).select().single();
    if (error) { console.error('cameraService.update:', error.message); return null; }
    if (camera.direccion_ip !== undefined && camera.direccion_ip?.trim()) {
      await syncDeviceIP(camera.direccion_ip.trim(), camera.nombre || '', camera.area, camera.mac_address, 'ocupada', 'Cámara/DVR');
    }
    return data as Camera;
  },

  async delete(id: string): Promise<boolean> {
    const supabase = createClient();
    const cam = await this.getById(id);
    if (cam?.direccion_ip?.trim()) {
      try {
        const allIps = await ipService.getAll();
        const existing = (allIps as Array<{ id: string; direccion_ip: string }>).find(r => r.direccion_ip === cam.direccion_ip);
        if (existing) {
          await ipService.update(existing.id, { status: 'disponible', nombre: '', observaciones: 'Liberada — cámara/DVR eliminada' });
        }
      } catch { /* non-blocking */ }
    }
    const { error } = await supabase.from('cameras').delete().eq('id', id);
    return !error;
  },
};

export const maintenanceService = {
  async getAll(): Promise<MaintenanceSchedule[]> {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('maintenance_schedules')
      .select('*')
      .order('fecha_programada', { ascending: true });
    if (error) { console.error('maintenanceService.getAll:', error.message); return []; }
    return (data || []) as MaintenanceSchedule[];
  },

  async getUpcoming(days = 30): Promise<MaintenanceSchedule[]> {
    const supabase = createClient();
    const today = new Date().toISOString().split('T')[0];
    const future = new Date(Date.now() + days * 86400000).toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('maintenance_schedules')
      .select('*')
      .gte('fecha_programada', today)
      .lte('fecha_programada', future)
      .neq('estado', 'completado')
      .neq('estado', 'cancelado')
      .order('fecha_programada', { ascending: true });
    if (error) { console.error('maintenanceService.getUpcoming:', error.message); return []; }
    return (data || []) as MaintenanceSchedule[];
  },

  async getOverdue(): Promise<MaintenanceSchedule[]> {
    const supabase = createClient();
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('maintenance_schedules')
      .select('*')
      .lt('fecha_programada', today)
      .neq('estado', 'completado')
      .neq('estado', 'cancelado')
      .order('fecha_programada', { ascending: true });
    if (error) { console.error('maintenanceService.getOverdue:', error.message); return []; }
    return (data || []) as MaintenanceSchedule[];
  },

  async create(schedule: Omit<MaintenanceSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<MaintenanceSchedule | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('maintenance_schedules').insert(schedule).select().single();
    if (error) {
      console.error('maintenanceService.create:', error.message);
      throw new Error(`No se pudo crear el mantenimiento: ${error.message}`);
    }
    return data as MaintenanceSchedule;
  },

  async update(id: string, schedule: Partial<MaintenanceSchedule>): Promise<MaintenanceSchedule | null> {
    const supabase = createClient();
    const { data, error } = await supabase.from('maintenance_schedules').update(schedule).eq('id', id).select().single();
    if (error) {
      console.error('maintenanceService.update:', error.message);
      throw new Error(`No se pudo actualizar el mantenimiento: ${error.message}`);
    }
    return data as MaintenanceSchedule;
  },

  async delete(id: string): Promise<boolean> {
    const supabase = createClient();
    const { error } = await supabase.from('maintenance_schedules').delete().eq('id', id);
    return !error;
  },
};

async function syncDeviceIP(ip: string, nombre: string, area?: string, mac?: string, status: string = 'ocupada', tipo: string = 'Dispositivo') {
  try {
    const allIps = await ipService.getAll();
    const existing = (allIps as Array<{ id: string; direccion_ip: string }>).find(r => r.direccion_ip === ip);
    if (existing) {
      await ipService.update(existing.id, { status, nombre, area: area || '', tipo_dispositivo: tipo, mac_address: mac || '' });
    } else {
      await ipService.create({
        direccion_ip: ip, nombre, area: area || '', tipo_dispositivo: tipo,
        mac_address: mac || '', subred: '255.255.255.0', gateway: '192.168.1.1',
        tipo_asignacion: 'Estática', status, observaciones: `Asignada a ${tipo}: ${nombre}`,
      });
    }
  } catch { /* non-blocking */ }
}

async function syncPrinterIP(ip: string, nombre: string, area?: string, mac?: string, status: string = 'ocupada') {
  return syncDeviceIP(ip, nombre, area, mac, status, 'Impresora');
}
