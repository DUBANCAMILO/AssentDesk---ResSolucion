/** Single source of truth for QR links across web, Android and future iOS builds. */
export function getSiteUrl(): string {
  const browserOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim().replace(/\/$/, '');
  return browserOrigin || configured || '';
}

export function getAssetQrUrl(assetId: string): string {
  const base = getSiteUrl();
  return `${base}/asset/${encodeURIComponent(assetId)}`;
}
