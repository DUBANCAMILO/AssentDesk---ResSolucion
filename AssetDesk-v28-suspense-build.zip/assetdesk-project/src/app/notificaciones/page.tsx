'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { Bell, CheckCircle, AlertTriangle, Info, Zap, RefreshCw, Check, CheckCheck } from 'lucide-react';
import { notificationService } from '@/lib/services/assetService';
import { createClient } from '@/lib/supabase/client';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  asset_id?: string;
  read: boolean;
  created_at: string;
}

const typeConfig: Record<string, { icon: React.ReactNode; color: string; bg: string; border: string }> = {
  critical: { icon: <AlertTriangle size={14} />, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
  warning: { icon: <Zap size={14} />, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  info: { icon: <Info size={14} />, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  success: { icon: <CheckCircle size={14} />, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const loadNotifications = async () => {
    setLoading(true);
    const data = await notificationService.getAll();
    setNotifications(data as Notification[]);
    setLoading(false);
  };

  useEffect(() => {
    loadNotifications();

    // Real-time subscription
    const supabase = createClient();
    const channel = supabase
      .channel('notifications_realtime')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, (payload) => {
        setNotifications(prev => [payload.new as Notification, ...prev]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'notifications' }, (payload) => {
        setNotifications(prev => prev.map(n => n.id === payload.new.id ? { ...n, ...payload.new as Notification } : n));
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const handleMarkRead = async (id: string) => {
    await notificationService.markRead(id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleMarkAllRead = async () => {
    await notificationService.markAllRead();
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const filtered = filter === 'unread' ? notifications.filter(n => !n.read) : notifications;
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <AppLayout>
      <Topbar title="Notificaciones" subtitle="Alertas y eventos del sistema en tiempo real" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Header metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total', value: notifications.length, color: 'text-foreground', bg: 'bg-secondary' },
            { label: 'Sin Leer', value: unreadCount, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Críticas', value: notifications.filter(n => n.type === 'critical').length, color: 'text-red-400', bg: 'bg-red-500/10' },
            { label: 'Advertencias', value: notifications.filter(n => n.type === 'warning').length, color: 'text-amber-400', bg: 'bg-amber-500/10' },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${m.bg}`}>
                <Bell size={16} className={m.color} />
              </div>
              <div>
                <p className={`text-2xl font-bold font-mono-data ${m.color}`}>{m.value}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{m.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex gap-2">
              {(['all', 'unread'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${filter === f ? 'bg-primary/15 border-primary/30 text-primary' : 'bg-secondary border-border text-muted-foreground hover:text-foreground'}`}>
                  {f === 'all' ? 'Todas' : `Sin leer (${unreadCount})`}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <button onClick={loadNotifications} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
                <RefreshCw size={14} />
              </button>
              {unreadCount > 0 && (
                <button onClick={handleMarkAllRead}
                  className="flex items-center gap-2 px-3 py-1.5 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
                  <CheckCheck size={13} /> Marcar todas leídas
                </button>
              )}
            </div>
          </div>

          <div className="divide-y divide-border/50">
            {loading ? (
              <div className="flex items-center justify-center gap-2 py-12 text-muted-foreground text-sm">
                <RefreshCw size={14} className="animate-spin" /> Cargando notificaciones...
              </div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <CheckCircle size={32} className="text-green-400" />
                <p className="text-sm text-muted-foreground">No hay notificaciones {filter === 'unread' ? 'sin leer' : ''}</p>
              </div>
            ) : filtered.map(notif => {
              const cfg = typeConfig[notif.type] || typeConfig.info;
              return (
                <div key={notif.id} className={`flex items-start gap-4 px-5 py-4 transition-colors hover:bg-secondary/20 ${!notif.read ? 'bg-primary/3' : ''}`}>
                  <div className={`p-2 rounded-xl shrink-0 ${cfg.bg} border ${cfg.border}`}>
                    <span className={cfg.color}>{cfg.icon}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className={`text-sm font-semibold ${!notif.read ? 'text-foreground' : 'text-muted-foreground'}`}>{notif.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{notif.message}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                          {notif.created_at ? new Date(notif.created_at).toLocaleString('es-CO', { dateStyle: 'short', timeStyle: 'short' }) : ''}
                        </span>
                        {!notif.read && (
                          <button onClick={() => handleMarkRead(notif.id)}
                            className="p-1 rounded-lg text-muted-foreground hover:text-green-400 hover:bg-green-500/10 transition-colors" title="Marcar como leída">
                            <Check size={12} />
                          </button>
                        )}
                      </div>
                    </div>
                    {!notif.read && <div className="w-2 h-2 rounded-full bg-primary mt-1" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
