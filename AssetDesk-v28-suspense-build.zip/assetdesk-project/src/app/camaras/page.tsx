'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { Camera, Plus, Search, RefreshCw, Edit2, Trash2, X, Network, AlertTriangle, CheckCircle, AlertCircle, MapPin, ChevronUp, ChevronDown, ChevronsUpDown, Wifi, WifiOff, Video, Shield,  } from 'lucide-react';
import { cameraService, ipService, type Camera as CameraType } from '@/lib/services/assetService';
import { createClient } from '@/lib/supabase/client';

const MARCAS_CAMARA = [
  '', 'Hikvision', 'Dahua', 'Axis', 'Bosch', 'Hanwha (Samsung)', 'Vivotek',
  'Uniview', 'Reolink', 'Amcrest', 'Lorex', 'Swann', 'Foscam', 'Arlo',
  'Nest (Google)', 'Ring', 'Pelco', 'Avigilon', 'Milestone', 'Genetec', 'Otra',
];

const TIPOS_DISPOSITIVO = [
  '', 'Cámara IP', 'Cámara Analógica', 'Cámara PTZ', 'Cámara Domo', 'Cámara Bala',
  'Cámara Fisheye', 'Cámara Térmica', 'Cámara 360°', 'DVR', 'NVR',
  'Videoportero', 'Cámara de Acceso', 'Otro',
];

const RESOLUCIONES = [
  '', '720p (1MP)', '1080p (2MP)', '3MP', '4MP', '5MP', '6MP', '8MP (4K)', '12MP', '4K Ultra HD', 'Analógica', 'Otra',
];

const STATUS_LABELS: Record<string, string> = {
  operational: 'Operativo', maintenance: 'Mantenimiento', critical: 'Crítico', decommissioned: 'Dado de Baja',
};
const STATUS_COLORS: Record<string, string> = {
  operational: 'text-green-400 bg-green-500/10 border-green-500/20',
  maintenance: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  critical: 'text-red-400 bg-red-500/10 border-red-500/20',
  decommissioned: 'text-gray-400 bg-gray-500/10 border-gray-500/20',
};

const EMPTY_FORM: Omit<CameraType, 'id' | 'created_at' | 'updated_at'> = {
  nombre: '', placa: '', marca: '', modelo: '', tipo: '', serial: '',
  mac_address: '', direccion_ip: '', subred: '255.255.255.0', gateway: '192.168.1.1',
  dns_primario: '8.8.8.8', dns_secundario: '8.8.4.4', puerto: '',
  canal_dvr: '', dvr_nvr_asociado: '', resolucion: '', fps: '',
  vision_nocturna: 'SI', angulo_vision: '', almacenamiento: '', dias_grabacion: '',
  area: '', sede: '', ubicacion: '', usuario_responsable: '', tecnico_instalador: '',
  proveedor: '', orden_compra: '', garantia_vencimiento: '', garantia_tipo: '',
  status: 'operational', en_red: 'SI', observaciones: '',
};

type SortKey = 'nombre' | 'marca' | 'area' | 'status' | 'direccion_ip' | 'tipo';
type SortDir = 'asc' | 'desc';

function Field({ label, name, value, onChange, type = 'text', options, span = 1, placeholder }: {
  label: string; name: string; value: string | undefined; onChange: (n: string, v: string) => void;
  type?: string; options?: string[]; span?: number; placeholder?: string;
}) {
  const cls = 'bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full';
  return (
    <div className={span === 2 ? 'col-span-2' : ''}>
      <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">{label}</label>
      {options ? (
        <select name={name} value={value || ''} onChange={e => onChange(name, e.target.value)} className={cls}>
          {options.map(o => <option key={o} value={o}>{o || '— Seleccionar —'}</option>)}
        </select>
      ) : (
        <input type={type} name={name} value={value || ''} onChange={e => onChange(name, e.target.value)}
          className={cls} placeholder={placeholder || label} />
      )}
    </div>
  );
}

export default function CamerasPage() {
  const [cameras, setCameras] = useState<CameraType[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('nombre');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selectedCamera, setSelectedCamera] = useState<CameraType | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingCamera, setEditingCamera] = useState<CameraType | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [ipWarning, setIpWarning] = useState<string | null>(null);

  const loadCameras = useCallback(async () => {
    setLoading(true);
    const data = await cameraService.getAll();
    setCameras(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadCameras();
    const supabase = createClient();
    const channel = supabase
      .channel('cameras_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'cameras' }, () => loadCameras())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadCameras]);

  const handleChange = (name: string, value: string) => {
    setForm(prev => ({ ...prev, [name]: value }));
    if (name === 'direccion_ip') setIpWarning(null);
  };

  const handleIpBlur = async () => {
    const ip = form.direccion_ip?.trim();
    if (!ip) return;
    try {
      const allIps = await ipService.getAll();
      const existing = (allIps as Array<{ direccion_ip: string; status?: string; nombre?: string }>).find(r => r.direccion_ip === ip);
      if (existing && existing.status === 'ocupada') {
        const name = existing.nombre ? ` (${existing.nombre})` : '';
        setIpWarning(`⚠️ Esta IP ya está marcada como "ocupada"${name} en el sistema de gestión de IPs.`);
      } else {
        setIpWarning(null);
      }
    } catch { setIpWarning(null); }
  };

  const openAdd = () => {
    setForm({ ...EMPTY_FORM });
    setEditingCamera(null);
    setSaveError(null);
    setSaveSuccess(false);
    setIpWarning(null);
    setShowForm(true);
  };

  const openEdit = (cam: CameraType) => {
    setForm({
      nombre: cam.nombre || '', placa: cam.placa || '', marca: cam.marca || '',
      modelo: cam.modelo || '', tipo: cam.tipo || '', serial: cam.serial || '',
      mac_address: cam.mac_address || '', direccion_ip: cam.direccion_ip || '',
      subred: cam.subred || '255.255.255.0', gateway: cam.gateway || '192.168.1.1',
      dns_primario: cam.dns_primario || '8.8.8.8', dns_secundario: cam.dns_secundario || '8.8.4.4',
      puerto: cam.puerto || '', canal_dvr: cam.canal_dvr || '',
      dvr_nvr_asociado: cam.dvr_nvr_asociado || '', resolucion: cam.resolucion || '',
      fps: cam.fps || '', vision_nocturna: cam.vision_nocturna || 'SI',
      angulo_vision: cam.angulo_vision || '', almacenamiento: cam.almacenamiento || '',
      dias_grabacion: cam.dias_grabacion || '', area: cam.area || '', sede: cam.sede || '',
      ubicacion: cam.ubicacion || '', usuario_responsable: cam.usuario_responsable || '',
      tecnico_instalador: cam.tecnico_instalador || '', proveedor: cam.proveedor || '',
      orden_compra: cam.orden_compra || '', garantia_vencimiento: cam.garantia_vencimiento || '',
      garantia_tipo: cam.garantia_tipo || '', status: cam.status || 'operational',
      en_red: cam.en_red || 'SI', observaciones: cam.observaciones || '',
    });
    setEditingCamera(cam);
    setSaveError(null);
    setSaveSuccess(false);
    setIpWarning(null);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.nombre.trim()) { setSaveError('El nombre es obligatorio'); return; }
    setSaving(true); setSaveError(null);
    try {
      const payload = { ...form, garantia_vencimiento: form.garantia_vencimiento || undefined };
      let result: CameraType | null;
      if (editingCamera) {
        result = await cameraService.update(editingCamera.id, payload);
      } else {
        result = await cameraService.create(payload);
      }
      if (result) {
        setSaveSuccess(true);
        setTimeout(() => { setShowForm(false); setSaveSuccess(false); setEditingCamera(null); }, 800);
        loadCameras();
      } else {
        setSaveError('No se pudo guardar. Intenta de nuevo.');
      }
    } catch { setSaveError('Error al guardar.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (cam: CameraType) => {
    if (!confirm(`¿Eliminar "${cam.nombre}"?`)) return;
    await cameraService.delete(cam.id);
    setSelectedCamera(null);
    loadCameras();
  };

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  const filtered = useMemo(() => {
    let data = [...cameras];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(c =>
        (c.nombre || '').toLowerCase().includes(q) ||
        (c.marca || '').toLowerCase().includes(q) ||
        (c.modelo || '').toLowerCase().includes(q) ||
        (c.serial || '').toLowerCase().includes(q) ||
        (c.direccion_ip || '').includes(q) ||
        (c.area || '').toLowerCase().includes(q) ||
        (c.tipo || '').toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'all') data = data.filter(c => c.status === statusFilter);
    data.sort((a, b) => {
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [cameras, search, statusFilter, sortKey, sortDir]);

  const metrics = useMemo(() => ({
    total: cameras.length,
    operational: cameras.filter(c => c.status === 'operational').length,
    maintenance: cameras.filter(c => c.status === 'maintenance').length,
    critical: cameras.filter(c => c.status === 'critical').length,
    online: cameras.filter(c => c.en_red === 'SI').length,
  }), [cameras]);

  return (
    <AppLayout>
      <Topbar title="Cámaras y DVR" subtitle="Inventario de sistemas de videovigilancia — Gestión y control" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { label: 'Total Dispositivos', value: metrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Camera },
            { label: 'Operativos', value: metrics.operational, color: 'text-green-400', bg: 'bg-green-500/10', icon: CheckCircle },
            { label: 'Mantenimiento', value: metrics.maintenance, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: AlertCircle },
            { label: 'Críticos', value: metrics.critical, color: 'text-red-400', bg: 'bg-red-500/10', icon: AlertTriangle },
            { label: 'En Red', value: metrics.online, color: 'text-cyan-400', bg: 'bg-cyan-500/10', icon: Wifi },
          ].map(m => {
            const MIcon = m.icon;
            return (
              <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${m.bg} flex items-center justify-center shrink-0`}>
                  <MIcon size={18} className={m.color} />
                </div>
                <div>
                  <p className={`text-xl font-bold ${m.color}`}>{m.value}</p>
                  <p className="text-xs text-muted-foreground">{m.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-48">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por nombre, marca, IP, área..."
              className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
          </div>
          <div className="flex gap-1.5">
            {['all', 'operational', 'maintenance', 'critical'].map(f => (
              <button key={f} onClick={() => setStatusFilter(f)}
                className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${statusFilter === f ? 'bg-primary/15 border-primary/30 text-primary' : 'bg-secondary border-border text-muted-foreground hover:text-foreground'}`}>
                {f === 'all' ? 'Todos' : STATUS_LABELS[f]}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button onClick={loadCameras} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors" title="Recargar">
              <RefreshCw size={14} />
            </button>
            <button onClick={openAdd}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-xs font-medium rounded-lg hover:bg-primary/90 transition-colors">
              <Plus size={14} /> Nuevo Dispositivo
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  {[
                    { key: 'nombre', label: 'Nombre / Placa' },
                    { key: 'tipo', label: 'Tipo' },
                    { key: 'marca', label: 'Marca / Modelo' },
                    { key: 'direccion_ip', label: 'IP' },
                    { key: null, label: 'Resolución' },
                    { key: 'area', label: 'Área / Ubicación' },
                    { key: 'status', label: 'Estado' },
                    { key: null, label: 'Acciones' },
                  ].map((col, i) => (
                    <th key={i} className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider text-[10px] ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                      onClick={() => col.key && handleSort(col.key as SortKey)}>
                      <div className="flex items-center gap-1">
                        {col.label}
                        {col.key && <SortIcon col={col.key as SortKey} />}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                    <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando dispositivos...
                  </td></tr>
                ) : filtered.length === 0 ? (
                  <tr><td colSpan={8} className="px-4 py-12 text-center">
                    <Camera size={32} className="mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">No se encontraron dispositivos</p>
                    <button onClick={openAdd} className="mt-2 text-xs text-primary hover:underline">Registrar primer dispositivo</button>
                  </td></tr>
                ) : filtered.map((cam, idx) => (
                  <tr key={cam.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors cursor-pointer ${idx % 2 === 0 ? '' : 'bg-secondary/10'}`}
                    onClick={() => setSelectedCamera(selectedCamera?.id === cam.id ? null : cam)}>
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground flex items-center gap-2">
                        <Video size={13} className="text-primary shrink-0" />
                        {cam.nombre}
                      </div>
                      {cam.placa && <div className="text-[10px] text-muted-foreground font-mono mt-0.5">{cam.placa}</div>}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{cam.tipo || '—'}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{cam.marca || '—'}</div>
                      <div className="text-[10px] text-muted-foreground">{cam.modelo}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-mono text-muted-foreground">{cam.direccion_ip || '—'}</div>
                      <div className="flex items-center gap-1 mt-0.5">
                        {cam.en_red === 'SI'
                          ? <><Wifi size={10} className="text-green-400" /><span className="text-[10px] text-green-400">En red</span></>
                          : <><WifiOff size={10} className="text-muted-foreground" /><span className="text-[10px] text-muted-foreground">Sin red</span></>
                        }
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      <div>{cam.resolucion || '—'}</div>
                      {cam.fps && <div className="text-[10px]">{cam.fps} FPS</div>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <MapPin size={10} />
                        <span className="truncate max-w-[120px]">{cam.ubicacion || cam.area || '—'}</span>
                      </div>
                      {cam.dvr_nvr_asociado && <div className="text-[10px] text-muted-foreground mt-0.5">DVR: {cam.dvr_nvr_asociado}</div>}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium border ${STATUS_COLORS[cam.status || 'operational']}`}>
                        {STATUS_LABELS[cam.status || 'operational']}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                        <button onClick={() => openEdit(cam)} title="Editar"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                          <Edit2 size={13} />
                        </button>
                        <button onClick={() => handleDelete(cam)} title="Eliminar"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detail panel */}
        {selectedCamera && (
          <div className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Video size={20} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{selectedCamera.nombre}</h3>
                  <p className="text-xs text-muted-foreground">{selectedCamera.tipo} · {selectedCamera.marca} {selectedCamera.modelo}</p>
                </div>
              </div>
              <button onClick={() => setSelectedCamera(null)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors"><X size={14} /></button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              {[
                { label: 'IP', value: selectedCamera.direccion_ip },
                { label: 'MAC', value: selectedCamera.mac_address },
                { label: 'Resolución', value: selectedCamera.resolucion },
                { label: 'FPS', value: selectedCamera.fps },
                { label: 'Visión Nocturna', value: selectedCamera.vision_nocturna },
                { label: 'Canal DVR', value: selectedCamera.canal_dvr },
                { label: 'DVR/NVR', value: selectedCamera.dvr_nvr_asociado },
                { label: 'Almacenamiento', value: selectedCamera.almacenamiento },
                { label: 'Días Grabación', value: selectedCamera.dias_grabacion },
                { label: 'Área', value: selectedCamera.area },
                { label: 'Sede', value: selectedCamera.sede },
                { label: 'Técnico', value: selectedCamera.tecnico_instalador },
                { label: 'Garantía', value: selectedCamera.garantia_vencimiento },
                { label: 'Serial', value: selectedCamera.serial },
              ].map(f => f.value ? (
                <div key={f.label}>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{f.label}</p>
                  <p className="text-foreground font-medium mt-0.5">{f.value}</p>
                </div>
              ) : null)}
            </div>
            {selectedCamera.observaciones && (
              <div className="mt-4 p-3 bg-secondary rounded-lg">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Observaciones</p>
                <p className="text-xs text-foreground">{selectedCamera.observaciones}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Camera size={16} className="text-primary" />
                </div>
                <h2 className="font-semibold text-foreground text-sm">
                  {editingCamera ? 'Editar Dispositivo' : 'Registrar Cámara / DVR'}
                </h2>
              </div>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors"><X size={16} /></button>
            </div>
            <div className="p-6 space-y-6">
              {/* Identificación */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2"><Shield size={12} />Identificación</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Nombre *" name="nombre" value={form.nombre} onChange={handleChange} span={2} />
                  <Field label="Placa / Inventario" name="placa" value={form.placa} onChange={handleChange} />
                  <Field label="Tipo" name="tipo" value={form.tipo} onChange={handleChange} options={TIPOS_DISPOSITIVO} />
                  <Field label="Marca" name="marca" value={form.marca} onChange={handleChange} options={MARCAS_CAMARA} />
                  <Field label="Modelo" name="modelo" value={form.modelo} onChange={handleChange} />
                  <Field label="Serial" name="serial" value={form.serial} onChange={handleChange} />
                  <Field label="Estado" name="status" value={form.status} onChange={handleChange}
                    options={['operational', 'maintenance', 'critical', 'decommissioned']} />
                </div>
              </div>
              {/* Especificaciones */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2"><Video size={12} />Especificaciones de Video</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Resolución" name="resolucion" value={form.resolucion} onChange={handleChange} options={RESOLUCIONES} />
                  <Field label="FPS" name="fps" value={form.fps} onChange={handleChange} placeholder="ej. 25, 30, 60" />
                  <Field label="Visión Nocturna" name="vision_nocturna" value={form.vision_nocturna} onChange={handleChange} options={['SI', 'NO']} />
                  <Field label="Ángulo de Visión" name="angulo_vision" value={form.angulo_vision} onChange={handleChange} placeholder="ej. 90°, 120°" />
                  <Field label="Almacenamiento" name="almacenamiento" value={form.almacenamiento} onChange={handleChange} placeholder="ej. SD 128GB, NVR, Nube" />
                  <Field label="Días de Grabación" name="dias_grabacion" value={form.dias_grabacion} onChange={handleChange} placeholder="ej. 30" />
                  <Field label="Canal DVR/NVR" name="canal_dvr" value={form.canal_dvr} onChange={handleChange} placeholder="ej. Canal 1" />
                  <Field label="DVR/NVR Asociado" name="dvr_nvr_asociado" value={form.dvr_nvr_asociado} onChange={handleChange} placeholder="Nombre del DVR/NVR" />
                </div>
              </div>
              {/* Red */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2"><Network size={12} />Configuración de Red</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="En Red" name="en_red" value={form.en_red} onChange={handleChange} options={['SI', 'NO']} />
                  <div>
                    <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Dirección IP</label>
                    <input
                      type="text" name="direccion_ip" value={form.direccion_ip || ''}
                      onChange={e => handleChange('direccion_ip', e.target.value)}
                      onBlur={handleIpBlur}
                      className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full"
                      placeholder="192.168.1.x" />
                    {ipWarning && <p className="text-[10px] text-amber-400 mt-1">{ipWarning}</p>}
                  </div>
                  <Field label="MAC Address" name="mac_address" value={form.mac_address} onChange={handleChange} />
                  <Field label="Puerto" name="puerto" value={form.puerto} onChange={handleChange} placeholder="ej. 8080, 554" />
                  <Field label="Subred" name="subred" value={form.subred} onChange={handleChange} />
                  <Field label="Gateway" name="gateway" value={form.gateway} onChange={handleChange} />
                </div>
              </div>
              {/* Ubicación */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2"><MapPin size={12} />Ubicación</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Área" name="area" value={form.area} onChange={handleChange} />
                  <Field label="Sede" name="sede" value={form.sede} onChange={handleChange} />
                  <Field label="Ubicación Específica" name="ubicacion" value={form.ubicacion} onChange={handleChange} span={2} />
                  <Field label="Responsable" name="usuario_responsable" value={form.usuario_responsable} onChange={handleChange} />
                  <Field label="Técnico Instalador" name="tecnico_instalador" value={form.tecnico_instalador} onChange={handleChange} />
                </div>
              </div>
              {/* Garantía */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2"><Shield size={12} />Garantía y Compra</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Proveedor" name="proveedor" value={form.proveedor} onChange={handleChange} />
                  <Field label="Orden de Compra" name="orden_compra" value={form.orden_compra} onChange={handleChange} />
                  <Field label="Vencimiento Garantía" name="garantia_vencimiento" value={form.garantia_vencimiento} onChange={handleChange} type="date" />
                  <Field label="Tipo de Garantía" name="garantia_tipo" value={form.garantia_tipo} onChange={handleChange} />
                </div>
              </div>
              {/* Observaciones */}
              <div>
                <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Observaciones</label>
                <textarea name="observaciones" value={form.observaciones || ''} onChange={e => handleChange('observaciones', e.target.value)}
                  rows={3} className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none"
                  placeholder="Notas adicionales..." />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-border sticky bottom-0 bg-card">
              {saveError && <p className="text-xs text-red-400 mr-auto">{saveError}</p>}
              {saveSuccess && <p className="text-xs text-green-400 mr-auto flex items-center gap-1"><CheckCircle size={12} />Guardado correctamente</p>}
              <button onClick={() => setShowForm(false)} className="px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
                Cancelar
              </button>
              <button onClick={handleSave} disabled={saving}
                className="px-5 py-2 text-xs bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center gap-2">
                {saving ? <><RefreshCw size={12} className="animate-spin" />Guardando...</> : 'Guardar Dispositivo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
