import React from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import TicketMetricsRow from './components/TicketMetricsRow';
import TicketTableSection from './components/TicketTableSection';

export default function TicketManagementPage() {
  return (
    <AppLayout>
      <Topbar
        title="Ticket Console"
        subtitle="Incident management and SLA tracking"
      />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">
        <TicketMetricsRow />
        <TicketTableSection />
      </div>
    </AppLayout>
  );
}