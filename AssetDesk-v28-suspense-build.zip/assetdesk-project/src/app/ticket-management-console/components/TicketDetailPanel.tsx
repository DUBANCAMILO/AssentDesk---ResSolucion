'use client';

import React, { useState } from 'react';
import { X, Monitor, MapPin, User, Calendar, Clock, Tag, AlertTriangle, Image as ImageIcon, CheckCircle, Send,  } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';
interface Ticket {
  id: string;
  ticketId: string;
  assetTag: string;
  assetName: string;
  category: string;
  priority: string;
  status: 'open' | 'in-progress' | 'pending-parts' | 'resolved' | 'closed';
  location: string;
  assignee: string;
  created: string;
  slaDue: string;
  slaHoursLeft: number;
  description: string;
  hasFaultPhoto: boolean;
  resolutionType: string | null;
}

const RESOLUTION_TYPES = [
  'Software Reinstall',
  'Component Replacement',
  'Network Reconfiguration',
  'Driver Update',
  'OS Repair',
  'Hardware Swap',
  'Configuration Change',
  'User Training',
];

interface Props {
  ticket: Ticket;
  onClose: () => void;
}

export default function TicketDetailPanel({ ticket, onClose }: Props) {
  const [activeTab, setActiveTab] = useState<'details' | 'notes' | 'resolve'>('details');
  const [note, setNote] = useState('');
  const [selectedResolution, setSelectedResolution] = useState(ticket.resolutionType ?? '');

  const CATEGORY_COLORS: Record<string, string> = {
    hardware: 'bg-amber-500/10 text-amber-400',
    software: 'bg-blue-500/10 text-blue-400',
    network: 'bg-purple-500/10 text-purple-400',
    connectivity: 'bg-cyan-500/10 text-cyan-400',
  };

  const PRIORITY_COLORS: Record<string, string> = {
    critical: 'text-red-400',
    high: 'text-orange-400',
    medium: 'text-amber-400',
    low: 'text-green-400',
  };

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card border-l border-border h-full flex flex-col slide-in-right overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-border flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono-data text-xs text-primary font-semibold">{ticket.ticketId}</span>
              <StatusBadge status={ticket.status} />
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full capitalize ${CATEGORY_COLORS[ticket.category] ?? ''}`}>
                {ticket.category}
              </span>
            </div>
            <h2 className="text-sm font-semibold text-foreground leading-snug max-w-[280px]">
              {ticket.description.slice(0, 60)}...
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors duration-150"
          >
            <X size={16} />
          </button>
        </div>

        {/* SLA banner */}
        {ticket.status !== 'resolved' && ticket.status !== 'closed' && ticket.slaHoursLeft <= 4 && (
          <div className={`px-5 py-2.5 flex items-center gap-2 ${ticket.slaHoursLeft <= 2 ? 'bg-red-500/10 border-b border-red-500/20' : 'bg-amber-500/10 border-b border-amber-500/20'}`}>
            <AlertTriangle size={13} className={ticket.slaHoursLeft <= 2 ? 'text-red-400' : 'text-amber-400'} />
            <span className={`text-xs font-semibold ${ticket.slaHoursLeft <= 2 ? 'text-red-400' : 'text-amber-400'}`}>
              SLA breach in {ticket.slaHoursLeft}h — Due {ticket.slaDue}
            </span>
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-border px-5">
          {(['details', 'notes', 'resolve'] as const).map((tab) => (
            <button
              key={`tab-${tab}`}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-3 text-xs font-medium capitalize transition-colors duration-150 border-b-2 -mb-px ${
                activeTab === tab
                  ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-4">
          {activeTab === 'details' && (
            <>
              <div className="bg-secondary rounded-xl p-4 space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Ticket Info</p>
                {[
                  { icon: Monitor, label: 'Asset', value: `${ticket.assetName} (${ticket.assetTag})` },
                  { icon: MapPin, label: 'Location', value: ticket.location },
                  { icon: User, label: 'Assignee', value: ticket.assignee },
                  { icon: Calendar, label: 'Created', value: ticket.created },
                  { icon: Clock, label: 'SLA Due', value: ticket.slaDue },
                  { icon: Tag, label: 'Priority', value: ticket.priority },
                ].map((row) => {
                  const Icon = row.icon;
                  return (
                    <div key={`detail-${row.label}`} className="flex items-start gap-3">
                      <Icon size={13} className="text-muted-foreground mt-0.5 shrink-0" />
                      <div>
                        <p className="text-[10px] text-muted-foreground">{row.label}</p>
                        <p className={`text-xs font-medium ${row.label === 'Priority' ? PRIORITY_COLORS[ticket.priority] : 'text-foreground'} capitalize`}>
                          {row.value}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="bg-secondary rounded-xl p-4">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Description</p>
                <p className="text-xs text-foreground leading-relaxed">{ticket.description}</p>
              </div>

              {ticket.hasFaultPhoto && (
                <div className="bg-secondary rounded-xl p-4">
                  <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">Fault Photo</p>
                  <div className="bg-muted rounded-lg h-32 flex items-center justify-center border border-dashed border-border">
                    <div className="text-center">
                      <ImageIcon size={24} className="text-muted-foreground/40 mx-auto mb-1" />
                      <p className="text-xs text-muted-foreground">fault_photo_{ticket.ticketId}.jpg</p>
                      <button className="text-[11px] text-primary hover:underline mt-1">View Full Image</button>
                    </div>
                  </div>
                </div>
              )}

              {ticket.resolutionType && (
                <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <CheckCircle size={13} className="text-green-400" />
                    <p className="text-[11px] font-semibold text-green-400 uppercase tracking-wider">Resolution</p>
                  </div>
                  <p className="text-xs text-foreground">{ticket.resolutionType}</p>
                </div>
              )}
            </>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-4">
              <div className="space-y-3">
                {[
                  { id: 'note-1', author: 'Carlos Mendez', time: '2026-07-15 14:32', text: 'Confirmed hardware failure. Running diagnostics now.' },
                  { id: 'note-2', author: 'Pedro Alvarado', time: '2026-07-15 16:10', text: 'Ordered replacement component from procurement. ETA 24h.' },
                ].map((n) => (
                  <div key={n.id} className="bg-secondary rounded-xl p-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-foreground">{n.author}</span>
                      <span className="text-[10px] font-mono-data text-muted-foreground">{n.time}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{n.text}</p>
                  </div>
                ))}
              </div>

              <div className="bg-secondary rounded-xl p-3">
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Add a technical note..."
                  rows={3}
                  className="w-full bg-transparent text-xs text-foreground placeholder:text-muted-foreground outline-none resize-none"
                />
                <div className="flex justify-end mt-2">
                  <button
                    className="flex items-center gap-1.5 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors duration-150 disabled:opacity-40"
                    disabled={!note.trim()}
                    onClick={() => { toast.success('Note added to ticket'); setNote(''); }}
                  >
                    <Send size={11} />
                    Add Note
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'resolve' && (
            <div className="space-y-4">
              <div className="bg-secondary rounded-xl p-4">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">Resolution Type</p>
                <p className="text-xs text-muted-foreground mb-3">
                  Select the type of solution applied. This feeds the knowledge base for future reference.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {RESOLUTION_TYPES.map((rt) => (
                    <button
                      key={`rt-${rt}`}
                      onClick={() => setSelectedResolution(rt)}
                      className={`text-xs px-2.5 py-2 rounded-lg text-left transition-all duration-150 border ${
                        selectedResolution === rt
                          ? 'bg-primary/15 border-primary/40 text-primary' :'bg-muted border-border text-muted-foreground hover:text-foreground hover:border-border/80'
                      }`}
                    >
                      {rt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-secondary rounded-xl p-4">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Resolution Notes</p>
                <textarea
                  placeholder="Describe the steps taken to resolve this incident..."
                  rows={4}
                  className="w-full bg-muted rounded-lg p-3 text-xs text-foreground placeholder:text-muted-foreground outline-none resize-none border border-border"
                />
              </div>

              <button
                className="w-full flex items-center justify-center gap-2 bg-green-500/10 border border-green-500/30 text-green-400 text-sm font-semibold py-3 rounded-xl hover:bg-green-500/20 transition-colors duration-150 disabled:opacity-40"
                disabled={!selectedResolution}
                onClick={() => toast.success(`Ticket ${ticket.ticketId} marked as resolved`)}
              >
                <CheckCircle size={15} />
                Mark as Resolved
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-border flex items-center gap-2">
          <button
            className="flex-1 text-xs bg-secondary text-foreground py-2 rounded-lg font-medium hover:bg-muted transition-colors duration-150"
            onClick={() => toast.success(`Ticket ${ticket.ticketId} assigned to Carlos Mendez`)}
          >
            Assign to Me
          </button>
          <button
            className="flex-1 text-xs bg-primary text-primary-foreground py-2 rounded-lg font-medium hover:bg-primary/90 transition-colors duration-150"
            onClick={() => setActiveTab('resolve')}
          >
            Resolve Ticket
          </button>
        </div>
      </div>
    </div>
  );
}