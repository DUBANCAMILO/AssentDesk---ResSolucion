'use client';

import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

const data = [
  { category: 'HW', count: 12, color: '#f59e0b' },
  { category: 'SW', count: 8, color: '#3b82f6' },
  { category: 'Net', count: 5, color: '#8b5cf6' },
  { category: 'Conn', count: 3, color: '#06b6d4' },
];

type TooltipEntry = { value?: number | string };

type CustomTooltipProps = {
  active?: boolean;
  payload?: TooltipEntry[];
  label?: string;
};

const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
  if (active && payload && payload.length) {
    const labels: Record<string, string> = {
      HW: 'Hardware',
      SW: 'Software',
      Net: 'Network',
      Conn: 'Connectivity',
    };
    return (
      <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-xl">
        <p className="text-xs text-muted-foreground">{labels[label ?? ''] ?? label ?? ''}</p>
        <p className="text-sm font-semibold text-foreground">{payload[0].value} tickets</p>
      </div>
    );
  }
  return null;
};

export default function TicketCategoryChart() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 0, right: 0, left: -32, bottom: 0 }}>
        <XAxis
          dataKey="category"
          tick={{ fontSize: 9, fill: 'var(--muted-foreground)' }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 9, fill: 'var(--muted-foreground)' }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip content={<CustomTooltip />} />
        <Bar dataKey="count" radius={[3, 3, 0, 0]}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.85} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}