'use client';

import React, { useState, useMemo } from 'react';
import { Search, Plus, X, ChevronUp, ChevronDown, ChevronsUpDown, CheckSquare, Square, Eye, UserPlus, Image as ImageIcon, Clock, Ticket } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';
import TicketDetailPanel from './TicketDetailPanel';

// Backend integration point: replace with API call to GET /api/tickets
const ALL_TICKETS = [
  {
    id: 'ticket-001',
    ticketId: 'TKT-2026-089',
    assetTag: 'AST-2024-002',
    assetName: 'HP EliteDesk 800 G6',
    category: 'hardware' as const,
    priority: 'critical' as const,
    status: 'open' as const,
    location: 'Floor 1 — Office 102',
    assignee: 'Unassigned',
    created: '2026-07-15',
    slaDue: '2026-07-16',
    slaHoursLeft: 2,
    description: 'System fails to POST on startup. No video output after power cycle.',
    hasFaultPhoto: true,
    resolutionType: null,
  },
  {
    id: 'ticket-002',
    ticketId: 'TKT-2026-088',
    assetTag: 'AST-2024-006',
    assetName: 'HP Z2 Tower G9',
    category: 'hardware' as const,
    priority: 'critical' as const,
    status: 'in-progress' as const,
    location: 'Floor 1 — Executive Suite',
    assignee: 'Carlos Mendez',
    created: '2026-07-15',
    slaDue: '2026-07-16',
    slaHoursLeft: 1,
    description: 'RAID array degraded — one drive showing imminent failure (S.M.A.R.T. alert).',
    hasFaultPhoto: true,
    resolutionType: null,
  },
  {
    id: 'ticket-003',
    ticketId: 'TKT-2026-087',
    assetTag: 'AST-2024-007',
    assetName: 'Lenovo ThinkStation P360',
    category: 'software' as const,
    priority: 'high' as const,
    status: 'in-progress' as const,
    location: 'Floor 2 — Office 211',
    assignee: 'Pedro Alvarado',
    created: '2026-07-14',
    slaDue: '2026-07-16',
    slaHoursLeft: 6,
    description: 'CAD software crashes on model load > 2GB. Memory dump collected.',
    hasFaultPhoto: false,
    resolutionType: null,
  },
  {
    id: 'ticket-004',
    ticketId: 'TKT-2026-086',
    assetTag: 'AST-2024-003',
    assetName: 'Lenovo ThinkCentre M720q',
    category: 'network' as const,
    priority: 'high' as const,
    status: 'pending-parts' as const,
    location: 'Floor 3 — Server Room',
    assignee: 'Carlos Mendez',
    created: '2026-07-13',
    slaDue: '2026-07-17',
    slaHoursLeft: 24,
    description: 'NIC card failure — replaced temporarily with USB adapter. Waiting for replacement NIC.',
    hasFaultPhoto: true,
    resolutionType: null,
  },
  {
    id: 'ticket-005',
    ticketId: 'TKT-2026-085',
    assetTag: 'AST-2024-012',
    assetName: 'Dell Vostro 3910',
    category: 'software' as const,
    priority: 'medium' as const,
    status: 'open' as const,
    location: 'Floor 1 — Warehouse',
    assignee: 'Unassigned',
    created: '2026-07-13',
    slaDue: '2026-07-17',
    slaHoursLeft: 18,
    description: 'Windows activation error after domain migration. Requires KMS re-activation.',
    hasFaultPhoto: false,
    resolutionType: null,
  },
  {
    id: 'ticket-006',
    ticketId: 'TKT-2026-084',
    assetTag: 'AST-2024-001',
    assetName: 'Dell OptiPlex 7090',
    category: 'hardware' as const,
    priority: 'medium' as const,
    status: 'open' as const,
    location: 'Floor 2 — Office 204',
    assignee: 'Pedro Alvarado',
    created: '2026-07-10',
    slaDue: '2026-07-18',
    slaHoursLeft: 36,
    description: 'Screen flickering intermittently — suspected GPU driver or display cable issue.',
    hasFaultPhoto: true,
    resolutionType: null,
  },
  {
    id: 'ticket-007',
    ticketId: 'TKT-2026-083',
    assetTag: 'AST-2024-011',
    assetName: 'Lenovo IdeaCentre 5i',
    category: 'connectivity' as const,
    priority: 'low' as const,
    status: 'open' as const,
    location: 'Floor 2 — Office 208',
    assignee: 'Unassigned',
    created: '2026-07-09',
    slaDue: '2026-07-20',
    slaHoursLeft: 72,
    description: 'VPN client disconnects every 20–30 minutes. Only on this workstation.',
    hasFaultPhoto: false,
    resolutionType: null,
  },
  {
    id: 'ticket-008',
    ticketId: 'TKT-2026-082',
    assetTag: 'AST-2024-004',
    assetName: 'Apple Mac Mini M2',
    category: 'software' as const,
    priority: 'low' as const,
    status: 'resolved' as const,
    location: 'Floor 2 — Design Lab',
    assignee: 'Carlos Mendez',
    created: '2026-07-07',
    slaDue: '2026-07-09',
    slaHoursLeft: 0,
    description: 'Adobe CC apps not launching after macOS update. Resolved by reinstalling CC Desktop app.',
    hasFaultPhoto: false,
    resolutionType: 'Software Reinstall',
  },
  {
    id: 'ticket-009',
    ticketId: 'TKT-2026-081',
    assetTag: 'AST-2024-008',
    assetName: 'Dell OptiPlex 5090',
    category: 'hardware' as const,
    priority: 'medium' as const,
    status: 'resolved' as const,
    location: 'Floor 1 — Reception',
    assignee: 'Pedro Alvarado',
    created: '2026-07-05',
    slaDue: '2026-07-07',
    slaHoursLeft: 0,
    description: 'Keyboard and mouse unresponsive after power surge. USB hub replaced.',
    hasFaultPhoto: true,
    resolutionType: 'Component Replacement',
  },
  {
    id: 'ticket-010',
    ticketId: 'TKT-2026-080',
    assetTag: 'AST-2024-010',
    assetName: 'Apple Mac Studio M2 Ultra',
    category: 'network' as const,
    priority: 'high' as const,
    status: 'resolved' as const,
    location: 'Floor 3 — Media Suite',
    assignee: 'Carlos Mendez',
    created: '2026-07-03',
    slaDue: '2026-07-05',
    slaHoursLeft: 0,
    description: '10GbE switch port misconfiguration causing packet loss during render exports.',
    hasFaultPhoto: false,
    resolutionType: 'Network Reconfiguration',
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  hardware: 'bg-amber-500/10 text-amber-400',
  software: 'bg-blue-500/10 text-blue-400',
  network: 'bg-purple-500/10 text-purple-400',
  connectivity: 'bg-cyan-500/10 text-cyan-400',
};

const PRIORITY_COLORS: Record<string, string> = {
  critical: 'text-red-400',
  high: 'text-orange-400',
  medium: 'text-amber-400',
  low: 'text-green-400',
};

type SortKey = 'ticketId' | 'assetName' | 'category' | 'priority' | 'status' | 'created' | 'slaDue';
type SortDir = 'asc' | 'desc';

export default function TicketTableSection() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [sortKey, setSortKey] = useState<SortKey>('slaDue');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [selectedTicket, setSelectedTicket] = useState<typeof ALL_TICKETS[0] | null>(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => {
    let data = [...ALL_TICKETS];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(
        (t) =>
          t.ticketId.toLowerCase().includes(q) ||
          t.assetName.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.assignee.toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'All') {
      data = data.filter((t) => t.status === statusFilter.toLowerCase().replace(' ', '-'));
    }
    if (categoryFilter !== 'All') {
      data = data.filter((t) => t.category === categoryFilter.toLowerCase());
    }
    if (priorityFilter !== 'All') {
      data = data.filter((t) => t.priority === priorityFilter.toLowerCase());
    }
    data.sort((a, b) => {
      const av = a[sortKey] ?? '';
      const bv = b[sortKey] ?? '';
      return sortDir === 'asc'
        ? String(av).localeCompare(String(bv))
        : String(bv).localeCompare(String(av));
    });
    return data;
  }, [search, statusFilter, categoryFilter, priorityFilter, sortKey, sortDir]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const pageData = filtered.slice((page - 1) * perPage, page * perPage);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const toggleRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selectedIds.size === pageData.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(pageData.map((t) => t.id)));
  };

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <ChevronsUpDown size={12} className="text-muted-foreground" />;
    return sortDir === 'asc' ? (
      <ChevronUp size={12} className="text-primary" />
    ) : (
      <ChevronDown size={12} className="text-primary" />
    );
  };

  const SlaTag = ({ hours, status }: { hours: number; status: string }) => {
    if (status === 'resolved' || status === 'closed') {
      return <span className="text-[11px] text-green-400 font-medium">Met</span>;
    }
    if (hours <= 2) {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-red-400 font-semibold sla-urgent">
          <Clock size={10} /> {hours}h left
        </span>
      );
    }
    if (hours <= 8) {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-amber-400 font-medium">
          <Clock size={10} /> {hours}h left
        </span>
      );
    }
    return (
      <span className="text-[11px] text-muted-foreground font-mono-data">{hours}h</span>
    );
  };

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      {/* Controls */}
      <div className="px-5 py-4 border-b border-border flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 bg-secondary rounded-lg px-3 py-2 flex-1 min-w-48 max-w-72">
          <Search size={14} className="text-muted-foreground shrink-0" />
          <input
            type="text"
            placeholder="Search ticket ID, asset, description..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none w-full"
          />
          {search && (
            <button onClick={() => setSearch('')}>
              <X size={12} className="text-muted-foreground hover:text-foreground" />
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          {[
            { label: 'Status', value: statusFilter, options: ['All', 'Open', 'In Progress', 'Pending Parts', 'Resolved', 'Closed'], setter: setStatusFilter },
            { label: 'Category', value: categoryFilter, options: ['All', 'Hardware', 'Software', 'Network', 'Connectivity'], setter: setCategoryFilter },
            { label: 'Priority', value: priorityFilter, options: ['All', 'Critical', 'High', 'Medium', 'Low'], setter: setPriorityFilter },
          ].map((f) => (
            <select
              key={`filter-${f.label}`}
              value={f.value}
              onChange={(e) => { f.setter(e.target.value); setPage(1); }}
              className="bg-secondary border border-border text-xs text-foreground rounded-lg px-2.5 py-1.5 outline-none cursor-pointer"
            >
              {f.options.map((o) => (
                <option key={`opt-${f.label}-${o}`} value={o}>{o === 'All' ? `All ${f.label}` : o}</option>
              ))}
            </select>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            className="flex items-center gap-1.5 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-all duration-150 font-medium"
            onClick={() => toast.info('New ticket form — connect to backend')}
          >
            <Plus size={13} />
            New Ticket
          </button>
        </div>
      </div>

      {/* Bulk bar */}
      {selectedIds.size > 0 && (
        <div className="px-5 py-2.5 bg-primary/10 border-b border-primary/20 flex items-center gap-3">
          <span className="text-xs font-medium text-primary">
            {selectedIds.size} ticket{selectedIds.size > 1 ? 's' : ''} selected
          </span>
          <div className="flex items-center gap-2">
            {['Assign to Me', 'Mark Resolved', 'Escalate Priority', 'Export'].map((action) => (
              <button
                key={`bulk-${action}`}
                className="text-xs px-2.5 py-1 rounded-lg bg-secondary hover:bg-muted text-foreground transition-colors duration-150"
                onClick={() => toast.success(`${action} applied to ${selectedIds.size} tickets`)}
              >
                {action}
              </button>
            ))}
          </div>
          <button className="ml-auto text-muted-foreground hover:text-foreground" onClick={() => setSelectedIds(new Set())}>
            <X size={14} />
          </button>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto scrollbar-thin">
        <table className="w-full min-w-[1100px]">
          <thead>
            <tr className="border-b border-border">
              <th className="w-10 px-4 py-3">
                <button onClick={toggleAll} className="text-muted-foreground hover:text-foreground">
                  {selectedIds.size === pageData.length && pageData.length > 0 ? (
                    <CheckSquare size={15} className="text-primary" />
                  ) : (
                    <Square size={15} />
                  )}
                </button>
              </th>
              {[
                { key: 'ticketId', label: 'Ticket ID' },
                { key: 'assetName', label: 'Asset' },
                { key: 'category', label: 'Category' },
                { key: 'priority', label: 'Priority' },
                { key: 'status', label: 'Status' },
                { key: null, label: 'Location' },
                { key: null, label: 'Assignee' },
                { key: 'created', label: 'Created' },
                { key: 'slaDue', label: 'SLA' },
                { key: null, label: 'Photo' },
                { key: null, label: '' },
              ].map((col, i) => (
                <th
                  key={`th-${i}`}
                  className="px-3 py-3 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wider"
                >
                  {col.key ? (
                    <button
                      className="flex items-center gap-1 hover:text-foreground transition-colors duration-150"
                      onClick={() => toggleSort(col.key as SortKey)}
                    >
                      {col.label}
                      <SortIcon col={col.key as SortKey} />
                    </button>
                  ) : (
                    col.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageData.length === 0 && (
              <tr>
                <td colSpan={11} className="text-center py-16">
                  <div className="flex flex-col items-center gap-3">
                    <Ticket size={32} className="text-muted-foreground/40" />
                    <p className="text-sm font-medium text-muted-foreground">No tickets match your filters</p>
                    <p className="text-xs text-muted-foreground/60">Try adjusting your filters or search query</p>
                  </div>
                </td>
              </tr>
            )}
            {pageData.map((ticket, idx) => (
              <tr
                key={ticket.id}
                className={`border-b border-border/50 hover:bg-secondary/40 transition-colors duration-100 cursor-pointer ${
                  selectedIds.has(ticket.id) ? 'bg-primary/5' : idx % 2 === 1 ? 'bg-secondary/10' : ''
                } ${ticket.priority === 'critical' && String(ticket.status) !== 'resolved' ? 'border-l-2 border-l-red-500/60' : ''}`}
                onClick={() => setSelectedTicket(ticket)}
              >
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => toggleRow(ticket.id)}>
                    {selectedIds.has(ticket.id) ? (
                      <CheckSquare size={15} className="text-primary" />
                    ) : (
                      <Square size={15} className="text-muted-foreground" />
                    )}
                  </button>
                </td>
                <td className="px-3 py-3">
                  <span className="font-mono-data text-xs text-primary font-semibold">{ticket.ticketId}</span>
                </td>
                <td className="px-3 py-3">
                  <div>
                    <p className="text-sm font-medium text-foreground truncate max-w-[140px]">{ticket.assetName}</p>
                    <p className="text-[11px] text-muted-foreground font-mono-data">{ticket.assetTag}</p>
                  </div>
                </td>
                <td className="px-3 py-3">
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full capitalize ${CATEGORY_COLORS[ticket.category]}`}>
                    {ticket.category}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${
                      ticket.priority === 'critical' ? 'bg-red-400' :
                      ticket.priority === 'high' ? 'bg-orange-400' :
                      ticket.priority === 'medium' ? 'bg-amber-400' : 'bg-green-400'
                    }`} />
                    <span className={`text-xs capitalize font-medium ${PRIORITY_COLORS[ticket.priority]}`}>
                      {ticket.priority}
                    </span>
                  </div>
                </td>
                <td className="px-3 py-3">
                  <StatusBadge status={ticket.status} />
                </td>
                <td className="px-3 py-3">
                  <p className="text-xs text-muted-foreground truncate max-w-[130px]">{ticket.location}</p>
                </td>
                <td className="px-3 py-3">
                  <span className={`text-xs ${ticket.assignee === 'Unassigned' ? 'text-muted-foreground/60 italic' : 'text-foreground'}`}>
                    {ticket.assignee}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <span className="font-mono-data text-xs text-muted-foreground">{ticket.created}</span>
                </td>
                <td className="px-3 py-3">
                  <SlaTag hours={ticket.slaHoursLeft} status={ticket.status} />
                </td>
                <td className="px-3 py-3">
                  {ticket.hasFaultPhoto ? (
                    <ImageIcon size={14} className="text-cyan-400" />
                  ) : (
                    <ImageIcon size={14} className="text-muted-foreground/30" />
                  )}
                </td>
                <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center gap-1">
                    <button
                      title="View ticket details"
                      className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors duration-150"
                      onClick={() => setSelectedTicket(ticket)}
                    >
                      <Eye size={13} />
                    </button>
                    <button
                      title="Assign ticket"
                      className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors duration-150"
                      onClick={() => toast.success(`Ticket ${ticket.ticketId} assigned to you`)}
                    >
                      <UserPlus size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="px-5 py-3 border-t border-border flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Showing {Math.min((page - 1) * perPage + 1, filtered.length)}–
          {Math.min(page * perPage, filtered.length)} of {filtered.length} tickets
        </p>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-secondary text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button
              key={`page-${p}`}
              onClick={() => setPage(p)}
              className={`w-7 h-7 text-xs rounded-lg transition-colors duration-150 ${
                page === p ? 'bg-primary text-primary-foreground font-medium' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {p}
            </button>
          ))}
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-secondary text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </div>

      {selectedTicket && (
        <TicketDetailPanel ticket={selectedTicket} onClose={() => setSelectedTicket(null)} />
      )}
    </div>
  );
}