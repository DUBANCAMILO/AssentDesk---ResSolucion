import React from 'react';
import { Ticket, Clock, AlertTriangle, CheckCircle, Zap } from 'lucide-react';
import TicketCategoryChart from './TicketCategoryChart';

const metrics = [
  {
    id: 'tm-open',
    label: 'Open Tickets',
    value: '23',
    sub: '7 unassigned',
    icon: Ticket,
    iconColor: 'text-blue-400',
    iconBg: 'bg-blue-500/10',
    alert: false,
    warn: false,
  },
  {
    id: 'tm-sla',
    label: 'SLA Breach Risk',
    value: '7',
    sub: 'Due in < 4 hours',
    icon: Clock,
    iconColor: 'text-orange-400',
    iconBg: 'bg-orange-500/10',
    alert: false,
    warn: true,
  },
  {
    id: 'tm-critical',
    label: 'Critical Priority',
    value: '4',
    sub: 'Escalated today',
    icon: AlertTriangle,
    iconColor: 'text-red-400',
    iconBg: 'bg-red-500/10',
    alert: true,
    warn: false,
  },
  {
    id: 'tm-resolved',
    label: 'Resolved This Week',
    value: '34',
    sub: 'Avg 2.4h resolution',
    icon: CheckCircle,
    iconColor: 'text-green-400',
    iconBg: 'bg-green-500/10',
    alert: false,
    warn: false,
  },
  {
    id: 'tm-pending',
    label: 'Pending Parts',
    value: '3',
    sub: 'Waiting on procurement',
    icon: Zap,
    iconColor: 'text-purple-400',
    iconBg: 'bg-purple-500/10',
    alert: false,
    warn: false,
  },
];

export default function TicketMetricsRow() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 2xl:grid-cols-6 gap-4">
      {metrics?.map((m) => {
        const Icon = m?.icon;
        return (
          <div
            key={m?.id}
            className={`bg-card border rounded-xl p-4 flex flex-col gap-3 ${
              m?.alert
                ? 'border-red-500/30 bg-red-500/5'
                : m?.warn
                ? 'border-amber-500/30 bg-amber-500/5' :'border-border'
            }`}
          >
            <div className={`p-2 rounded-lg w-fit ${m?.iconBg}`}>
              <Icon size={15} className={m?.iconColor} />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono-data text-foreground">{m?.value}</p>
              <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide mt-0.5">
                {m?.label}
              </p>
            </div>
            <p className="text-xs text-muted-foreground">{m?.sub}</p>
          </div>
        );
      })}
      {/* Category breakdown chart */}
      <div className="col-span-2 md:col-span-3 xl:col-span-1 2xl:col-span-1 bg-card border border-border rounded-xl p-4 flex flex-col">
        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">
          By Category
        </p>
        <div className="flex-1 min-h-[80px]">
          <TicketCategoryChart />
        </div>
      </div>
    </div>
  );
}