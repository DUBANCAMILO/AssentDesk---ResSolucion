'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Plus, Search, Edit2, Trash2, Users, Monitor, Cpu, MapPin, Tag, X, Save, RefreshCw, Layers } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { assetService, type Asset } from '@/lib/services/assetService';
import { toast } from 'sonner';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';

interface EquipmentGroup {
  id: string;
  nombre: string;
  descripcion?: string;
  tipo?: string;
  responsable?: string;
  area?: string;
  sede?: string;
  color?: string;
  icono?: string;
  activo?: boolean;
  created_at?: string;
  asset_count?: number;
}

const EMPTY_GROUP: Omit<EquipmentGroup, 'id' | 'created_at'> = {
  nombre: '',
  descripcion: '',
  tipo: 'general',
  responsable: '',
  area: '',
  sede: '',
  color: '#6366f1',
  icono: 'monitor',
  activo: true,
};

const GROUP_COLORS = [
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316',
  '#eab308', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6',
];

const GROUP_TIPOS = ['general', 'laptops', 'desktops', 'servidores', 'impresoras', 'monitores', 'tablets', 'red', 'periféricos', 'otro'];

export default function EquipmentManagementPage() {
  const [groups, setGroups] = useState<EquipmentGroup[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editGroup, setEditGroup] = useState<EquipmentGroup | null>(null);
  const [form, setForm] = useState<Omit<EquipmentGroup, 'id' | 'created_at'>>(EMPTY_GROUP);
  const [saving, setSaving] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<EquipmentGroup | null>(null);
  const [assignSearch, setAssignSearch] = useState('');
  const [assigning, setAssigning] = useState(false);

  const supabase = useMemo(() => createClient(), []);

  const loadData = useCallback(async () => {
    setLoading(true);
    const [groupsRes, assetsData] = await Promise.all([
      supabase.from('equipment_groups').select('*').order('nombre'),
      assetService.getAll(),
    ]);
    const rawGroups: EquipmentGroup[] = (groupsRes.data || []) as EquipmentGroup[];
    // Count assets per group
    const withCounts = rawGroups.map(g => ({
      ...g,
      asset_count: assetsData.filter(a => (a as Asset & { group_id?: string }).group_id === g.id).length,
    }));
    setGroups(withCounts);
    setAssets(assetsData);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { loadData(); }, [loadData]);

  const filteredGroups = useMemo(() => {
    if (!search) return groups;
    const q = search.toLowerCase();
    return groups.filter(g =>
      g.nombre.toLowerCase().includes(q) ||
      (g.area || '').toLowerCase().includes(q) ||
      (g.responsable || '').toLowerCase().includes(q)
    );
  }, [groups, search]);

  const groupAssets = useMemo(() => {
    if (!selectedGroup) return [];
    return assets.filter(a => (a as Asset & { group_id?: string }).group_id === selectedGroup.id);
  }, [selectedGroup, assets]);

  const unassignedAssets = useMemo(() => {
    if (!selectedGroup) return [];
    const q = assignSearch.toLowerCase();
    return assets.filter(a => {
      const noGroup = !(a as Asset & { group_id?: string }).group_id;
      if (!q) return noGroup;
      return noGroup && (
        (a.placa || '').toLowerCase().includes(q) ||
        (a.marca || '').toLowerCase().includes(q) ||
        (a.modelo || '').toLowerCase().includes(q) ||
        (a.usuario_responsable || '').toLowerCase().includes(q)
      );
    });
  }, [assets, selectedGroup, assignSearch]);

  const openCreate = () => {
    setEditGroup(null);
    setForm(EMPTY_GROUP);
    setShowModal(true);
  };

  const openEdit = (g: EquipmentGroup) => {
    setEditGroup(g);
    setForm({ nombre: g.nombre, descripcion: g.descripcion || '', tipo: g.tipo || 'general', responsable: g.responsable || '', area: g.area || '', sede: g.sede || '', color: g.color || '#6366f1', icono: g.icono || 'monitor', activo: g.activo !== false });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.nombre.trim()) { toast.error('El nombre del grupo es requerido'); return; }
    setSaving(true);
    if (editGroup) {
      const { error } = await supabase.from('equipment_groups').update({ ...form, updated_at: new Date().toISOString() }).eq('id', editGroup.id);
      if (error) { toast.error('Error al actualizar grupo'); } else { toast.success('Grupo actualizado'); }
    } else {
      const { error } = await supabase.from('equipment_groups').insert(form);
      if (error) { toast.error('Error al crear grupo'); } else { toast.success('Grupo creado'); }
    }
    setSaving(false);
    setShowModal(false);
    loadData();
  };

  const handleDelete = async (g: EquipmentGroup) => {
    if (!confirm(`¿Eliminar el grupo "${g.nombre}"? Los equipos quedarán sin grupo.`)) return;
    const { error } = await supabase.from('equipment_groups').delete().eq('id', g.id);
    if (error) { toast.error('Error al eliminar'); } else { toast.success('Grupo eliminado'); loadData(); }
  };

  const assignAsset = async (assetId: string) => {
    if (!selectedGroup) return;
    setAssigning(true);
    await supabase.from('assets').update({ group_id: selectedGroup.id }).eq('id', assetId);
    await loadData();
    setAssigning(false);
    toast.success('Equipo asignado al grupo');
  };

  const removeFromGroup = async (assetId: string) => {
    setAssigning(true);
    await supabase.from('assets').update({ group_id: null }).eq('id', assetId);
    await loadData();
    setAssigning(false);
    toast.success('Equipo removido del grupo');
  };

  return (
    <AppLayout>
      <Topbar title="Gestión de Equipos" subtitle="Organiza y agrupa los activos por categoría, área o función" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Header actions */}
        <div className="flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar grupos..."
              className="w-full pl-9 pr-4 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
            />
          </div>
          <button
            onClick={openCreate}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus size={15} />
            Nuevo Grupo
          </button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Grupos', value: groups.length, icon: Layers, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Equipos Agrupados', value: assets.filter(a => (a as Asset & { group_id?: string }).group_id).length, icon: Monitor, color: 'text-green-400', bg: 'bg-green-500/10' },
            { label: 'Sin Grupo', value: assets.filter(a => !(a as Asset & { group_id?: string }).group_id).length, icon: Tag, color: 'text-amber-400', bg: 'bg-amber-500/10' },
            { label: 'Áreas Cubiertas', value: [...new Set(groups.map(g => g.area).filter(Boolean))].length, icon: MapPin, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
          ].map(s => (
            <div key={s.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center shrink-0`}>
                <s.icon size={18} className={s.color} />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Groups list */}
          <div className="lg:col-span-1 space-y-3">
            <h3 className="text-sm font-semibold text-foreground">Grupos de Equipos</h3>
            {loading ? (
              <div className="space-y-2">
                {[1,2,3].map(i => <div key={i} className="h-20 bg-secondary rounded-xl animate-pulse" />)}
              </div>
            ) : filteredGroups.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center">
                <Layers size={32} className="mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">No hay grupos creados</p>
                <button onClick={openCreate} className="mt-3 text-xs text-primary hover:underline">Crear primer grupo</button>
              </div>
            ) : (
              filteredGroups.map(g => (
                <div
                  key={g.id}
                  onClick={() => setSelectedGroup(selectedGroup?.id === g.id ? null : g)}
                  className={`bg-card border rounded-xl p-4 cursor-pointer transition-all duration-150 ${selectedGroup?.id === g.id ? 'border-primary/50 ring-1 ring-primary/20' : 'border-border hover:border-border/80'}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: (g.color || '#6366f1') + '20' }}>
                        <Monitor size={16} style={{ color: g.color || '#6366f1' }} />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{g.nombre}</p>
                        <p className="text-xs text-muted-foreground">{g.area || 'Sin área'} · {g.asset_count || 0} equipos</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={e => { e.stopPropagation(); openEdit(g); }} className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                        <Edit2 size={13} />
                      </button>
                      <button onClick={e => { e.stopPropagation(); handleDelete(g); }} className="p-1.5 rounded text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                  {g.responsable && <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1"><Users size={11} />{g.responsable}</p>}
                  {g.descripcion && <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{g.descripcion}</p>}
                </div>
              ))
            )}
          </div>

          {/* Group detail / asset assignment */}
          <div className="lg:col-span-2">
            {!selectedGroup ? (
              <div className="bg-card border border-border rounded-xl p-12 text-center h-full flex flex-col items-center justify-center">
                <Layers size={40} className="text-muted-foreground mb-3" />
                <p className="text-sm font-medium text-foreground">Selecciona un grupo</p>
                <p className="text-xs text-muted-foreground mt-1">Haz clic en un grupo para ver y gestionar sus equipos</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: (selectedGroup.color || '#6366f1') + '20' }}>
                        <Monitor size={18} style={{ color: selectedGroup.color || '#6366f1' }} />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-foreground">{selectedGroup.nombre}</h3>
                        <p className="text-xs text-muted-foreground">{selectedGroup.tipo} · {selectedGroup.area}</p>
                      </div>
                    </div>
                    <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">{groupAssets.length} equipos</span>
                  </div>

                  {/* Assigned assets */}
                  <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
                    {groupAssets.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-4">Sin equipos asignados</p>
                    ) : groupAssets.map(a => (
                      <div key={a.id} className="flex items-center justify-between bg-secondary rounded-lg px-3 py-2">
                        <div className="flex items-center gap-2">
                          <Monitor size={13} className="text-muted-foreground" />
                          <span className="text-xs font-medium text-foreground">{a.placa}</span>
                          <span className="text-xs text-muted-foreground">{a.marca} {a.modelo}</span>
                        </div>
                        <button onClick={() => removeFromGroup(a.id)} className="text-xs text-red-400 hover:text-red-300 transition-colors">
                          <X size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Assign unassigned assets */}
                <div className="bg-card border border-border rounded-xl p-4">
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Agregar Equipos al Grupo</h4>
                  <div className="relative mb-3">
                    <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input
                      value={assignSearch}
                      onChange={e => setAssignSearch(e.target.value)}
                      placeholder="Buscar equipos sin grupo..."
                      className="w-full pl-8 pr-4 py-1.5 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
                    />
                  </div>
                  <div className="space-y-1.5 max-h-52 overflow-y-auto scrollbar-thin">
                    {unassignedAssets.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-3">No hay equipos disponibles</p>
                    ) : unassignedAssets.slice(0, 20).map(a => (
                      <div key={a.id} className="flex items-center justify-between bg-secondary rounded-lg px-3 py-2">
                        <div className="flex items-center gap-2">
                          <Cpu size={12} className="text-muted-foreground" />
                          <span className="text-xs font-medium text-foreground">{a.placa}</span>
                          <span className="text-xs text-muted-foreground">{a.marca} {a.modelo}</span>
                          {a.usuario_responsable && <span className="text-xs text-muted-foreground">· {a.usuario_responsable}</span>}
                        </div>
                        <button
                          onClick={() => assignAsset(a.id)}
                          disabled={assigning}
                          className="text-xs text-primary hover:text-primary/80 font-medium transition-colors disabled:opacity-50"
                        >
                          + Agregar
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowModal(false)} />
          <div className="relative bg-card border border-border rounded-2xl w-full max-w-lg shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="text-base font-semibold text-foreground">{editGroup ? 'Editar Grupo' : 'Nuevo Grupo de Equipos'}</h2>
              <button onClick={() => setShowModal(false)} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={16} />
              </button>
            </div>
            <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto scrollbar-thin">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Nombre del Grupo *</label>
                  <input value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50" placeholder="Ej: Laptops Gerencia" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Tipo</label>
                  <select value={form.tipo} onChange={e => setForm(f => ({ ...f, tipo: e.target.value }))} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50">
                    {GROUP_TIPOS.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Área</label>
                  <input value={form.area || ''} onChange={e => setForm(f => ({ ...f, area: e.target.value }))} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50" placeholder="Ej: Recursos Humanos" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Sede</label>
                  <input value={form.sede || ''} onChange={e => setForm(f => ({ ...f, sede: e.target.value }))} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50" placeholder="Ej: Sede Principal" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Responsable</label>
                  <input value={form.responsable || ''} onChange={e => setForm(f => ({ ...f, responsable: e.target.value }))} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50" placeholder="Nombre del responsable" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Descripción</label>
                  <textarea value={form.descripcion || ''} onChange={e => setForm(f => ({ ...f, descripcion: e.target.value }))} rows={2} className="w-full px-3 py-2 text-sm bg-secondary border border-border rounded-lg text-foreground outline-none focus:border-primary/50 resize-none" placeholder="Descripción del grupo..." />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-muted-foreground mb-2">Color del Grupo</label>
                  <div className="flex gap-2 flex-wrap">
                    {GROUP_COLORS.map(c => (
                      <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))} className={`w-7 h-7 rounded-full border-2 transition-all ${form.color === c ? 'border-white scale-110' : 'border-transparent'}`} style={{ backgroundColor: c }} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-3">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Cancelar</button>
              <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-60">
                {saving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                {editGroup ? 'Guardar Cambios' : 'Crear Grupo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
