'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import {
  Printer, Plus, Search, RefreshCw, Edit2, Trash2, Eye, X,
  Network, AlertTriangle, CheckCircle, AlertCircle, MapPin, User,
  ChevronUp, ChevronDown, ChevronsUpDown, Wifi, WifiOff,
} from 'lucide-react';
import { printerService, ipService, type Printer as PrinterType } from '@/lib/services/assetService';
import { createClient } from '@/lib/supabase/client';

const MARCAS_IMPRESORA = [
  '', 'HP', 'Canon', 'Epson', 'Brother', 'Xerox', 'Lexmark', 'Samsung',
  'Ricoh', 'Kyocera', 'Konica Minolta', 'Sharp', 'OKI', 'Pantum',
  'Zebra', 'Datamax', 'Honeywell', 'TSC', 'Citizen', 'Star Micronics', 'Otra',
];

const TIPOS_IMPRESORA = [
  '', 'Láser B&N', 'Láser Color', 'Inkjet', 'Multifuncional Láser B&N',
  'Multifuncional Láser Color', 'Multifuncional Inkjet', 'Térmica Directa',
  'Térmica por Transferencia', 'Matricial / Punto', 'Plotter Inkjet',
  'Plotter de Corte', 'Sublimación', 'Impresora de Etiquetas',
  'Impresora de Tarjetas', 'Impresora de Recibos', 'Impresora 3D', 'Otra',
];

const STATUS_LABELS: Record<string, string> = {
  operational: 'Operativa',
  maintenance: 'Mantenimiento',
  critical: 'Crítica',
  decommissioned: 'Dada de Baja',
};

const STATUS_COLORS: Record<string, string> = {
  operational: 'text-green-400 bg-green-500/10 border-green-500/20',
  maintenance: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  critical: 'text-red-400 bg-red-500/10 border-red-500/20',
  decommissioned: 'text-gray-400 bg-gray-500/10 border-gray-500/20',
};

const EMPTY_FORM: Omit<PrinterType, 'id' | 'created_at' | 'updated_at'> = {
  nombre: '',
  placa: '',
  marca: '',
  modelo: '',
  tipo: '',
  serial: '',
  mac_address: '',
  direccion_ip: '',
  subred: '255.255.255.0',
  gateway: '192.168.1.1',
  dns_primario: '8.8.8.8',
  dns_secundario: '8.8.4.4',
  puerto_switch: '',
  tipo_asignacion: 'Estática',
  area: '',
  sede: '',
  ubicacion: '',
  usuario_responsable: '',
  tecnico_instalador: '',
  proveedor: '',
  orden_compra: '',
  garantia_vencimiento: '',
  garantia_tipo: '',
  status: 'operational',
  en_red: 'SI',
  observaciones: '',
};

type SortKey = 'nombre' | 'marca' | 'area' | 'status' | 'direccion_ip';
type SortDir = 'asc' | 'desc';

function Field({ label, name, value, onChange, type = 'text', options, span = 1, placeholder }: {
  label: string; name: string; value: string | undefined; onChange: (n: string, v: string) => void;
  type?: string; options?: string[]; span?: number; placeholder?: string;
}) {
  const cls = 'bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full';
  return (
    <div className={span === 2 ? 'col-span-2' : ''}>
      <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">{label}</label>
      {options ? (
        <select name={name} value={value || ''} onChange={e => onChange(name, e.target.value)} className={cls}>
          {options.map(o => <option key={o} value={o}>{o || '— Seleccionar —'}</option>)}
        </select>
      ) : (
        <input type={type} name={name} value={value || ''} onChange={e => onChange(name, e.target.value)}
          className={cls} placeholder={placeholder || label} />
      )}
    </div>
  );
}

export default function PrintersPage() {
  const [printers, setPrinters] = useState<PrinterType[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('nombre');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selectedPrinter, setSelectedPrinter] = useState<PrinterType | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingPrinter, setEditingPrinter] = useState<PrinterType | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [ipWarning, setIpWarning] = useState<string | null>(null);

  const loadPrinters = useCallback(async () => {
    setLoading(true);
    const data = await printerService.getAll();
    setPrinters(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPrinters();
    const supabase = createClient();
    const channel = supabase
      .channel('printers_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'printers' }, () => loadPrinters())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadPrinters]);

  const handleChange = (name: string, value: string) => {
    setForm(prev => ({ ...prev, [name]: value }));
    if (name === 'direccion_ip') setIpWarning(null);
  };

  const handleIpBlur = async () => {
    const ip = form.direccion_ip?.trim();
    if (!ip) return;
    try {
      const allIps = await ipService.getAll();
      const existing = (allIps as Array<{ direccion_ip: string; status?: string; nombre?: string }>).find(
        r => r.direccion_ip === ip
      );
      if (existing && existing.status === 'ocupada') {
        const name = existing.nombre ? ` (${existing.nombre})` : '';
        setIpWarning(`⚠️ Esta IP ya está marcada como "ocupada"${name} en el sistema de gestión de IPs.`);
      } else {
        setIpWarning(null);
      }
    } catch { setIpWarning(null); }
  };

  const openAdd = () => {
    setForm({ ...EMPTY_FORM });
    setEditingPrinter(null);
    setSaveError(null);
    setSaveSuccess(false);
    setIpWarning(null);
    setShowForm(true);
  };

  const openEdit = (printer: PrinterType) => {
    setForm({
      nombre: printer.nombre || '',
      placa: printer.placa || '',
      marca: printer.marca || '',
      modelo: printer.modelo || '',
      tipo: printer.tipo || '',
      serial: printer.serial || '',
      mac_address: printer.mac_address || '',
      direccion_ip: printer.direccion_ip || '',
      subred: printer.subred || '255.255.255.0',
      gateway: printer.gateway || '192.168.1.1',
      dns_primario: printer.dns_primario || '8.8.8.8',
      dns_secundario: printer.dns_secundario || '8.8.4.4',
      puerto_switch: printer.puerto_switch || '',
      tipo_asignacion: printer.tipo_asignacion || 'Estática',
      area: printer.area || '',
      sede: printer.sede || '',
      ubicacion: printer.ubicacion || '',
      usuario_responsable: printer.usuario_responsable || '',
      tecnico_instalador: printer.tecnico_instalador || '',
      proveedor: printer.proveedor || '',
      orden_compra: printer.orden_compra || '',
      garantia_vencimiento: printer.garantia_vencimiento || '',
      garantia_tipo: printer.garantia_tipo || '',
      status: printer.status || 'operational',
      en_red: printer.en_red || 'SI',
      observaciones: printer.observaciones || '',
    });
    setEditingPrinter(printer);
    setSaveError(null);
    setSaveSuccess(false);
    setIpWarning(null);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.nombre.trim()) { setSaveError('El nombre es obligatorio'); return; }
    setSaving(true); setSaveError(null);
    try {
      const payload = {
        ...form,
        garantia_vencimiento: form.garantia_vencimiento || undefined,
      };
      let result: PrinterType | null;
      if (editingPrinter) {
        result = await printerService.update(editingPrinter.id, payload);
      } else {
        result = await printerService.create(payload);
      }
      if (result) {
        setSaveSuccess(true);
        setTimeout(() => {
          setShowForm(false);
          setSaveSuccess(false);
          setEditingPrinter(null);
        }, 800);
        loadPrinters();
      } else {
        setSaveError('No se pudo guardar. Intenta de nuevo.');
      }
    } catch { setSaveError('Error al guardar.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (printer: PrinterType) => {
    if (!confirm(`¿Eliminar la impresora "${printer.nombre}"?`)) return;
    await printerService.delete(printer.id);
    setSelectedPrinter(null);
    loadPrinters();
  };

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  const filtered = useMemo(() => {
    let data = [...printers];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(p =>
        (p.nombre || '').toLowerCase().includes(q) ||
        (p.marca || '').toLowerCase().includes(q) ||
        (p.modelo || '').toLowerCase().includes(q) ||
        (p.serial || '').toLowerCase().includes(q) ||
        (p.direccion_ip || '').includes(q) ||
        (p.area || '').toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'all') data = data.filter(p => p.status === statusFilter);
    data.sort((a, b) => {
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [printers, search, statusFilter, sortKey, sortDir]);

  const metrics = useMemo(() => ({
    total: printers.length,
    operational: printers.filter(p => p.status === 'operational').length,
    maintenance: printers.filter(p => p.status === 'maintenance').length,
    critical: printers.filter(p => p.status === 'critical').length,
    enRed: printers.filter(p => p.en_red === 'SI' && p.direccion_ip).length,
  }), [printers]);

  return (
    <AppLayout>
      <Topbar title="Inventario de Impresoras" subtitle="Gestión y control de impresoras en red" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { label: 'Total', value: metrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Printer },
            { label: 'Operativas', value: metrics.operational, color: 'text-green-400', bg: 'bg-green-500/10', icon: CheckCircle },
            { label: 'Mantenimiento', value: metrics.maintenance, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: AlertTriangle },
            { label: 'Críticas', value: metrics.critical, color: 'text-red-400', bg: 'bg-red-500/10', icon: AlertCircle },
            { label: 'En Red', value: metrics.enRed, color: 'text-blue-400', bg: 'bg-blue-500/10', icon: Wifi },
          ].map(m => {
            const MIcon = m.icon;
            return (
              <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                <div className={`p-2 rounded-xl ${m.bg}`}><MIcon size={15} className={m.color} /></div>
                <div>
                  <p className={`text-xl font-bold font-mono ${m.color}`}>{m.value}</p>
                  <p className="text-[10px] text-muted-foreground">{m.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-border">
            <div className="relative flex-1 min-w-48">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Buscar por nombre, marca, IP, área..."
                className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {['all', 'operational', 'maintenance', 'critical'].map(f => (
                <button key={f} onClick={() => setStatusFilter(f)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${statusFilter === f ? 'bg-primary/15 border-primary/30 text-primary' : 'bg-secondary border-border text-muted-foreground hover:text-foreground'}`}>
                  {f === 'all' ? 'Todas' : STATUS_LABELS[f]}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <button onClick={loadPrinters} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
                <RefreshCw size={14} />
              </button>
              <button onClick={openAdd}
                className="flex items-center gap-2 px-3 py-2 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                <Plus size={13} /> Nueva Impresora
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  {[
                    { key: 'nombre', label: 'Nombre' },
                    { key: 'marca', label: 'Marca / Modelo' },
                    { key: 'direccion_ip', label: 'Dirección IP' },
                    { key: 'area', label: 'Área' },
                    { key: null, label: 'Red' },
                    { key: 'status', label: 'Estado' },
                    { key: null, label: 'Acciones' },
                  ].map((col, i) => (
                    <th key={i}
                      className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider text-[10px] ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                      onClick={() => col.key && handleSort(col.key as SortKey)}>
                      <div className="flex items-center gap-1">{col.label}{col.key && <SortIcon col={col.key as SortKey} />}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                    <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando impresoras...
                  </td></tr>
                ) : filtered.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                    <Printer size={32} className="mx-auto mb-3 opacity-30" />
                    <p>No se encontraron impresoras</p>
                    <button onClick={openAdd} className="mt-2 text-primary hover:underline text-xs">Agregar primera impresora</button>
                  </td></tr>
                ) : filtered.map((p, idx) => (
                  <tr key={p.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors ${idx % 2 === 0 ? '' : 'bg-secondary/10'}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-primary/10 rounded-lg"><Printer size={12} className="text-primary" /></div>
                        <div>
                          <p className="font-semibold text-foreground">{p.nombre}</p>
                          {p.placa && <p className="text-[10px] text-muted-foreground font-mono">{p.placa}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-foreground">{p.marca || '—'}</p>
                      <p className="text-[10px] text-muted-foreground">{p.modelo || ''}</p>
                    </td>
                    <td className="px-4 py-3 font-mono text-primary">{p.direccion_ip || <span className="text-muted-foreground">—</span>}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.area || '—'}</td>
                    <td className="px-4 py-3">
                      {p.en_red === 'SI' && p.direccion_ip
                        ? <div className="flex items-center gap-1 text-green-400"><Wifi size={12} /><span className="text-[10px]">En Red</span></div>
                        : <div className="flex items-center gap-1 text-muted-foreground"><WifiOff size={12} /><span className="text-[10px]">Sin Red</span></div>
                      }
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] font-semibold px-2 py-1 rounded-lg border ${STATUS_COLORS[p.status || 'operational']}`}>
                        {STATUS_LABELS[p.status || 'operational']}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelectedPrinter(p)} title="Ver detalle"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                          <Eye size={14} />
                        </button>
                        <button onClick={() => openEdit(p)} title="Editar"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10 transition-colors">
                          <Edit2 size={14} />
                        </button>
                        <button onClick={() => handleDelete(p)} title="Eliminar"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add/Edit Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowForm(false)} />
          <div className="relative w-full max-w-2xl bg-card border border-border rounded-2xl flex flex-col max-h-[92vh] shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-primary/10 rounded-lg"><Printer size={15} className="text-primary" /></div>
                <h3 className="text-sm font-semibold text-foreground">
                  {editingPrinter ? 'Editar Impresora' : 'Registrar Impresora'}
                </h3>
              </div>
              <button onClick={() => setShowForm(false)}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {saveError && (
                <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs">
                  <AlertCircle size={14} className="shrink-0" />{saveError}
                </div>
              )}
              {saveSuccess && (
                <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-xs">
                  <CheckCircle size={14} className="shrink-0" />{editingPrinter ? 'Impresora actualizada' : 'Impresora registrada correctamente'}
                </div>
              )}

              {/* Identification */}
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Printer size={11} /> Identificación
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Nombre / Descripción <span className="text-red-400">*</span></label>
                    <input type="text" value={form.nombre} onChange={e => handleChange('nombre', e.target.value)}
                      placeholder="Impresora Recepción / HP LaserJet Pro"
                      className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full" />
                  </div>
                  <Field label="Placa / Código" name="placa" value={form.placa} onChange={handleChange} placeholder="IMP-2026-001" />
                  <Field label="Serial" name="serial" value={form.serial} onChange={handleChange} />
                  <Field label="Marca" name="marca" value={form.marca} onChange={handleChange} options={MARCAS_IMPRESORA} />
                  <Field label="Modelo" name="modelo" value={form.modelo} onChange={handleChange} />
                  <Field label="Tipo" name="tipo" value={form.tipo} onChange={handleChange} options={TIPOS_IMPRESORA} />
                  <div>
                    <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Estado</label>
                    <select value={form.status || 'operational'} onChange={e => handleChange('status', e.target.value)}
                      className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full">
                      <option value="operational">Operativa</option>
                      <option value="maintenance">Mantenimiento</option>
                      <option value="critical">Crítica</option>
                      <option value="decommissioned">Dada de Baja</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Network */}
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Network size={11} /> Configuración de Red
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="En Red" name="en_red" value={form.en_red} onChange={handleChange} options={['SI', 'NO']} />
                  <div>
                    <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Dirección IP</label>
                    <input type="text" value={form.direccion_ip || ''} onChange={e => handleChange('direccion_ip', e.target.value)}
                      onBlur={handleIpBlur}
                      placeholder="192.168.1.100"
                      className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full" />
                    {ipWarning && (
                      <div className="flex items-center gap-1.5 mt-1.5 text-amber-400 text-[10px]">
                        <AlertTriangle size={11} className="shrink-0" />
                        <span>{ipWarning}</span>
                      </div>
                    )}
                  </div>
                  <Field label="MAC Address" name="mac_address" value={form.mac_address} onChange={handleChange} placeholder="AA:BB:CC:DD:EE:FF" />
                  <Field label="Tipo Asignación" name="tipo_asignacion" value={form.tipo_asignacion} onChange={handleChange}
                    options={['Estática', 'DHCP', 'Reservada']} />
                  <Field label="Máscara de Subred" name="subred" value={form.subred} onChange={handleChange} />
                  <Field label="Puerta de Enlace" name="gateway" value={form.gateway} onChange={handleChange} />
                  <Field label="DNS Primario" name="dns_primario" value={form.dns_primario} onChange={handleChange} />
                  <Field label="DNS Secundario" name="dns_secundario" value={form.dns_secundario} onChange={handleChange} />
                  <Field label="Puerto Switch" name="puerto_switch" value={form.puerto_switch} onChange={handleChange} placeholder="Gi0/1" />
                </div>
              </div>

              {/* Location */}
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <MapPin size={11} /> Ubicación y Asignación
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Área / Unidad" name="area" value={form.area} onChange={handleChange} />
                  <Field label="Sede" name="sede" value={form.sede} onChange={handleChange} />
                  <Field label="Ubicación Física" name="ubicacion" value={form.ubicacion} onChange={handleChange} span={2} />
                  <Field label="Usuario Responsable" name="usuario_responsable" value={form.usuario_responsable} onChange={handleChange} />
                  <Field label="Técnico Instalador" name="tecnico_instalador" value={form.tecnico_instalador} onChange={handleChange} />
                </div>
              </div>

              {/* Purchase */}
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <User size={11} /> Compra y Garantía
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Proveedor" name="proveedor" value={form.proveedor} onChange={handleChange} />
                  <Field label="Orden de Compra" name="orden_compra" value={form.orden_compra} onChange={handleChange} />
                  <Field label="Vencimiento Garantía" name="garantia_vencimiento" value={form.garantia_vencimiento} onChange={handleChange} type="date" />
                  <Field label="Tipo Garantía" name="garantia_tipo" value={form.garantia_tipo} onChange={handleChange}
                    options={['', 'Fabricante', 'Distribuidor', 'Extendida', 'On-Site', 'Carry-In', 'Sin Garantía']} />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Observaciones</label>
                <textarea value={form.observaciones || ''} onChange={e => handleChange('observaciones', e.target.value)}
                  rows={2} placeholder="Notas adicionales..."
                  className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none" />
              </div>
            </div>

            <div className="flex gap-3 px-6 py-4 border-t border-border shrink-0">
              <button onClick={() => setShowForm(false)}
                className="flex-1 px-4 py-2.5 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors font-medium">
                Cancelar
              </button>
              <button onClick={handleSave} disabled={saving || !form.nombre.trim()}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50">
                {saving ? <><RefreshCw size={13} className="animate-spin" /> Guardando...</>
                  : saveSuccess ? <><CheckCircle size={13} /> Guardado</>
                  : <><Plus size={13} /> {editingPrinter ? 'Actualizar' : 'Registrar Impresora'}</>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedPrinter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setSelectedPrinter(null)} />
          <div className="relative w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-primary/10 rounded-lg"><Printer size={15} className="text-primary" /></div>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">{selectedPrinter.nombre}</h3>
                  {selectedPrinter.placa && <p className="text-[10px] text-muted-foreground font-mono">{selectedPrinter.placa}</p>}
                </div>
              </div>
              <button onClick={() => setSelectedPrinter(null)}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <X size={16} />
              </button>
            </div>
            <div className="p-6 grid grid-cols-2 gap-3 text-xs max-h-[60vh] overflow-y-auto">
              {([
                ['Marca', selectedPrinter.marca],
                ['Modelo', selectedPrinter.modelo],
                ['Tipo', selectedPrinter.tipo],
                ['Serial', selectedPrinter.serial],
                ['Estado', STATUS_LABELS[selectedPrinter.status || 'operational']],
                ['Dirección IP', selectedPrinter.direccion_ip],
                ['MAC Address', selectedPrinter.mac_address],
                ['Área', selectedPrinter.area],
                ['Sede', selectedPrinter.sede],
                ['Ubicación', selectedPrinter.ubicacion],
                ['Usuario', selectedPrinter.usuario_responsable],
                ['Técnico', selectedPrinter.tecnico_instalador],
                ['Subred', selectedPrinter.subred],
                ['Gateway', selectedPrinter.gateway],
                ['Puerto Switch', selectedPrinter.puerto_switch],
                ['Proveedor', selectedPrinter.proveedor],
                ['Garantía hasta', selectedPrinter.garantia_vencimiento],
                ['Observaciones', selectedPrinter.observaciones],
              ] as [string, string | undefined][]).map(([label, value]) => value ? (
                <div key={label}>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
                  <p className="text-foreground font-medium">{value}</p>
                </div>
              ) : null)}
            </div>
            <div className="px-6 pb-6 flex gap-3">
              <button onClick={() => { setSelectedPrinter(null); openEdit(selectedPrinter); }}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-xl transition-colors">
                <Edit2 size={13} /> Editar
              </button>
              <button onClick={() => handleDelete(selectedPrinter)}
                className="flex items-center justify-center gap-2 px-4 py-2 text-xs bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 rounded-xl transition-colors">
                <Trash2 size={13} /> Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
