'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { QRCodeSVG } from 'qrcode.react';
import {
  AlertTriangle, CheckCircle, Clock, MapPin, User, Tag,
  Monitor, Package, Share2, Wrench, XCircle, Loader,
} from 'lucide-react';

interface Ticket {
  id: string;
  ticket_id?: string;
  asset_tag?: string;
  asset_name?: string;
  category?: string;
  priority?: string;
  status?: string;
  location?: string;
  assignee?: string;
  created_at?: string;
  sla_due?: string;
  description?: string;
  resolution_type?: string;
  notes?: string;
}

const STATUS_STYLES: Record<string, string> = {
  open: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
  'in-progress': 'bg-amber-500/10 border-amber-500/30 text-amber-400',
  'pending-parts': 'bg-violet-500/10 border-violet-500/30 text-violet-400',
  resolved: 'bg-green-500/10 border-green-500/30 text-green-400',
  closed: 'bg-gray-500/10 border-gray-500/30 text-gray-400',
};
const STATUS_LABELS: Record<string, string> = {
  open: 'ABIERTO',
  'in-progress': 'EN PROGRESO',
  'pending-parts': 'ESPERANDO PIEZAS',
  resolved: 'RESUELTO',
  closed: 'CERRADO',
};
const PRIORITY_COLORS: Record<string, string> = {
  critical: 'text-red-400',
  high: 'text-orange-400',
  medium: 'text-amber-400',
  low: 'text-green-400',
};
const CATEGORY_COLORS: Record<string, string> = {
  hardware: 'bg-amber-500/10 text-amber-400',
  software: 'bg-blue-500/10 text-blue-400',
  network: 'bg-purple-500/10 text-purple-400',
  connectivity: 'bg-cyan-500/10 text-cyan-400',
};

function InfoRow({ icon, label, value, colorClass }: { icon: React.ReactNode; label: string; value?: string | null; colorClass?: string }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-white/10 last:border-0">
      <span className="text-gray-500 mt-0.5 shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] text-gray-500 uppercase tracking-wide">{label}</p>
        <p className={`text-sm font-medium mt-0.5 ${colorClass || 'text-white'}`}>{value}</p>
      </div>
    </div>
  );
}

export default function TicketPublicPage() {
  const params = useParams();
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const rawId = Array.isArray(params?.id) ? params.id[0] : params?.id;
      if (!rawId) { setNotFound(true); setLoading(false); return; }

      try {
        const supabase = createClient();
        // Try by UUID first
        let { data } = await supabase.from('tickets').select('*').eq('id', rawId).maybeSingle();
        // Try by ticket_id string (e.g. TKT-2026-089)
        if (!data) {
          const res = await supabase.from('tickets').select('*').eq('ticket_id', rawId).maybeSingle();
          data = res.data;
        }
        if (data) {
          setTicket(data);
        } else {
          setNotFound(true);
        }
      } catch {
        setNotFound(true);
      }
      setLoading(false);
    };
    load();
  }, [params]);

  const handleShare = async () => {
    const url = typeof window !== 'undefined' ? window.location.href : '';
    if (navigator.share) {
      try {
        await navigator.share({ title: `Ticket ${ticket?.ticket_id || ticket?.id}`, url });
        return;
      } catch { /* fallback */ }
    }
    try {
      await navigator.clipboard.writeText(url);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    } catch { alert(url); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <Loader size={32} className="text-indigo-400 animate-spin mx-auto mb-3" />
          <p className="text-gray-400 text-sm">Cargando ticket...</p>
        </div>
      </div>
    );
  }

  if (notFound || !ticket) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <XCircle size={28} className="text-red-400" />
          </div>
          <h1 className="text-white text-xl font-bold mb-2">Ticket no encontrado</h1>
          <p className="text-gray-400 text-sm">El código QR escaneado no corresponde a ningún ticket registrado.</p>
        </div>
      </div>
    );
  }

  const qrUrl = typeof window !== 'undefined' ? window.location.href : '';
  const statusStyle = STATUS_STYLES[ticket.status || 'open'] || STATUS_STYLES.open;
  const statusLabel = STATUS_LABELS[ticket.status || 'open'] || ticket.status?.toUpperCase();
  const isResolved = ticket.status === 'resolved' || ticket.status === 'closed';

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Top bar */}
      <div className="bg-gray-900 border-b border-white/10 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <Wrench size={16} className="text-indigo-400" />
          <span className="text-sm font-semibold text-white">AssetDesk</span>
          <span className="text-gray-500 text-xs">/ Ticket</span>
        </div>
        <button
          onClick={handleShare}
          className={`p-2 rounded-lg transition-colors ${shareSuccess ? 'text-green-400 bg-green-500/10' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}>
          {shareSuccess ? <CheckCircle size={16} /> : <Share2 size={16} />}
        </button>
      </div>

      <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {/* Hero card */}
        <div className={`border rounded-2xl p-5 ${isResolved ? 'bg-green-900/20 border-green-500/20' : 'bg-red-900/10 border-red-500/10'}`}>
          <div className="flex items-start gap-4">
            <div className="bg-white p-2 rounded-xl shrink-0">
              <QRCodeSVG value={qrUrl} size={72} level="M" includeMargin={false} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="font-mono text-xs text-indigo-300 font-bold">{ticket.ticket_id || ticket.id}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${statusStyle}`}>
                  {statusLabel}
                </span>
              </div>
              <h1 className="text-base font-bold text-white leading-snug">
                {ticket.description ? ticket.description.slice(0, 80) + (ticket.description.length > 80 ? '...' : '') : 'Sin descripción'}
              </h1>
              {ticket.category && (
                <span className={`inline-block mt-1.5 text-[10px] px-2 py-0.5 rounded-full font-semibold capitalize ${CATEGORY_COLORS[ticket.category] || 'bg-gray-500/10 text-gray-400'}`}>
                  {ticket.category}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="bg-white/5 border border-white/10 rounded-2xl px-4 py-2">
          <InfoRow icon={<Monitor size={13} />} label="Equipo" value={ticket.asset_name ? `${ticket.asset_name} (${ticket.asset_tag || ''})` : ticket.asset_tag} />
          <InfoRow icon={<MapPin size={13} />} label="Ubicación" value={ticket.location} />
          <InfoRow icon={<User size={13} />} label="Técnico Asignado" value={ticket.assignee} />
          <InfoRow icon={<Tag size={13} />} label="Prioridad" value={ticket.priority ? ticket.priority.toUpperCase() : undefined} colorClass={PRIORITY_COLORS[ticket.priority || 'low']} />
          <InfoRow icon={<Clock size={13} />} label="Creado" value={ticket.created_at ? new Date(ticket.created_at).toLocaleDateString('es-CO') : undefined} />
          <InfoRow icon={<AlertTriangle size={13} />} label="SLA Vence" value={ticket.sla_due ? new Date(ticket.sla_due).toLocaleDateString('es-CO') : undefined} />
        </div>

        {/* Description */}
        {ticket.description && (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Descripción del Problema</p>
            <p className="text-sm text-gray-200 leading-relaxed">{ticket.description}</p>
          </div>
        )}

        {/* Resolution */}
        {ticket.resolution_type && (
          <div className="bg-green-500/5 border border-green-500/20 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle size={14} className="text-green-400" />
              <p className="text-xs font-semibold text-green-400 uppercase tracking-wider">Resolución</p>
            </div>
            <p className="text-sm text-white font-medium">{ticket.resolution_type}</p>
            {ticket.notes && <p className="text-xs text-gray-400 mt-1 leading-relaxed">{ticket.notes}</p>}
          </div>
        )}

        {/* Asset link */}
        {ticket.asset_tag && (
          <a
            href={`/asset/${ticket.asset_tag}`}
            className="flex items-center gap-3 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-4 hover:bg-indigo-500/20 transition-colors">
            <Package size={18} className="text-indigo-400 shrink-0" />
            <div>
              <p className="text-xs text-gray-400">Ver ficha técnica del equipo</p>
              <p className="text-sm font-semibold text-indigo-300">{ticket.asset_name || ticket.asset_tag}</p>
            </div>
          </a>
        )}

        <div className="h-8" />
      </div>
    </div>
  );
}
