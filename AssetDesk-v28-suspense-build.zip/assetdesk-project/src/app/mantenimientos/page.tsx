'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { Wrench, Plus, Search, RefreshCw, Edit2, Trash2, X, CheckCircle, AlertTriangle, Clock, Calendar, User, ChevronUp, ChevronDown, ChevronsUpDown, Bell, AlertCircle, FileDown } from 'lucide-react';
import { maintenanceService, type MaintenanceSchedule } from '@/lib/services/assetService';
import { downloadTablePdf } from '@/lib/pdfReport';
import { createClient } from '@/lib/supabase/client';

const TIPOS_MANTENIMIENTO = [
  '', 'Preventivo', 'Correctivo', 'Limpieza', 'Calibración', 'Actualización de Firmware',
  'Revisión de Red', 'Cambio de Componente', 'Inspección General', 'Otro',
];

const ESTADO_LABELS: Record<string, string> = {
  pendiente: 'Pendiente', en_proceso: 'En Proceso', completado: 'Completado', cancelado: 'Cancelado',
};
const ESTADO_COLORS: Record<string, string> = {
  pendiente: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  en_proceso: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  completado: 'text-green-400 bg-green-500/10 border-green-500/20',
  cancelado: 'text-gray-400 bg-gray-500/10 border-gray-500/20',
};
const PRIORIDAD_COLORS: Record<string, string> = {
  baja: 'text-gray-400 bg-gray-500/10',
  media: 'text-blue-400 bg-blue-500/10',
  alta: 'text-amber-400 bg-amber-500/10',
  critica: 'text-red-400 bg-red-500/10',
};
const ASSET_TYPE_LABELS: Record<string, string> = {
  asset: 'Equipo', printer: 'Impresora', camera: 'Cámara/DVR',
};

const EMPTY_FORM: Omit<MaintenanceSchedule, 'id' | 'created_at' | 'updated_at'> = {
  asset_type: 'asset', asset_id: '', asset_name: '', asset_placa: '',
  tipo_mantenimiento: '', descripcion: '', fecha_programada: '',
  fecha_realizado: '', tecnico_asignado: '', estado: 'pendiente',
  prioridad: 'media', costo_estimado: undefined, costo_real: undefined,
  observaciones: '', alerta_enviada: false,
};

type SortKey = 'fecha_programada' | 'asset_name' | 'estado' | 'prioridad' | 'tipo_mantenimiento';
type SortDir = 'asc' | 'desc';

function getDaysUntil(dateStr: string): number {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const target = new Date(dateStr + 'T00:00:00');
  return Math.round((target.getTime() - today.getTime()) / 86400000);
}

function DaysChip({ dateStr, estado }: { dateStr: string; estado: string }) {
  if (estado === 'completado' || estado === 'cancelado') return null;
  const days = getDaysUntil(dateStr);
  if (days < 0) return <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 font-medium">{Math.abs(days)}d vencido</span>;
  if (days === 0) return <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 font-medium">Hoy</span>;
  if (days <= 7) return <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 font-medium">en {days}d</span>;
  if (days <= 30) return <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 font-medium">en {days}d</span>;
  return <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground font-medium">en {days}d</span>;
}

export default function MaintenancePage() {
  const [schedules, setSchedules] = useState<MaintenanceSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [estadoFilter, setEstadoFilter] = useState('all');
  const [prioridadFilter, setPrioridadFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('fecha_programada');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [showForm, setShowForm] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<MaintenanceSchedule | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [overdueCount, setOverdueCount] = useState(0);
  const [upcomingCount, setUpcomingCount] = useState(0);

  const loadSchedules = useCallback(async () => {
    setLoading(true);
    const [all, overdue, upcoming] = await Promise.all([
      maintenanceService.getAll(),
      maintenanceService.getOverdue(),
      maintenanceService.getUpcoming(7),
    ]);
    setSchedules(all);
    setOverdueCount(overdue.length);
    setUpcomingCount(upcoming.length);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadSchedules();
    const supabase = createClient();
    const channel = supabase
      .channel('maintenance_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'maintenance_schedules' }, () => loadSchedules())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadSchedules]);

  const handleChange = (name: string, value: string) => setForm(prev => ({ ...prev, [name]: value }));

  const openAdd = () => {
    setForm({ ...EMPTY_FORM });
    setEditingSchedule(null);
    setSaveError(null);
    setShowForm(true);
  };

  const openEdit = (s: MaintenanceSchedule) => {
    setForm({
      asset_type: s.asset_type, asset_id: s.asset_id, asset_name: s.asset_name || '',
      asset_placa: s.asset_placa || '', tipo_mantenimiento: s.tipo_mantenimiento,
      descripcion: s.descripcion || '', fecha_programada: s.fecha_programada,
      fecha_realizado: s.fecha_realizado || '', tecnico_asignado: s.tecnico_asignado || '',
      estado: s.estado, prioridad: s.prioridad, costo_estimado: s.costo_estimado,
      costo_real: s.costo_real, observaciones: s.observaciones || '', alerta_enviada: s.alerta_enviada || false,
    });
    setEditingSchedule(s);
    setSaveError(null);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.asset_name?.trim()) { setSaveError('El nombre del activo es obligatorio'); return; }
    if (!form.fecha_programada) { setSaveError('La fecha programada es obligatoria'); return; }
    if (!form.tipo_mantenimiento) { setSaveError('El tipo de mantenimiento es obligatorio'); return; }
    setSaving(true); setSaveError(null);
    try {
      const payload = {
        ...form,
        asset_id: form.asset_id || '00000000-0000-0000-0000-000000000000',
        fecha_realizado: form.fecha_realizado || undefined,
        costo_estimado: form.costo_estimado || undefined,
        costo_real: form.costo_real || undefined,
      };
      let result: MaintenanceSchedule | null;
      if (editingSchedule) {
        result = await maintenanceService.update(editingSchedule.id, payload);
      } else {
        result = await maintenanceService.create(payload);
      }
      if (result) {
        setShowForm(false);
        setEditingSchedule(null);
        loadSchedules();
      } else {
        setSaveError('No se pudo guardar. Intenta de nuevo.');
      }
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'Error al guardar.');
    }
    finally { setSaving(false); }
  };

  const handleDelete = async (s: MaintenanceSchedule) => {
    if (!confirm(`¿Eliminar este mantenimiento programado?`)) return;
    await maintenanceService.delete(s.id);
    loadSchedules();
  };

  const handleMarkComplete = async (s: MaintenanceSchedule) => {
    const today = new Date().toISOString().split('T')[0];
    await maintenanceService.update(s.id, { estado: 'completado', fecha_realizado: today });
    loadSchedules();
  };

  const handleExportReport = async () => {
    try {
      await downloadTablePdf(
        'Informe de mantenimientos',
        ['Placa', 'Activo', 'Tipo', 'Programado', 'Estado', 'Técnico', 'Observaciones'],
        filtered.map((item) => [
          item.asset_placa || 'N/A',
          item.asset_name || '',
          item.tipo_mantenimiento || '',
          item.fecha_programada || '',
          ESTADO_LABELS[item.estado] || item.estado,
          item.tecnico_asignado || 'Sin asignar',
          item.observaciones || '',
        ]),
        `informe_mantenimientos_${new Date().toISOString().slice(0, 10)}`,
      );
    } catch (error) {
      console.error('Error exportando informe de mantenimientos:', error);
      alert('No se pudo descargar el informe de mantenimientos.');
    }
  };

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  const filtered = useMemo(() => {
    let data = [...schedules];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(s =>
        (s.asset_name || '').toLowerCase().includes(q) ||
        (s.asset_placa || '').toLowerCase().includes(q) ||
        (s.tipo_mantenimiento || '').toLowerCase().includes(q) ||
        (s.tecnico_asignado || '').toLowerCase().includes(q)
      );
    }
    if (estadoFilter !== 'all') data = data.filter(s => s.estado === estadoFilter);
    if (prioridadFilter !== 'all') data = data.filter(s => s.prioridad === prioridadFilter);
    data.sort((a, b) => {
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [schedules, search, estadoFilter, prioridadFilter, sortKey, sortDir]);

  const metrics = useMemo(() => ({
    total: schedules.length,
    pendiente: schedules.filter(s => s.estado === 'pendiente').length,
    en_proceso: schedules.filter(s => s.estado === 'en_proceso').length,
    completado: schedules.filter(s => s.estado === 'completado').length,
  }), [schedules]);

  return (
    <AppLayout>
      <Topbar title="Mantenimientos" subtitle="Programación y seguimiento de mantenimientos preventivos y correctivos" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Alert banners */}
        {overdueCount > 0 && (
          <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
            <AlertTriangle size={16} className="text-red-400 shrink-0" />
            <p className="text-sm text-red-400 font-medium">
              {overdueCount} mantenimiento{overdueCount > 1 ? 's' : ''} vencido{overdueCount > 1 ? 's' : ''} — requieren atención inmediata
            </p>
          </div>
        )}
        {upcomingCount > 0 && (
          <div className="flex items-center gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
            <Bell size={16} className="text-amber-400 shrink-0" />
            <p className="text-sm text-amber-400 font-medium">
              {upcomingCount} mantenimiento{upcomingCount > 1 ? 's' : ''} programado{upcomingCount > 1 ? 's' : ''} en los próximos 7 días
            </p>
          </div>
        )}

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total', value: metrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Wrench },
            { label: 'Pendientes', value: metrics.pendiente, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: Clock },
            { label: 'En Proceso', value: metrics.en_proceso, color: 'text-blue-400', bg: 'bg-blue-500/10', icon: AlertCircle },
            { label: 'Completados', value: metrics.completado, color: 'text-green-400', bg: 'bg-green-500/10', icon: CheckCircle },
          ].map(m => {
            const MIcon = m.icon;
            return (
              <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${m.bg} flex items-center justify-center shrink-0`}>
                  <MIcon size={18} className={m.color} />
                </div>
                <div>
                  <p className={`text-xl font-bold ${m.color}`}>{m.value}</p>
                  <p className="text-xs text-muted-foreground">{m.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-48">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por activo, tipo, técnico..."
              className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
          </div>
          <select value={estadoFilter} onChange={e => setEstadoFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-secondary border border-border rounded-lg text-muted-foreground focus:outline-none focus:border-primary">
            <option value="all">Todos los estados</option>
            {Object.entries(ESTADO_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={prioridadFilter} onChange={e => setPrioridadFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-secondary border border-border rounded-lg text-muted-foreground focus:outline-none focus:border-primary">
            <option value="all">Todas las prioridades</option>
            {['baja', 'media', 'alta', 'critica'].map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
          </select>
          <div className="flex items-center gap-2 ml-auto">
            <button onClick={loadSchedules} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
              <RefreshCw size={14} />
            </button>
            <button onClick={handleExportReport}
              className="flex items-center gap-2 px-3 py-2 bg-secondary border border-border text-muted-foreground hover:text-foreground text-xs rounded-lg transition-colors">
              <FileDown size={14} /> Informe PDF
            </button>
            <button onClick={openAdd}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-xs font-medium rounded-lg hover:bg-primary/90 transition-colors">
              <Plus size={14} /> Programar Mantenimiento
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  {[
                    { key: 'fecha_programada', label: 'Fecha' },
                    { key: 'asset_name', label: 'Activo' },
                    { key: 'tipo_mantenimiento', label: 'Tipo' },
                    { key: null, label: 'Tipo Activo' },
                    { key: null, label: 'Técnico' },
                    { key: 'prioridad', label: 'Prioridad' },
                    { key: 'estado', label: 'Estado' },
                    { key: null, label: 'Acciones' },
                  ].map((col, i) => (
                    <th key={i} className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider text-[10px] ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                      onClick={() => col.key && handleSort(col.key as SortKey)}>
                      <div className="flex items-center gap-1">
                        {col.label}
                        {col.key && <SortIcon col={col.key as SortKey} />}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                    <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando...
                  </td></tr>
                ) : filtered.length === 0 ? (
                  <tr><td colSpan={8} className="px-4 py-12 text-center">
                    <Wrench size={32} className="mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">No hay mantenimientos programados</p>
                    <button onClick={openAdd} className="mt-2 text-xs text-primary hover:underline">Programar primero</button>
                  </td></tr>
                ) : filtered.map((s, idx) => {
                  const isOverdue = s.estado !== 'completado' && s.estado !== 'cancelado' && getDaysUntil(s.fecha_programada) < 0;
                  return (
                    <tr key={s.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors ${idx % 2 === 0 ? '' : 'bg-secondary/10'} ${isOverdue ? 'bg-red-500/5' : ''}`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Calendar size={12} className={isOverdue ? 'text-red-400' : 'text-muted-foreground'} />
                          <span className={isOverdue ? 'text-red-400 font-medium' : 'text-foreground'}>{s.fecha_programada}</span>
                        </div>
                        <DaysChip dateStr={s.fecha_programada} estado={s.estado} />
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-foreground">{s.asset_name || '—'}</div>
                        {s.asset_placa && <div className="text-[10px] text-muted-foreground font-mono">{s.asset_placa}</div>}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{s.tipo_mantenimiento}</td>
                      <td className="px-4 py-3">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-secondary text-muted-foreground">
                          {ASSET_TYPE_LABELS[s.asset_type] || s.asset_type}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {s.tecnico_asignado ? (
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <User size={10} />{s.tecnico_asignado}
                          </div>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium ${PRIORIDAD_COLORS[s.prioridad]}`}>
                          {s.prioridad.charAt(0).toUpperCase() + s.prioridad.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium border ${ESTADO_COLORS[s.estado]}`}>
                          {ESTADO_LABELS[s.estado]}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          {s.estado !== 'completado' && s.estado !== 'cancelado' && (
                            <button onClick={() => handleMarkComplete(s)} title="Marcar completado"
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-green-400 hover:bg-green-500/10 transition-colors">
                              <CheckCircle size={13} />
                            </button>
                          )}
                          <button onClick={() => openEdit(s)} title="Editar"
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                            <Edit2 size={13} />
                          </button>
                          <button onClick={() => handleDelete(s)} title="Eliminar"
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Wrench size={16} className="text-primary" />
                </div>
                <h2 className="font-semibold text-foreground text-sm">
                  {editingSchedule ? 'Editar Mantenimiento' : 'Programar Mantenimiento'}
                </h2>
              </div>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors"><X size={16} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {/* Asset info */}
                <div className="col-span-2">
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Tipo de Activo</label>
                  <select value={form.asset_type} onChange={e => handleChange('asset_type', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full">
                    <option value="asset">Equipo de Cómputo</option>
                    <option value="printer">Impresora</option>
                    <option value="camera">Cámara / DVR</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Nombre del Activo *</label>
                  <input value={form.asset_name || ''} onChange={e => handleChange('asset_name', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full"
                    placeholder="Nombre del equipo" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Placa / Inventario</label>
                  <input value={form.asset_placa || ''} onChange={e => handleChange('asset_placa', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full"
                    placeholder="INV-2026-0001" />
                </div>
                {/* Maintenance details */}
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Tipo de Mantenimiento *</label>
                  <select value={form.tipo_mantenimiento} onChange={e => handleChange('tipo_mantenimiento', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full">
                    {TIPOS_MANTENIMIENTO.map(t => <option key={t} value={t}>{t || '— Seleccionar —'}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Fecha Programada *</label>
                  <input type="date" value={form.fecha_programada} onChange={e => handleChange('fecha_programada', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Prioridad</label>
                  <select value={form.prioridad} onChange={e => handleChange('prioridad', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full">
                    <option value="baja">Baja</option>
                    <option value="media">Media</option>
                    <option value="alta">Alta</option>
                    <option value="critica">Crítica</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Estado</label>
                  <select value={form.estado} onChange={e => handleChange('estado', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full">
                    <option value="pendiente">Pendiente</option>
                    <option value="en_proceso">En Proceso</option>
                    <option value="completado">Completado</option>
                    <option value="cancelado">Cancelado</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Técnico Asignado</label>
                  <input value={form.tecnico_asignado || ''} onChange={e => handleChange('tecnico_asignado', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full"
                    placeholder="Nombre del técnico" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Fecha Realizado</label>
                  <input type="date" value={form.fecha_realizado || ''} onChange={e => handleChange('fecha_realizado', e.target.value)}
                    className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full" />
                </div>
                <div className="col-span-2">
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Descripción</label>
                  <textarea value={form.descripcion || ''} onChange={e => handleChange('descripcion', e.target.value)}
                    rows={3} className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none"
                    placeholder="Descripción del mantenimiento..." />
                </div>
                <div className="col-span-2">
                  <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Observaciones</label>
                  <textarea value={form.observaciones || ''} onChange={e => handleChange('observaciones', e.target.value)}
                    rows={2} className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none"
                    placeholder="Notas adicionales..." />
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-border sticky bottom-0 bg-card">
              {saveError && <p className="text-xs text-red-400 mr-auto">{saveError}</p>}
              <button onClick={() => setShowForm(false)} className="px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
                Cancelar
              </button>
              <button onClick={handleSave} disabled={saving}
                className="px-5 py-2 text-xs bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center gap-2">
                {saving ? <><RefreshCw size={12} className="animate-spin" />Guardando...</> : 'Guardar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
