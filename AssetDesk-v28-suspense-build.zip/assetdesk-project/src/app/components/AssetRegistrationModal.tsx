'use client';

import React, { useState, useRef, useEffect } from 'react';
import { X, ChevronDown, ChevronUp, Monitor, Cpu, HardDrive, Network, MapPin, User, Printer, Keyboard, FileText, Camera, Upload, Shield, Zap, Wifi, Battery, Settings, AlertTriangle } from 'lucide-react';
import { assetService, ipService, type Asset } from '@/lib/services/assetService';
import AppImage from '@/components/ui/AppImage';

export type AssetFormData = Omit<Asset, 'id' | 'created_at' | 'updated_at'>;

const EMPTY_FORM: AssetFormData = {
  placa: 'INV-2026-', serial: '', sede: '', n_ficha: '', tag: '',
  marca: '', modelo: '', n_producto: '', tipo_equipo: 'Desktop',
  sistema_operativo: '', service_pack: '', idioma: 'ESP', arquitectura: 'x64', licencia_os: '',
  procesador_marca: '', procesador_tipo: '', procesador_velocidad: '', procesador_nucleos: '', procesador_generacion: '',
  ram_capacidad: '', ram_tipo: 'DDR4', ram_slot: '', ram_slots_totales: '', ram_slots_libres: '',
  disco_capacidad: '', disco_tecnologia: 'SSD', disco_interfaz: '', disco_rpm: '',
  disco2_capacidad: '', disco2_tecnologia: '',
  unidad_optica: 'NO', unidad_marca: '',
  gpu_marca: '', gpu_modelo: '', gpu_vram: '', gpu_tipo: '',
  display_tamano: '', display_resolucion: '', display_tipo: '', display_frecuencia: '', display_tactil: 'NO',
  bateria_estado: '', bateria_ciclos: '', bateria_capacidad: '', bateria_modelo: '',
  firmware_version: '', bios_version: '', tpm_version: '', secure_boot: '',
  puertos_usb: '', puertos_usb_c: '', puertos_hdmi: '', puertos_thunderbolt: '', lector_tarjetas: 'NO', bluetooth: '', wifi_estandar: '',
  teclado_marca: '', mouse_marca: '', web_cam: 'NO',
  monitor_marca: '', monitor_modelo: '', monitor_tipo: 'LCD', monitor_tamano: '', monitor_serial: '',
  impresora_marca: '', impresora_tipo: '', impresora_serial: '', impresora_modelo: '', impresora_mac: '',
  nombre_equipo: '', en_red: 'SI', direccion_ip: '', mac_address: '',
  subred: '255.255.255.0', gateway: '192.168.1.1', dns_primario: '8.8.8.8', dns_secundario: '8.8.4.4', puerto_switch: '',
  usuario_responsable: '', area: '', ubicacion: '', fecha_asignacion: '', tecnico_instalador: '',
  numero_inventario_anterior: '', garantia_vencimiento: '', garantia_tipo: '', proveedor: '', orden_compra: '', valor_compra: undefined, fecha_compra: '',
  office_version: '', antivirus: '', software_adicional: '',
  foto_url: '',
  status: 'operational',
  observaciones: '', recomendaciones: '',
  has_qr: true,
};

// ─── Dropdown Lists ───────────────────────────────────────────────────────────

const MARCAS_EQUIPO = [
  '', 'HP', 'Dell', 'Lenovo', 'Asus', 'Acer', 'Apple', 'Microsoft', 'Samsung', 'Toshiba',
  'Sony', 'LG', 'Huawei', 'Xiaomi', 'Fujitsu', 'Panasonic', 'Getac', 'Zebra', 'Honeywell',
  'Razer', 'MSI', 'Gigabyte', 'Intel (NUC)', 'Supermicro', 'IBM', 'Cisco', 'Otra',
];

const PROVEEDORES = [
  '', 'Ingram Micro', 'Tech Data', 'Synnex', 'Arrow Electronics', 'Avnet', 'CDW',
  'Insight Direct', 'SHI International', 'PC Connection', 'Connection', 'Zones',
  'CompuDisti', 'Intcomex', 'Nexsys', 'Micromax', 'Computec', 'Distrimax',
  'Almacenes Éxito', 'Alkosto', 'Falabella', 'Linio', 'MercadoLibre',
  'Proveedor Local', 'Importación Directa', 'Otro',
];

const TIPOS_EQUIPO = [
  'Desktop', 'Laptop', 'Laptop Rugged', 'Workstation', 'Server', 'All-in-One',
  'Mini PC', 'Tablet', 'Thin Client', 'NUC', 'Gaming PC', 'Chromebook',
  'Convertible 2-en-1', 'Estación de Trabajo Móvil', 'Blade Server',
  'Torre Servidor', 'Rack Server', 'Micro Server', 'Otro',
];

const MARCAS_PROCESADOR = [
  '', 'Intel', 'AMD', 'Apple', 'Qualcomm', 'MediaTek', 'Samsung Exynos',
  'NVIDIA (Tegra)', 'Ampere', 'IBM (POWER)', 'ARM', 'Otro',
];

const MODELOS_PROCESADOR = [
  '',
  // Intel Core Ultra (Meteor Lake / Arrow Lake)
  'Intel Core Ultra 9 285H', 'Intel Core Ultra 7 265H', 'Intel Core Ultra 5 245H',
  'Intel Core Ultra 9 185H', 'Intel Core Ultra 7 165H', 'Intel Core Ultra 5 125H',
  // Intel Core 13a Gen
  'Intel Core i9-13900K', 'Intel Core i9-13900H', 'Intel Core i7-13700K', 'Intel Core i7-13700H',
  'Intel Core i5-13600K', 'Intel Core i5-13500H', 'Intel Core i3-13100',
  // Intel Core 12a Gen
  'Intel Core i9-12900K', 'Intel Core i7-12700K', 'Intel Core i7-12700H',
  'Intel Core i5-12600K', 'Intel Core i5-12500H', 'Intel Core i3-12100',
  // Intel Core 11a Gen
  'Intel Core i9-11900K', 'Intel Core i7-11700K', 'Intel Core i7-1165G7',
  'Intel Core i5-11600K', 'Intel Core i5-1135G7', 'Intel Core i3-1115G4',
  // Intel Core 10a Gen
  'Intel Core i9-10900K', 'Intel Core i7-10700K', 'Intel Core i7-10750H',
  'Intel Core i5-10600K', 'Intel Core i5-10300H', 'Intel Core i3-10100',
  // Intel Xeon
  'Intel Xeon W-3400', 'Intel Xeon W-2400', 'Intel Xeon Gold 6400',
  'Intel Xeon Silver 4400', 'Intel Xeon E-2300',
  // Intel Celeron / Pentium
  'Intel Celeron N4500', 'Intel Celeron J4125', 'Intel Pentium Gold G7400',
  // AMD Ryzen 7000
  'AMD Ryzen 9 7950X', 'AMD Ryzen 9 7900X', 'AMD Ryzen 7 7700X', 'AMD Ryzen 7 7700',
  'AMD Ryzen 5 7600X', 'AMD Ryzen 5 7600', 'AMD Ryzen 5 7530U', 'AMD Ryzen 3 7300X',
  // AMD Ryzen 6000 / 5000
  'AMD Ryzen 9 6900HX', 'AMD Ryzen 7 6800H', 'AMD Ryzen 5 6600H',
  'AMD Ryzen 9 5900X', 'AMD Ryzen 7 5800X', 'AMD Ryzen 5 5600X', 'AMD Ryzen 5 5500U',
  'AMD Ryzen 3 5300U',
  // AMD EPYC
  'AMD EPYC 9654', 'AMD EPYC 9554', 'AMD EPYC 7763', 'AMD EPYC 7543',
  // Apple Silicon
  'Apple M4 Max', 'Apple M4 Pro', 'Apple M4', 'Apple M3 Max', 'Apple M3 Pro',
  'Apple M3', 'Apple M2 Ultra', 'Apple M2 Max', 'Apple M2 Pro', 'Apple M2',
  'Apple M1 Ultra', 'Apple M1 Max', 'Apple M1 Pro', 'Apple M1',
  // Qualcomm
  'Qualcomm Snapdragon X Elite', 'Qualcomm Snapdragon X Plus',
  'Qualcomm Snapdragon 8cx Gen 3',
  'Otro',
];

const MARCAS_MONITOR = [
  '', 'Dell', 'LG', 'Samsung', 'HP', 'Asus', 'Acer', 'BenQ', 'ViewSonic',
  'AOC', 'Philips', 'Lenovo', 'Apple', 'MSI', 'Gigabyte', 'Alienware',
  'Eizo', 'NEC', 'Iiyama', 'Hannspree', 'Otra',
];

const TIPOS_MONITOR = [
  'LCD', 'LED', 'IPS', 'IPS LED', 'OLED', 'AMOLED', 'TN', 'VA', 'MVA', 'PVA',
  'Curved IPS', 'Curved VA', 'Ultra-Wide IPS', 'Ultra-Wide VA',
  'Mini-LED', 'QLED', 'Nano IPS', 'WQHD', '4K UHD', 'Táctil',
];

const MARCAS_IMPRESORA = [
  '', 'HP', 'Canon', 'Epson', 'Brother', 'Xerox', 'Lexmark', 'Samsung',
  'Ricoh', 'Kyocera', 'Konica Minolta', 'Sharp', 'OKI', 'Pantum',
  'Zebra', 'Datamax', 'Honeywell', 'TSC', 'Citizen', 'Star Micronics', 'Otra',
];

const TIPOS_IMPRESORA = [
  '', 'Láser B&N', 'Láser Color', 'Inkjet', 'Multifuncional Láser B&N',
  'Multifuncional Láser Color', 'Multifuncional Inkjet', 'Térmica Directa',
  'Térmica por Transferencia', 'Matricial / Punto', 'Plotter Inkjet',
  'Plotter de Corte', 'Sublimación', 'Impresora de Etiquetas',
  'Impresora de Tarjetas', 'Impresora de Recibos', 'Impresora 3D', 'Otra',
];

// ─── Helper: generate next inventory number ──────────────────────────────────

function generateInventoryPlate(sequence: number): string {
  const padded = String(sequence).padStart(4, '0');
  return `INV-2026-${padded}`;
}

// ─── Section & Field components ──────────────────────────────────────────────

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

function Section({ title, icon, children, defaultOpen = true }: SectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <button type="button" onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 bg-secondary/50 hover:bg-secondary transition-colors">
        <div className="flex items-center gap-2 text-xs font-semibold text-foreground uppercase tracking-wider">{icon}{title}</div>
        {open ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
      </button>
      {open && <div className="p-4 grid grid-cols-2 gap-3">{children}</div>}
    </div>
  );
}

function Field({ label, name, value, onChange, type = 'text', options, span = 1, placeholder, readOnly }: {
  label: string; name: string; value: string | number | undefined; onChange: (n: string, v: string) => void;
  type?: string; options?: string[]; span?: number; placeholder?: string; readOnly?: boolean;
}) {
  const cls = `bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full ${readOnly ? 'opacity-70 cursor-not-allowed' : ''}`;
  const wrapCls = span === 2 ? 'col-span-2' : '';
  return (
    <div className={wrapCls}>
      <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">{label}</label>
      {options ? (
        <select name={name} value={String(value || '')} onChange={e => onChange(name, e.target.value)} className={cls} disabled={readOnly}>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input type={type} name={name} value={String(value || '')} onChange={e => onChange(name, e.target.value)} className={cls} placeholder={placeholder || label} readOnly={readOnly} />
      )}
    </div>
  );
}

interface Props {
  onClose: () => void;
  onSave: (data: AssetFormData) => void;
  initialData?: Partial<AssetFormData>;
  loading?: boolean;
}

export default function AssetRegistrationModal({ onClose, onSave, initialData, loading = false }: Props) {
  const [form, setForm] = useState<AssetFormData>({ ...EMPTY_FORM, ...initialData });
  const [photoPreview, setPhotoPreview] = useState<string>(initialData?.foto_url || '');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [ipWarning, setIpWarning] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const tipoEquipo = String(form.tipo_equipo || '').toLowerCase();
  const isPrinter = tipoEquipo.includes('impresora') || tipoEquipo.includes('printer');
  const isPortable = /laptop|tablet|convertible|móvil|movil/.test(tipoEquipo);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Pre-fill plate with INV-2026- prefix for new assets
  useEffect(() => {
    if (!initialData?.placa) {
      assetService.getAll().then((assets) => {
        const count = Array.isArray(assets) ? assets.length + 1 : 1;
        const generatedPlate = generateInventoryPlate(count);
        setForm(prev => ({ ...prev, placa: generatedPlate }));
      }).catch(() => {
        setForm(prev => ({ ...prev, placa: 'INV-2026-' }));
      });
    }
  }, [initialData?.placa]);

  const handleChange = (name: string, value: string) => {
    setForm(prev => ({ ...prev, [name]: value }));
    if (name === 'direccion_ip') {
      setIpWarning(null);
    }
  };

  const handleIpBlur = async () => {
    const ip = form.direccion_ip?.trim();
    if (!ip) return;
    try {
      const existing = await ipService.getByAddress(ip) as { direccion_ip: string; status?: string; nombre?: string; asset_id?: string } | null;
      if (existing && (existing.status === 'ocupada' || existing.asset_id)) {
        const name = existing.nombre ? ` (${existing.nombre})` : '';
        setIpWarning(`⚠️ Esta IP ya está marcada como "ocupada"${name} en el sistema de gestión de IPs.`);
      } else {
        setIpWarning(null);
      }
    } catch {
      setIpWarning(null);
    }
  };

  const handlePhotoFile = async (file: File) => {
    const compressed = await compressImage(file);
    setPhotoFile(compressed);
    const reader = new FileReader();
    reader.onload = (e) => setPhotoPreview(e.target?.result as string);
    reader.readAsDataURL(compressed);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let finalForm = { ...form };

    if (photoFile && form.placa) {
      setUploading(true);
      const url = await assetService.uploadPhoto(form.placa, photoFile);
      if (url) finalForm = { ...finalForm, foto_url: url };
      setUploading(false);
    }

    // IP synchronization is centralized in assetService after the asset is saved.
    // This guarantees asset_id is available and also releases the old IP on edits.
    onSave(finalForm);
  };

  // Compress image to JPEG, max 800px wide, max ~200KB
  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const img = new window.Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        const MAX_W = 800;
        const scale = img.width > MAX_W ? MAX_W / img.width : 1;
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (!ctx) { resolve(file); return; }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(
          (blob) => {
            if (!blob) { resolve(file); return; }
            const compressed = new File([blob], file.name.replace(/\.[^.]+$/, '.jpg'), { type: 'image/jpeg' });
            resolve(compressed);
          },
          'image/jpeg',
          0.75
        );
      };
      img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-3xl bg-card border border-border rounded-2xl flex flex-col max-h-[92vh] mx-4">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div>
            <h2 className="text-base font-semibold text-foreground">Registro de Equipo</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Hoja de Vida — Equipos de Cómputo</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            <X size={16} />
          </button>
        </div>

        <form id="asset-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-4">

          {/* Photo Section */}
          <Section title="Foto del Equipo" icon={<Camera size={13} />} defaultOpen={true}>
            <div className="col-span-2 flex items-center gap-4">
              <div className="w-24 h-24 rounded-xl border-2 border-dashed border-border bg-secondary/50 flex items-center justify-center overflow-hidden shrink-0">
                {photoPreview ? (
                  <AppImage src={photoPreview} alt="Foto del equipo" width={640} height={360} unoptimized className="w-full h-full object-cover rounded-xl" />
                ) : (
                  <Camera size={24} className="text-muted-foreground" />
                )}
              </div>
              <div className="flex flex-col gap-2">
                <button type="button" onClick={() => cameraInputRef.current?.click()}
                  className="flex items-center gap-2 px-3 py-2 bg-primary/10 border border-primary/30 text-primary text-xs rounded-lg hover:bg-primary/20 transition-colors">
                  <Camera size={13} /> Tomar Foto
                </button>
                <button type="button" onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-3 py-2 bg-secondary border border-border text-muted-foreground text-xs rounded-lg hover:text-foreground hover:bg-secondary/80 transition-colors">
                  <Upload size={13} /> Subir Imagen
                </button>
                <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden"
                  onChange={e => e.target.files?.[0] && handlePhotoFile(e.target.files[0])} />
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                  onChange={e => e.target.files?.[0] && handlePhotoFile(e.target.files[0])} />
                {photoPreview && (
                  <button type="button" onClick={() => { setPhotoPreview(''); setPhotoFile(null); }}
                    className="text-[10px] text-red-400 hover:text-red-300">Eliminar foto</button>
                )}
              </div>
            </div>
          </Section>

          {/* Identification */}
          <Section title="Identificación del Equipo" icon={<FileText size={13} />}>
            {/* Inventory plate — manual entry with fixed prefix */}
            <div className="col-span-2">
              <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">
                Placa de Inventario *
                <span className="ml-2 text-primary normal-case font-normal">(Prefijo fijo: INV-2026-)</span>
              </label>
              <div className="flex gap-2 items-center">
                <span className="shrink-0 px-3 py-2 bg-primary/10 border border-primary/30 rounded-lg text-xs text-primary font-mono font-semibold select-none">
                  INV-2026-
                </span>
                <input
                  type="text"
                  name="placa_numero"
                  value={(form.placa || '').startsWith('INV-2026-') ? (form.placa || '').slice(9) : (form.placa || '')}
                  onChange={e => {
                    const raw = e.target.value.replace(/[^0-9A-Za-z-]/g, '');
                    handleChange('placa', `INV-2026-${raw}`);
                  }}
                  className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground font-mono font-semibold focus:outline-none focus:border-primary w-full"
                  placeholder="0001"
                  maxLength={20}
                />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">
                Placa completa: <span className="text-primary font-mono">{form.placa || 'INV-2026-'}</span>
              </p>
            </div>
            <Field label="Serial PC *" name="serial" value={form.serial} onChange={handleChange} />
            <Field label="Sede / Institución" name="sede" value={form.sede} onChange={handleChange} />
            <Field label="N° Ficha" name="n_ficha" value={form.n_ficha} onChange={handleChange} />
            <div>
              <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Estado</label>
              <select
                name="status"
                value={form.status || 'operational'}
                onChange={e => handleChange('status', e.target.value)}
                className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary w-full"
              >
                <option value="operational">Operativo</option>
                <option value="maintenance">Mantenimiento</option>
                <option value="critical">Crítico</option>
                <option value="decommissioned">Dado de Baja</option>
              </select>
            </div>
          </Section>

          {/* Equipment Data */}
          <Section title="Datos del Equipo" icon={<Monitor size={13} />}>
            <Field label="Marca *" name="marca" value={form.marca} onChange={handleChange}
              options={MARCAS_EQUIPO} />
            <Field label="Modelo *" name="modelo" value={form.modelo} onChange={handleChange} />
            <Field label="N° Producto / Part Number" name="n_producto" value={form.n_producto} onChange={handleChange} />
            <Field label="Tipo de Equipo" name="tipo_equipo" value={form.tipo_equipo} onChange={handleChange}
              options={TIPOS_EQUIPO} />
            <Field label="Proveedor" name="proveedor" value={form.proveedor} onChange={handleChange}
              options={PROVEEDORES} />
            <Field label="Orden de Compra / PO" name="orden_compra" value={form.orden_compra} onChange={handleChange} placeholder="OC-2024-001" />
            <Field label="Vencimiento Garantía" name="garantia_vencimiento" value={form.garantia_vencimiento} onChange={handleChange} type="date" />
            <Field label="Tipo de Garantía" name="garantia_tipo" value={form.garantia_tipo} onChange={handleChange}
              options={['', 'Fabricante', 'Distribuidor', 'Extendida', 'On-Site', 'Carry-In', 'NBD', 'Sin Garantía']} />
          </Section>

          {/* OS */}
          <Section title="Sistema Operativo" icon={<Shield size={13} />} defaultOpen={false}>
            <Field label="Sistema Operativo" name="sistema_operativo" value={form.sistema_operativo} onChange={handleChange}
              options={['', 'Windows 11 Pro', 'Windows 11 Home', 'Windows 11 Enterprise', 'Windows 10 Pro', 'Windows 10 Home', 'Windows 10 Enterprise', 'Windows Server 2022', 'Windows Server 2019', 'Windows Server 2016', 'Ubuntu 24.04 LTS', 'Ubuntu 22.04 LTS', 'Ubuntu 20.04 LTS', 'Debian 12', 'Fedora 40', 'macOS Sonoma 14', 'macOS Ventura 13', 'macOS Monterey 12', 'Chrome OS', 'Android', 'Otro']} />
            <Field label="Service Pack / Build" name="service_pack" value={form.service_pack} onChange={handleChange} placeholder="22H2 / Build 22621" />
            <Field label="Idioma" name="idioma" value={form.idioma} onChange={handleChange} options={['ESP', 'ING', 'OTRO']} />
            <Field label="Arquitectura" name="arquitectura" value={form.arquitectura} onChange={handleChange} options={['x64', 'x86', 'ARM64']} />
            <Field label="Licencia Original S.O." name="licencia_os" value={form.licencia_os} onChange={handleChange} span={2} />
            <Field label="Office / Suite Ofimática" name="office_version" value={form.office_version} onChange={handleChange}
              options={['', 'Microsoft 365 Business', 'Microsoft 365 Personal', 'Office 2021 Pro', 'Office 2021 Home', 'Office 2019', 'Office 2016', 'LibreOffice 7', 'Google Workspace', 'WPS Office', 'Ninguno']} />
            <Field label="Antivirus" name="antivirus" value={form.antivirus} onChange={handleChange}
              options={['', 'Windows Defender', 'Kaspersky Endpoint', 'Norton 360', 'McAfee Endpoint', 'ESET Endpoint', 'Bitdefender GravityZone', 'Avast Business', 'Sophos', 'CrowdStrike', 'Ninguno']} />
            <Field label="Software Adicional" name="software_adicional" value={form.software_adicional} onChange={handleChange} span={2} placeholder="AutoCAD, Adobe CC, SAP..." />
          </Section>

          {/* CPU */}
          <Section title="Procesador" icon={<Cpu size={13} />} defaultOpen={false}>
            <Field label="Marca Procesador" name="procesador_marca" value={form.procesador_marca} onChange={handleChange}
              options={MARCAS_PROCESADOR} />
            <Field label="Tipo / Modelo" name="procesador_tipo" value={form.procesador_tipo} onChange={handleChange}
              options={MODELOS_PROCESADOR} />
            <Field label="Velocidad Base (GHz)" name="procesador_velocidad" value={form.procesador_velocidad} onChange={handleChange} placeholder="2.4 GHz" />
            <Field label="Núcleos / Hilos" name="procesador_nucleos" value={form.procesador_nucleos} onChange={handleChange} placeholder="8C / 16T" />
            <Field label="Generación / Serie" name="procesador_generacion" value={form.procesador_generacion} onChange={handleChange} placeholder="13a Gen / Zen 4" />
          </Section>

          {/* RAM & Storage */}
          <Section title="Memoria RAM y Almacenamiento" icon={<HardDrive size={13} />} defaultOpen={false}>
            <Field label="Capacidad RAM Total" name="ram_capacidad" value={form.ram_capacidad} onChange={handleChange} placeholder="16 GB" />
            <Field label="Tipo RAM" name="ram_tipo" value={form.ram_tipo} onChange={handleChange}
              options={['DDR3', 'DDR4', 'DDR5', 'LPDDR4', 'LPDDR4X', 'LPDDR5', 'LPDDR5X', 'Unified Memory', 'ECC DDR4', 'ECC DDR5']} />
            <Field label="Capacidad por Módulo" name="ram_slot" value={form.ram_slot} onChange={handleChange} placeholder="8 GB x2" />
            <Field label="Slots Totales" name="ram_slots_totales" value={form.ram_slots_totales} onChange={handleChange} placeholder="4" />
            <Field label="Slots Libres" name="ram_slots_libres" value={form.ram_slots_libres} onChange={handleChange} placeholder="2" />
            <Field label="Capacidad Disco 1" name="disco_capacidad" value={form.disco_capacidad} onChange={handleChange} placeholder="512 GB" />
            <Field label="Tecnología Disco 1" name="disco_tecnologia" value={form.disco_tecnologia} onChange={handleChange}
              options={['SSD', 'HDD', 'NVMe SSD', 'SATA SSD', 'M.2 NVMe PCIe 4.0', 'M.2 NVMe PCIe 5.0', 'M.2 SATA', 'eMMC', 'UFS', 'HDD + SSD', 'NVMe RAID']} />
            <Field label="Interfaz Disco" name="disco_interfaz" value={form.disco_interfaz} onChange={handleChange} placeholder="PCIe 4.0 x4 / SATA III" />
            <Field label="RPM (HDD)" name="disco_rpm" value={form.disco_rpm} onChange={handleChange} options={['', '5400 RPM', '7200 RPM', '10000 RPM', '15000 RPM', 'N/A']} />
            <Field label="Disco 2 Capacidad" name="disco2_capacidad" value={form.disco2_capacidad} onChange={handleChange} placeholder="1 TB" />
            <Field label="Disco 2 Tecnología" name="disco2_tecnologia" value={form.disco2_tecnologia} onChange={handleChange}
              options={['', 'SSD', 'HDD', 'NVMe SSD', 'SATA SSD', 'M.2 NVMe', 'M.2 SATA']} />
            <Field label="Unidad Óptica" name="unidad_optica" value={form.unidad_optica} onChange={handleChange}
              options={['NO', 'DVD-RW', 'DVD-ROM', 'Blu-Ray RW', 'Blu-Ray ROM']} />
          </Section>

          {/* GPU */}
          <Section title="Tarjeta Gráfica (GPU)" icon={<Zap size={13} />} defaultOpen={false}>
            <Field label="Tipo GPU" name="gpu_tipo" value={form.gpu_tipo} onChange={handleChange}
              options={['', 'Dedicada', 'Integrada', 'Híbrida (iGPU + dGPU)']} />
            <Field label="Marca GPU" name="gpu_marca" value={form.gpu_marca} onChange={handleChange}
              options={['', 'NVIDIA', 'AMD', 'Intel', 'Apple', 'Integrada Intel', 'Integrada AMD']} />
            <Field label="Modelo GPU" name="gpu_modelo" value={form.gpu_modelo} onChange={handleChange} placeholder="RTX 4070 / RX 7600 / Arc A770" />
            <Field label="VRAM" name="gpu_vram" value={form.gpu_vram} onChange={handleChange}
              options={['', 'Compartida', '2 GB', '4 GB', '6 GB', '8 GB', '10 GB', '12 GB', '16 GB', '20 GB', '24 GB', '48 GB']} />
          </Section>

          {/* Battery — only when the selected device is portable */}
          {isPortable && <Section title="Batería (Laptops / Tablets)" icon={<Battery size={13} />} defaultOpen={false}>
            <Field label="Estado Batería" name="bateria_estado" value={form.bateria_estado} onChange={handleChange}
              options={['', 'Excelente', 'Bueno', 'Regular', 'Malo', 'Reemplazada', 'N/A']} />
            <Field label="Capacidad (Wh / mAh)" name="bateria_capacidad" value={form.bateria_capacidad} onChange={handleChange} placeholder="72 Wh / 6000 mAh" />
            <Field label="Ciclos de Carga" name="bateria_ciclos" value={form.bateria_ciclos} onChange={handleChange} placeholder="245" />
            <Field label="Modelo / P/N Batería" name="bateria_modelo" value={form.bateria_modelo} onChange={handleChange} placeholder="L19M4PH0" />
          </Section>}

          {/* Firmware & Security */}
          <Section title="Firmware y Seguridad" icon={<Settings size={13} />} defaultOpen={false}>
            <Field label="Versión BIOS / UEFI" name="bios_version" value={form.bios_version} onChange={handleChange} placeholder="F.25 / 1.12.0" />
            <Field label="Versión Firmware" name="firmware_version" value={form.firmware_version} onChange={handleChange} placeholder="EC 1.04" />
            <Field label="Versión TPM" name="tpm_version" value={form.tpm_version} onChange={handleChange}
              options={['', 'TPM 1.2', 'TPM 2.0', 'fTPM 2.0', 'No tiene']} />
            <Field label="Secure Boot" name="secure_boot" value={form.secure_boot} onChange={handleChange}
              options={['', 'Habilitado', 'Deshabilitado', 'N/A']} />
          </Section>

          {/* Connectivity & Ports */}
          <Section title="Conectividad y Puertos" icon={<Wifi size={13} />} defaultOpen={false}>
            <Field label="Puertos USB-A" name="puertos_usb" value={form.puertos_usb} onChange={handleChange} placeholder="3x USB 3.2 Gen1" />
            <Field label="Puertos USB-C / USB4" name="puertos_usb_c" value={form.puertos_usb_c} onChange={handleChange} placeholder="2x USB-C 3.2 Gen2" />
            <Field label="Puertos HDMI / DisplayPort" name="puertos_hdmi" value={form.puertos_hdmi} onChange={handleChange} placeholder="1x HDMI 2.1, 1x DP 1.4" />
            <Field label="Thunderbolt" name="puertos_thunderbolt" value={form.puertos_thunderbolt} onChange={handleChange}
              options={['', 'Thunderbolt 3', 'Thunderbolt 4', 'Thunderbolt 5', 'No tiene']} />
            <Field label="Estándar Wi-Fi" name="wifi_estandar" value={form.wifi_estandar} onChange={handleChange}
              options={['', 'Wi-Fi 5 (802.11ac)', 'Wi-Fi 6 (802.11ax)', 'Wi-Fi 6E', 'Wi-Fi 7 (802.11be)', 'No tiene']} />
            <Field label="Bluetooth" name="bluetooth" value={form.bluetooth} onChange={handleChange}
              options={['', 'Bluetooth 4.2', 'Bluetooth 5.0', 'Bluetooth 5.1', 'Bluetooth 5.2', 'Bluetooth 5.3', 'No tiene']} />
            <Field label="Lector de Tarjetas" name="lector_tarjetas" value={form.lector_tarjetas} onChange={handleChange}
              options={['NO', 'SD', 'microSD', 'SD + microSD', 'Multi-card']} />
          </Section>

          {/* Peripherals */}
          <Section title="Periféricos" icon={<Keyboard size={13} />} defaultOpen={false}>
            <Field label="Marca Teclado" name="teclado_marca" value={form.teclado_marca} onChange={handleChange} />
            <Field label="Marca Mouse" name="mouse_marca" value={form.mouse_marca} onChange={handleChange} />
            <Field label="Web Cam" name="web_cam" value={form.web_cam} onChange={handleChange} options={['NO', 'SI', 'Integrada', 'Externa']} />
            <Field label="Marca Monitor" name="monitor_marca" value={form.monitor_marca} onChange={handleChange}
              options={MARCAS_MONITOR} />
            <Field label="Modelo Monitor" name="monitor_modelo" value={form.monitor_modelo} onChange={handleChange} />
            <Field label="Tipo Monitor" name="monitor_tipo" value={form.monitor_tipo} onChange={handleChange}
              options={TIPOS_MONITOR} />
            <Field label="Tamaño Monitor (pulgadas)" name="monitor_tamano" value={form.monitor_tamano} onChange={handleChange} />
            <Field label="Serial Monitor" name="monitor_serial" value={form.monitor_serial} onChange={handleChange} />
          </Section>

          {/* Printer — avoid duplicating printer fields for ordinary computers */}
          {isPrinter && <Section title="Impresora" icon={<Printer size={13} />} defaultOpen={false}>
            <Field label="Marca Impresora" name="impresora_marca" value={form.impresora_marca} onChange={handleChange}
              options={MARCAS_IMPRESORA} />
            <Field label="Modelo Impresora" name="impresora_modelo" value={form.impresora_modelo} onChange={handleChange} />
            <Field label="Tipo Impresora" name="impresora_tipo" value={form.impresora_tipo} onChange={handleChange}
              options={TIPOS_IMPRESORA} />
            <Field label="Serial Impresora" name="impresora_serial" value={form.impresora_serial} onChange={handleChange} />
            <Field label="MAC Impresora" name="impresora_mac" value={form.impresora_mac} onChange={handleChange} />
          </Section>}

          {/* Network */}
          <Section title="Configuración de Red" icon={<Network size={13} />} defaultOpen={false}>
            <Field label="Nombre del Equipo (Hostname)" name="nombre_equipo" value={form.nombre_equipo} onChange={handleChange} />
            <Field label="En Red" name="en_red" value={form.en_red} onChange={handleChange} options={['SI', 'NO']} />
            <div>
              <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Dirección IP</label>
              <input
                type="text"
                name="direccion_ip"
                value={String(form.direccion_ip || '')}
                onChange={e => handleChange('direccion_ip', e.target.value)}
                onBlur={handleIpBlur}
                className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full"
                placeholder="192.168.1.100"
              />
              {ipWarning && (
                <div className="flex items-center gap-1.5 mt-1.5 text-amber-400 text-[10px]">
                  <AlertTriangle size={11} className="shrink-0" />
                  <span>{ipWarning}</span>
                </div>
              )}
            </div>
            <Field label="Dirección MAC" name="mac_address" value={form.mac_address} onChange={handleChange} placeholder="AA:BB:CC:DD:EE:FF" />
            <Field label="Máscara de Subred" name="subred" value={form.subred} onChange={handleChange} />
            <Field label="Puerta de Enlace" name="gateway" value={form.gateway} onChange={handleChange} />
            <Field label="DNS Primario" name="dns_primario" value={form.dns_primario} onChange={handleChange} />
            <Field label="DNS Secundario" name="dns_secundario" value={form.dns_secundario} onChange={handleChange} />
            <Field label="Puerto Switch" name="puerto_switch" value={form.puerto_switch} onChange={handleChange} placeholder="Gi0/1" />
          </Section>

          {/* Assignment */}
          <Section title="Ubicación y Asignación" icon={<MapPin size={13} />}>
            <Field label="Usuario Responsable *" name="usuario_responsable" value={form.usuario_responsable} onChange={handleChange} />
            <Field label="Área / Unidad" name="area" value={form.area} onChange={handleChange} />
            <Field label="Ubicación Física" name="ubicacion" value={form.ubicacion} onChange={handleChange} />
            <Field label="Fecha de Asignación" name="fecha_asignacion" value={form.fecha_asignacion} onChange={handleChange} type="date" />
            <Field label="Técnico Instalador" name="tecnico_instalador" value={form.tecnico_instalador} onChange={handleChange} />
          </Section>

          {/* Notes */}
          <Section title="Observaciones y Recomendaciones" icon={<User size={13} />} defaultOpen={false}>
            <div className="col-span-2">
              <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Observaciones</label>
              <textarea name="observaciones" value={form.observaciones || ''} onChange={e => handleChange('observaciones', e.target.value)}
                rows={3} className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none"
                placeholder="Observaciones adicionales..." />
            </div>
            <div className="col-span-2">
              <label className="block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide">Recomendaciones</label>
              <textarea name="recomendaciones" value={form.recomendaciones || ''} onChange={e => handleChange('recomendaciones', e.target.value)}
                rows={2} className="bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary w-full resize-none"
                placeholder="Recomendaciones técnicas..." />
            </div>
          </Section>

        </form>

        <div className="px-6 py-4 border-t border-border flex items-center justify-end gap-3 shrink-0">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-xs text-muted-foreground hover:text-foreground bg-secondary border border-border rounded-lg transition-colors">
            Cancelar
          </button>
          <button type="submit" form="asset-form" disabled={loading || uploading}
            className="px-5 py-2 text-xs font-semibold bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50">
            {loading || uploading ? 'Guardando...' : 'Guardar Equipo'}
          </button>
        </div>
      </div>
    </div>
  );
}
