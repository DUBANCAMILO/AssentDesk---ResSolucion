'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { Search, Plus, QrCode, ChevronUp, ChevronDown, ChevronsUpDown, Eye, Monitor, Cpu, HardDrive, MapPin, CheckCircle, AlertTriangle, Wrench, FileSpreadsheet, Archive, RefreshCw, Tag, X } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import AssetRegistrationModal, { type AssetFormData } from './AssetRegistrationModal';
import ExcelImportModal from './ExcelImportModal';
import QRTechSheet from './QRTechSheet';
import BajaModal, { type BajaFormData } from './BajaModal';
import { assetService, type Asset } from '@/lib/services/assetService';
import { createClient } from '@/lib/supabase/client';

const STATUS_FILTERS = ['Todos', 'Operativo', 'Crítico', 'Mantenimiento'];
const STATUS_MAP: Record<string, string> = {
  'Todos': 'All', 'Operativo': 'operational', 'Crítico': 'critical', 'Mantenimiento': 'maintenance',
};

// Visual status label (etiqueta_estado) config
const ETIQUETA_OPTIONS = [
  { value: '', label: '— Sin etiqueta —' },
  { value: 'requiere_mantenimiento', label: 'Requiere Mantenimiento', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
  { value: 'cambios_realizados', label: 'Cambios Realizados', color: 'text-green-400 bg-green-500/10 border-green-500/30' },
  { value: 'pendiente_baja', label: 'Pendiente de Baja', color: 'text-red-400 bg-red-500/10 border-red-500/30' },
  { value: 'en_revision', label: 'En Revisión', color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
  { value: 'garantia_vencida', label: 'Garantía Vencida', color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
  { value: 'actualizado', label: 'Actualizado', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' },
  { value: 'optimo', label: 'Óptimo / Buen estado', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
];

type SortKey = 'placa' | 'marca' | 'modelo' | 'direccion_ip' | 'ubicacion' | 'status';
type SortDir = 'asc' | 'desc';

function QrCodeDisplay({ tag }: { tag: string }) {
  const cells = useMemo(() => {
    const size = 7;
    const grid: boolean[][] = [];
    let seed = (tag || 'QR').split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const rand = () => { seed = (seed * 1664525 + 1013904223) & 0xffffffff; return (seed >>> 0) / 0xffffffff; };
    for (let r = 0; r < size; r++) {
      grid[r] = [];
      for (let c = 0; c < size; c++) {
        if ((r < 3 && c < 3) || (r < 3 && c >= size - 3) || (r >= size - 3 && c < 3)) {
          grid[r][c] = true;
        } else {
          grid[r][c] = rand() > 0.45;
        }
      }
    }
    return grid;
  }, [tag]);
  return (
    <div className="p-1 bg-white rounded inline-block">
      <div className="grid gap-[1px]" style={{ gridTemplateColumns: `repeat(7, 4px)` }}>
        {cells.map((row, r) => row.map((filled, c) => (
          <div key={`${r}-${c}`} className={`w-[4px] h-[4px] ${filled ? 'bg-gray-900' : 'bg-white'}`} />
        )))}
      </div>
    </div>
  );
}

function EtiquetaBadge({ etiqueta }: { etiqueta?: string }) {
  if (!etiqueta) return null;
  const opt = ETIQUETA_OPTIONS.find(o => o.value === etiqueta);
  if (!opt || !opt.value) return null;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border ${opt.color}`}>
      <Tag size={9} />
      {opt.label}
    </span>
  );
}

function escapePrint(value: unknown): string {
  const entities: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;' };
  const text = String(value ?? '').replace(/[&<>]/g, ch => entities[ch] || ch);
  return text.replace(/"/g, '&quot;');
}

function printBajaDocument(asset: Asset, form: BajaFormData, documentNo: string) {
  const win = window.open('', '_blank', 'width=820,height=1000');
  if (!win) return;
  const checked = (value: boolean) => value ? '☒' : '☐';
  win.document.write(`<!doctype html><html lang="es"><head><meta charset="utf-8"/><title>${escapePrint(documentNo)}</title><style>
    @page { size: A4; margin: 16mm; } * { box-sizing: border-box; } body { font-family: Arial, sans-serif; color:#111; font-size:11px; }
    header { display:flex; justify-content:space-between; border-bottom:2px solid #111; padding-bottom:8px; margin-bottom:14px; }
    h1 { font-size:16px; margin:0 0 3px; } h2 { font-size:12px; margin:15px 0 6px; border-bottom:1px solid #888; padding-bottom:4px; }
    .meta { font-size:10px; text-align:right; } .grid { display:grid; grid-template-columns:repeat(3, 1fr); border:1px solid #555; }
    .cell { padding:6px; border-right:1px solid #aaa; border-bottom:1px solid #aaa; min-height:30px; } .cell:nth-child(3n) { border-right:0; }
    .label { display:block; font-size:9px; color:#555; text-transform:uppercase; margin-bottom:3px; } .box { border:1px solid #555; min-height:70px; padding:8px; white-space:pre-wrap; }
    .factors { display:grid; grid-template-columns:1fr 1fr; gap:5px; } .sign { margin-top:45px; display:grid; grid-template-columns:1fr 1fr; gap:35px; }
    .line { border-top:1px solid #111; padding-top:5px; text-align:center; } footer { margin-top:18px; font-size:9px; color:#555; }
  </style></head><body>
    <header><div><h1>FORMATO SUGERENCIA DE BAJAS</h1><div>GESTIÓN DE RECURSOS FÍSICOS</div></div><div class="meta">Documento: ${escapePrint(documentNo)}<br/>Fecha: ${new Date().toLocaleDateString('es-CO')}<br/>AssetDesk</div></header>
    <div class="grid"><div class="cell"><span class="label">Nombre del equipo</span>${escapePrint(`${asset.marca || ''} ${asset.modelo || ''}`)}</div><div class="cell"><span class="label">Cantidad</span>1</div><div class="cell"><span class="label">N° Inventario</span>${escapePrint(asset.placa)}</div><div class="cell"><span class="label">Serial</span>${escapePrint(asset.serial || 'N/A')}</div><div class="cell"><span class="label">Ubicación</span>${escapePrint(asset.ubicacion || asset.area || 'N/A')}</div><div class="cell"><span class="label">Motivo</span>${escapePrint(form.motivo)}</div></div>
    <h2>Valoración técnica</h2><div class="box">${escapePrint(form.valoracion_tecnica || form.observaciones || 'Sin valoración registrada')}</div>
    <h2>Frecuencia de trabajo</h2><div>${escapePrint(form.frecuencia_trabajo || 'No especificada')}</div>
    <h2>Factores que determinan la baja</h2><div class="factors"><div>${checked(form.factores.mantenimiento_correctivo)} Mantenimiento correctivo constante</div><div>${checked(form.factores.repuestos_no_comerciales)} Repuestos no comerciales</div><div>${checked(form.factores.costo_reparacion_70)} Reparación superior al 70%</div><div>${checked(form.factores.ciclo_vida)} Ciclo de vida cumplido</div><div>${checked(form.factores.hurto)} Hurto</div><div>${checked(form.factores.riesgo_usuario)} Riesgo para el usuario</div></div>
    <h2>Observaciones</h2><div class="box">${escapePrint(form.observaciones || 'Sin observaciones')}</div>
    <div class="sign"><div class="line">${escapePrint(form.tecnico || 'Responsable del análisis técnico')}</div><div class="line">Firma / aprobación</div></div><footer>Formato generado automáticamente desde AssetDesk. Verifique y firme según el procedimiento institucional.</footer>
    <script>setTimeout(()=>{window.print();},350);</script></body></html>`);
  win.document.close();
}

export default function AssetTableSection() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [sortKey, setSortKey] = useState<SortKey>('placa');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [page, setPage] = useState(1);
  const perPage = 10;

  const [showRegModal, setShowRegModal] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [qrAsset, setQrAsset] = useState<Asset | null>(null);
  const [bajaAsset, setBajaAsset] = useState<Asset | null>(null);
  const [editAsset, setEditAsset] = useState<Asset | null>(null);
  const [etiquetaAsset, setEtiquetaAsset] = useState<Asset | null>(null);
  const [etiquetaValue, setEtiquetaValue] = useState('');
  const [savingEtiqueta, setSavingEtiqueta] = useState(false);

  const loadAssets = async () => {
    setLoading(true);
    let data = await assetService.getAll();
    // Exclude printers from the computer equipment list
    data = data.filter(a => {
      const tipo = (a.tipo_equipo || '').toLowerCase();
      return !tipo.includes('impresora') && !tipo.includes('printer');
    });
    setAssets(data);
    setLoading(false);
  };

  useEffect(() => {
    loadAssets();

    // Real-time subscription: reflect inserts, updates, deletes immediately
    const supabase = createClient();
    const channel = supabase
      .channel('assets-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'assets' },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newAsset = payload.new as Asset;
            // Only show non-decommissioned assets
            if (newAsset.status !== 'decommissioned') {
              setAssets(prev => {
                // Avoid duplicates
                if (prev.some(a => a.id === newAsset.id)) return prev;
                return [newAsset, ...prev];
              });
            }
          } else if (payload.eventType === 'UPDATE') {
            const updated = payload.new as Asset;
            setAssets(prev => {
              if (updated.status === 'decommissioned') {
                return prev.filter(a => a.id !== updated.id);
              }
              return prev.map(a => a.id === updated.id ? updated : a);
            });
          } else if (payload.eventType === 'DELETE') {
            const deleted = payload.old as Asset;
            setAssets(prev => prev.filter(a => a.id !== deleted.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const filtered = useMemo(() => {
    let data = [...assets];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(a =>
        (a.placa || '').toLowerCase().includes(q) ||
        (a.marca || '').toLowerCase().includes(q) ||
        (a.modelo || '').toLowerCase().includes(q) ||
        (a.serial || '').toLowerCase().includes(q) ||
        (a.usuario_responsable || '').toLowerCase().includes(q) ||
        (a.area || '').toLowerCase().includes(q) ||
        (a.direccion_ip || '').includes(q)
      );
    }
    if (statusFilter !== 'Todos') {
      data = data.filter(a => a.status === STATUS_MAP[statusFilter]);
    }
    data.sort((a, b) => {
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [assets, search, statusFilter, sortKey, sortDir]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  const handleSave = async (data: AssetFormData) => {
    setSaving(true);
    const result = editAsset?.id
      ? await assetService.update(editAsset.id, data)
      : await assetService.create(data);
    setSaving(false);
    if (!result) {
      alert('No se pudo guardar el equipo. Revisa los datos y la conexión con Supabase.');
      return;
    }
    setShowRegModal(false);
    setEditAsset(null);
    loadAssets();
  };

  const handleImport = async (rows: Partial<AssetFormData>[]) => {
    setSaving(true);
    for (const row of rows) {
      await assetService.create(row as AssetFormData);
    }
    setSaving(false);
    setShowImport(false);
    loadAssets();
  };

  const handleBaja = async (form: BajaFormData) => {
    if (!bajaAsset?.id) return;
    const assetForDocument = bajaAsset;
    const documentNo = await assetService.moveToBaja(bajaAsset.id, form);
    if (!documentNo) {
      alert('No se pudo registrar la baja. Verifica la conexión y la migración de formularios.');
      return;
    }
    setBajaAsset(null);
    loadAssets();
    // Generate the institutional document automatically after a successful baja.
    printBajaDocument(assetForDocument, form, documentNo);
  };

  const handleSaveEtiqueta = async () => {
    if (!etiquetaAsset?.id) return;
    setSavingEtiqueta(true);
    await assetService.update(etiquetaAsset.id, { etiqueta_estado: etiquetaValue || null } as Partial<Asset>);
    setSavingEtiqueta(false);
    setEtiquetaAsset(null);
    loadAssets();
  };

  const metrics = useMemo(() => ({
    total: assets.length,
    operational: assets.filter(a => a.status === 'operational').length,
    critical: assets.filter(a => a.status === 'critical').length,
    maintenance: assets.filter(a => a.status === 'maintenance').length,
  }), [assets]);

  return (
    <>
      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Activos', value: metrics.total, color: 'text-foreground', bg: 'bg-secondary', icon: Monitor },
          { label: 'Operativos', value: metrics.operational, color: 'text-green-400', bg: 'bg-green-500/10', icon: CheckCircle },
          { label: 'Críticos', value: metrics.critical, color: 'text-red-400', bg: 'bg-red-500/10', icon: AlertTriangle },
          { label: 'Mantenimiento', value: metrics.maintenance, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: Wrench },
        ].map(m => {
          const MIcon = m.icon;
          return (
            <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${m.bg}`}><MIcon size={16} className={m.color} /></div>
              <div>
                <p className={`text-2xl font-bold font-mono-data ${m.color}`}>{m.value}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{m.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-border">
          <div className="relative flex-1 min-w-48">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Buscar por placa, marca, IP, usuario..."
              className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
          </div>
          <div className="flex gap-1.5">
            {STATUS_FILTERS.map(f => (
              <button key={f} onClick={() => { setStatusFilter(f); setPage(1); }}
                className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${statusFilter === f ? 'bg-primary/15 border-primary/30 text-primary' : 'bg-secondary border-border text-muted-foreground hover:text-foreground'}`}>
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button onClick={loadAssets} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors" title="Recargar">
              <RefreshCw size={14} />
            </button>
            <button onClick={() => setShowImport(true)}
              className="flex items-center gap-2 px-3 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
              <FileSpreadsheet size={13} /> Importar
            </button>
            <button onClick={() => { setEditAsset(null); setShowRegModal(true); }}
              className="flex items-center gap-2 px-3 py-2 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
              <Plus size={13} /> Nuevo Equipo
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                {[
                  { key: 'placa', label: 'Placa / Tag' },
                  { key: 'marca', label: 'Marca / Modelo' },
                  { key: null, label: 'CPU / RAM' },
                  { key: null, label: 'Almacenamiento' },
                  { key: 'direccion_ip', label: 'IP' },
                  { key: 'ubicacion', label: 'Ubicación' },
                  { key: 'status', label: 'Estado' },
                  { key: null, label: 'Etiqueta' },
                  { key: null, label: 'QR' },
                  { key: null, label: 'Acciones' },
                ].map((col, i) => (
                  <th key={i} className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                    onClick={() => col.key && handleSort(col.key as SortKey)}>
                    <div className="flex items-center gap-1">
                      {col.label}
                      {col.key && <SortIcon col={col.key as SortKey} />}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={10} className="px-4 py-12 text-center text-muted-foreground">
                  <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando activos...
                </td></tr>
              ) : paginated.length === 0 ? (
                <tr><td colSpan={10} className="px-4 py-12 text-center text-muted-foreground">
                  No se encontraron activos
                </td></tr>
              ) : paginated.map((asset, idx) => (
                <tr key={asset.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors ${idx % 2 === 0 ? '' : 'bg-secondary/10'}`}>
                  <td className="px-4 py-3">
                    <div className="font-mono-data text-primary text-xs font-semibold">{asset.placa}</div>
                    <div className="text-[10px] text-muted-foreground">{asset.tag}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-foreground">{asset.marca}</div>
                    <div className="text-[10px] text-muted-foreground">{asset.modelo}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Cpu size={10} />
                      <span className="truncate max-w-[120px]">{asset.procesador_tipo || '—'}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground mt-0.5">
                      <HardDrive size={10} />
                      <span>{asset.ram_capacidad || '—'}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    <div>{asset.disco_capacidad || '—'}</div>
                    <div className="text-[10px]">{asset.disco_tecnologia}</div>
                  </td>
                  <td className="px-4 py-3 font-mono-data text-muted-foreground">{asset.direccion_ip || '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MapPin size={10} />
                      <span className="truncate max-w-[120px]">{asset.ubicacion || asset.area || '—'}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{asset.usuario_responsable}</div>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={(asset.status as 'operational' | 'critical' | 'maintenance' | 'decommissioned') || 'operational'} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <EtiquetaBadge etiqueta={(asset as Asset & { etiqueta_estado?: string }).etiqueta_estado} />
                      <button
                        onClick={() => { setEtiquetaAsset(asset); setEtiquetaValue((asset as Asset & { etiqueta_estado?: string }).etiqueta_estado || ''); }}
                        className="text-[10px] text-muted-foreground hover:text-primary flex items-center gap-1 transition-colors"
                        title="Cambiar etiqueta">
                        <Tag size={9} />{(asset as Asset & { etiqueta_estado?: string }).etiqueta_estado ? 'Cambiar' : 'Etiquetar'}
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {asset.has_qr && <QrCodeDisplay tag={asset.placa || asset.id || ''} />}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setQrAsset(asset)} title="Ver Ficha QR"
                        className="p-1.5 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                        <QrCode size={14} />
                      </button>
                      <button onClick={() => { setEditAsset(asset); setShowRegModal(true); }} title="Editar"
                        className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                        <Eye size={14} />
                      </button>
                      <button onClick={() => setBajaAsset(asset)} title="Dar de Baja"
                        className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                        <Archive size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-xs text-muted-foreground">{filtered.length} activos · Página {page} de {totalPages}</span>
            <div className="flex gap-1">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">
                Anterior
              </button>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">
                Siguiente
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Etiqueta Modal */}
      {etiquetaAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Tag size={15} className="text-primary" />
                <h3 className="font-semibold text-foreground text-sm">Etiqueta de Estado</h3>
              </div>
              <button onClick={() => setEtiquetaAsset(null)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors">
                <X size={14} />
              </button>
            </div>
            <div className="p-5 space-y-3">
              <p className="text-xs text-muted-foreground">Activo: <span className="text-foreground font-medium">{etiquetaAsset.placa} — {etiquetaAsset.marca} {etiquetaAsset.modelo}</span></p>
              <div className="space-y-2">
                {ETIQUETA_OPTIONS.map(opt => (
                  <button key={opt.value} onClick={() => setEtiquetaValue(opt.value)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-xs transition-all ${etiquetaValue === opt.value ? 'border-primary/50 bg-primary/10' : 'border-border bg-secondary hover:border-border/80'}`}>
                    {opt.value ? (
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border ${opt.color}`}>
                        <Tag size={9} />{opt.label}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">{opt.label}</span>
                    )}
                    {etiquetaValue === opt.value && <CheckCircle size={13} className="text-primary ml-auto" />}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-border">
              <button onClick={() => setEtiquetaAsset(null)} className="px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
                Cancelar
              </button>
              <button onClick={handleSaveEtiqueta} disabled={savingEtiqueta}
                className="px-4 py-2 text-xs bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50">
                {savingEtiqueta ? 'Guardando...' : 'Aplicar Etiqueta'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {showRegModal && (
        <AssetRegistrationModal
          onClose={() => { setShowRegModal(false); setEditAsset(null); }}
          onSave={handleSave}
          initialData={editAsset ? {
            placa: editAsset.placa, serial: editAsset.serial, sede: editAsset.sede,
            n_ficha: editAsset.n_ficha, tag: editAsset.tag,
            marca: editAsset.marca, modelo: editAsset.modelo, n_producto: editAsset.n_producto,
            tipo_equipo: editAsset.tipo_equipo,
            sistema_operativo: editAsset.sistema_operativo, service_pack: editAsset.service_pack,
            idioma: editAsset.idioma, arquitectura: editAsset.arquitectura, licencia_os: editAsset.licencia_os,
            procesador_marca: editAsset.procesador_marca, procesador_tipo: editAsset.procesador_tipo,
            procesador_velocidad: editAsset.procesador_velocidad, procesador_nucleos: editAsset.procesador_nucleos,
            procesador_generacion: editAsset.procesador_generacion,
            ram_capacidad: editAsset.ram_capacidad, ram_tipo: editAsset.ram_tipo,
            ram_slot: editAsset.ram_slot, ram_slots_totales: editAsset.ram_slots_totales,
            ram_slots_libres: editAsset.ram_slots_libres,
            disco_capacidad: editAsset.disco_capacidad, disco_tecnologia: editAsset.disco_tecnologia,
            disco_interfaz: editAsset.disco_interfaz, disco_rpm: editAsset.disco_rpm,
            disco2_capacidad: editAsset.disco2_capacidad, disco2_tecnologia: editAsset.disco2_tecnologia,
            unidad_optica: editAsset.unidad_optica, unidad_marca: editAsset.unidad_marca,
            gpu_marca: editAsset.gpu_marca, gpu_modelo: editAsset.gpu_modelo,
            gpu_vram: editAsset.gpu_vram, gpu_tipo: editAsset.gpu_tipo,
            display_tamano: editAsset.display_tamano, display_resolucion: editAsset.display_resolucion,
            display_tipo: editAsset.display_tipo, display_frecuencia: editAsset.display_frecuencia,
            display_tactil: editAsset.display_tactil,
            bateria_estado: editAsset.bateria_estado, bateria_ciclos: editAsset.bateria_ciclos,
            bateria_capacidad: editAsset.bateria_capacidad, bateria_modelo: editAsset.bateria_modelo,
            firmware_version: editAsset.firmware_version, bios_version: editAsset.bios_version,
            tpm_version: editAsset.tpm_version, secure_boot: editAsset.secure_boot,
            puertos_usb: editAsset.puertos_usb, puertos_usb_c: editAsset.puertos_usb_c,
            puertos_hdmi: editAsset.puertos_hdmi, puertos_thunderbolt: editAsset.puertos_thunderbolt,
            lector_tarjetas: editAsset.lector_tarjetas, bluetooth: editAsset.bluetooth,
            wifi_estandar: editAsset.wifi_estandar,
            teclado_marca: editAsset.teclado_marca, mouse_marca: editAsset.mouse_marca,
            web_cam: editAsset.web_cam,
            monitor_marca: editAsset.monitor_marca, monitor_modelo: editAsset.monitor_modelo,
            monitor_tipo: editAsset.monitor_tipo, monitor_tamano: editAsset.monitor_tamano,
            monitor_serial: editAsset.monitor_serial,
            impresora_marca: editAsset.impresora_marca, impresora_tipo: editAsset.impresora_tipo,
            impresora_serial: editAsset.impresora_serial, impresora_modelo: editAsset.impresora_modelo,
            impresora_mac: editAsset.impresora_mac,
            nombre_equipo: editAsset.nombre_equipo, en_red: editAsset.en_red,
            direccion_ip: editAsset.direccion_ip, mac_address: editAsset.mac_address,
            subred: editAsset.subred, gateway: editAsset.gateway,
            dns_primario: editAsset.dns_primario, dns_secundario: editAsset.dns_secundario,
            puerto_switch: editAsset.puerto_switch,
            usuario_responsable: editAsset.usuario_responsable, area: editAsset.area,
            ubicacion: editAsset.ubicacion, fecha_asignacion: editAsset.fecha_asignacion,
            tecnico_instalador: editAsset.tecnico_instalador,
            garantia_vencimiento: editAsset.garantia_vencimiento, garantia_tipo: editAsset.garantia_tipo,
            proveedor: editAsset.proveedor, orden_compra: editAsset.orden_compra,
            office_version: editAsset.office_version, antivirus: editAsset.antivirus,
            software_adicional: editAsset.software_adicional,
            foto_url: editAsset.foto_url,
            status: editAsset.status,
            observaciones: editAsset.observaciones, recomendaciones: editAsset.recomendaciones,
            has_qr: editAsset.has_qr,
          } : undefined}
          loading={saving}
        />
      )}
      {showImport && <ExcelImportModal onClose={() => setShowImport(false)} onImport={handleImport} />}
      {qrAsset && <QRTechSheet asset={qrAsset} onClose={() => setQrAsset(null)} />}
      {bajaAsset && <BajaModal asset={bajaAsset} onClose={() => setBajaAsset(null)} onConfirm={handleBaja} />}
    </>
  );
}