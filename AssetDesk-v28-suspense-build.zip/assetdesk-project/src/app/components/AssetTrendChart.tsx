'use client';

import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { day: 'Jul 2', tickets: 3 },
  { day: 'Jul 3', tickets: 5 },
  { day: 'Jul 4', tickets: 2 },
  { day: 'Jul 5', tickets: 7 },
  { day: 'Jul 6', tickets: 4 },
  { day: 'Jul 7', tickets: 6 },
  { day: 'Jul 8', tickets: 9 },
  { day: 'Jul 9', tickets: 5 },
  { day: 'Jul 10', tickets: 11 },
  { day: 'Jul 11', tickets: 7 },
  { day: 'Jul 12', tickets: 4 },
  { day: 'Jul 13', tickets: 8 },
  { day: 'Jul 14', tickets: 6 },
  { day: 'Jul 15', tickets: 7 },
];

type TooltipEntry = { value?: number | string };

type CustomTooltipProps = {
  active?: boolean;
  payload?: TooltipEntry[];
  label?: string;
};

const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-xl">
        <p className="text-xs text-muted-foreground mb-1">{label}</p>
        <p className="text-sm font-semibold text-foreground">
          {payload[0].value} tickets
        </p>
      </div>
    );
  }
  return null;
};

export default function AssetTrendChart() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
        <defs>
          <linearGradient id="ticketGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
            <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid
          stroke="var(--border)"
          strokeDasharray="3 3"
          vertical={false}
        />
        <XAxis
          dataKey="day"
          tick={{ fontSize: 9, fill: 'var(--muted-foreground)' }}
          axisLine={false}
          tickLine={false}
          interval={3}
        />
        <YAxis
          tick={{ fontSize: 9, fill: 'var(--muted-foreground)' }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip content={<CustomTooltip />} />
        <Area
          type="monotone"
          dataKey="tickets"
          stroke="var(--primary)"
          strokeWidth={2}
          fill="url(#ticketGradient)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}