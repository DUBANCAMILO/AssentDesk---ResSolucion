import React from 'react';
import { Monitor, AlertTriangle, Wrench, Archive, Wifi, QrCode } from 'lucide-react';
import AssetTrendChart from './AssetTrendChart';

const metrics = [
  {
    id: 'metric-total',
    label: 'Total Assets',
    value: '247',
    sub: '+4 registered this month',
    icon: Monitor,
    iconColor: 'text-primary',
    iconBg: 'bg-primary/10',
    alert: false,
    warn: false,
  },
  {
    id: 'metric-critical',
    label: 'Critical Status',
    value: '2',
    sub: 'Immediate attention required',
    icon: AlertTriangle,
    iconColor: 'text-red-400',
    iconBg: 'bg-red-500/10',
    alert: true,
    warn: false,
  },
  {
    id: 'metric-maintenance',
    label: 'Under Maintenance',
    value: '11',
    sub: '3 overdue for return',
    icon: Wrench,
    iconColor: 'text-amber-400',
    iconBg: 'bg-amber-500/10',
    alert: false,
    warn: true,
  },
  {
    id: 'metric-decommissioned',
    label: 'Decommissioned',
    value: '18',
    sub: 'Pending disposal review',
    icon: Archive,
    iconColor: 'text-slate-400',
    iconBg: 'bg-slate-500/10',
    alert: false,
    warn: false,
  },
  {
    id: 'metric-ip',
    label: 'IPs Assigned',
    value: '193',
    sub: '54 addresses available',
    icon: Wifi,
    iconColor: 'text-cyan-400',
    iconBg: 'bg-cyan-500/10',
    alert: false,
    warn: false,
  },
  {
    id: 'metric-qr',
    label: 'QR Codes Active',
    value: '229',
    sub: '18 assets pending QR',
    icon: QrCode,
    iconColor: 'text-violet-400',
    iconBg: 'bg-violet-500/10',
    alert: false,
    warn: false,
  },
];

export default function AssetMetricsBento() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {metrics?.slice(0, 3)?.map((m) => {
        const Icon = m?.icon;
        return (
          <div
            key={m?.id}
            className={`bg-card border rounded-xl p-4 flex flex-col gap-3 ${
              m?.alert
                ? 'border-red-500/30 bg-red-500/5 glow-red'
                : m?.warn
                ? 'border-amber-500/30 bg-amber-500/5' :'border-border'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className={`p-2 rounded-lg ${m?.iconBg}`}>
                <Icon size={16} className={m?.iconColor} />
              </div>
              {m?.alert && (
                <span className="text-[10px] font-semibold text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded-full">
                  URGENT
                </span>
              )}
            </div>
            <div>
              <p className="text-2xl font-bold font-mono-data text-foreground">{m?.value}</p>
              <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide mt-0.5">{m?.label}</p>
            </div>
            <p className="text-xs text-muted-foreground">{m?.sub}</p>
          </div>
        );
      })}
      {/* Chart spans 1 col, 2 rows */}
      <div className="row-span-2 bg-card border border-border rounded-xl p-4 flex flex-col col-span-2 md:col-span-1">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
          Asset Status — 14d Trend
        </p>
        <div className="flex-1 min-h-0">
          <AssetTrendChart />
        </div>
      </div>
      {metrics?.slice(3, 6)?.map((m) => {
        const Icon = m?.icon;
        return (
          <div
            key={m?.id}
            className="bg-card border border-border rounded-xl p-4 flex flex-col gap-3"
          >
            <div className={`p-2 rounded-lg w-fit ${m?.iconBg}`}>
              <Icon size={16} className={m?.iconColor} />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono-data text-foreground">{m?.value}</p>
              <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide mt-0.5">{m?.label}</p>
            </div>
            <p className="text-xs text-muted-foreground">{m?.sub}</p>
          </div>
        );
      })}
    </div>
  );
}