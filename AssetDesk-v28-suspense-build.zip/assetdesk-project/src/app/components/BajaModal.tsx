'use client';

import React, { useState } from 'react';
import { X, Archive, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { type Asset } from '@/lib/services/assetService';

export interface BajaFormData {
  motivo: string;
  observaciones: string;
  tecnico: string;
  disposicion: string;
  valoracion_tecnica: string;
  frecuencia_trabajo: string;
  factores: {
    mantenimiento_correctivo: boolean;
    repuestos_no_comerciales: boolean;
    costo_reparacion_70: boolean;
    ciclo_vida: boolean;
    hurto: boolean;
    riesgo_usuario: boolean;
  };
}

interface Props {
  asset: Asset;
  onClose: () => void;
  onConfirm: (data: BajaFormData) => Promise<void>;
}

const MOTIVOS = [
  { value: 'obsolescencia', label: 'Obsolescencia' },
  { value: 'daño_irreparable', label: 'Daño Irreparable' },
  { value: 'robo_perdida', label: 'Robo / Pérdida' },
  { value: 'donacion', label: 'Donación' },
  { value: 'fin_vida_util', label: 'Fin de Vida Útil' },
];

const DISPOSICIONES = [
  { value: 'almacenado', label: 'Almacenado' },
  { value: 'donado', label: 'Donado' },
  { value: 'destruido', label: 'Destruido' },
  { value: 'en_proceso', label: 'En Proceso' },
];

const FACTORS = [
  ['mantenimiento_correctivo', 'Mantenimiento correctivo constante'],
  ['repuestos_no_comerciales', 'Repuestos no comerciales'],
  ['costo_reparacion_70', 'Reparación superior al 70% del valor comercial'],
  ['ciclo_vida', 'Ciclo de vida útil cumplido'],
  ['hurto', 'Hurto'],
  ['riesgo_usuario', 'Riesgo para el usuario'],
] as const;

export default function BajaModal({ asset, onClose, onConfirm }: Props) {
  const [motivo, setMotivo] = useState('obsolescencia');
  const [observaciones, setObservaciones] = useState('');
  const [valoracion, setValoracion] = useState('');
  const [tecnico, setTecnico] = useState('');
  const [frecuencia, setFrecuencia] = useState('');
  const [disposicion, setDisposicion] = useState('en_proceso');
  const [factores, setFactores] = useState<Record<string, boolean>>({});
  const [showInstitutional, setShowInstitutional] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await onConfirm({
      motivo,
      observaciones,
      tecnico,
      disposicion,
      valoracion_tecnica: valoracion,
      frecuencia_trabajo: frecuencia,
      factores: {
        mantenimiento_correctivo: !!factores.mantenimiento_correctivo,
        repuestos_no_comerciales: !!factores.repuestos_no_comerciales,
        costo_reparacion_70: !!factores.costo_reparacion_70,
        ciclo_vida: !!factores.ciclo_vida,
        hurto: !!factores.hurto,
        riesgo_usuario: !!factores.riesgo_usuario,
      },
    });
    setLoading(false);
  };

  const inputCls = 'w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary';
  const labelCls = 'block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card border border-border rounded-2xl mx-4 shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10"><Archive size={16} className="text-red-400" /></div>
            <div>
              <h2 className="text-sm font-semibold text-foreground">Sugerencia de Baja</h2>
              <p className="text-xs text-muted-foreground">{asset.marca} {asset.modelo} · {asset.placa}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"><X size={16} /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-3 flex items-start gap-2">
            <AlertTriangle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground">El sistema llenará automáticamente el formato de baja con los datos del equipo, fecha, placa, serial, ubicación y responsable.</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Motivo de Baja *</label>
              <select value={motivo} onChange={e => setMotivo(e.target.value)} required className={inputCls}>
                {MOTIVOS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Disposición Final</label>
              <select value={disposicion} onChange={e => setDisposicion(e.target.value)} className={inputCls}>
                {DISPOSICIONES.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className={labelCls}>Técnico Responsable</label>
            <input type="text" value={tecnico} onChange={e => setTecnico(e.target.value)} placeholder="Nombre del técnico" className={inputCls} />
          </div>

          <button type="button" onClick={() => setShowInstitutional(v => !v)} className="w-full flex items-center justify-between px-3 py-2 bg-secondary/60 border border-border rounded-lg text-xs font-semibold text-foreground">
            <span>Campos del formato institucional</span>{showInstitutional ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>

          {showInstitutional && (
            <div className="space-y-3 p-3 border border-border rounded-xl">
              <div>
                <label className={labelCls}>Valoración técnica</label>
                <textarea value={valoracion} onChange={e => setValoracion(e.target.value)} rows={3} className={`${inputCls} resize-none`} placeholder="Justificación técnica de la baja..." />
              </div>
              <div>
                <label className={labelCls}>Frecuencia de trabajo</label>
                <select value={frecuencia} onChange={e => setFrecuencia(e.target.value)} className={inputCls}>
                  <option value="">No especificada</option>
                  <option value="continuo">Continuo</option>
                  <option value="semanal">Semanal</option>
                  <option value="mensual">Mensual</option>
                  <option value="una_vez_al_dia">Una vez al día</option>
                  <option value="esporadicamente">Esporádicamente</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Factores que aplican</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {FACTORS.map(([key, label]) => (
                    <label key={key} className="flex items-start gap-2 text-[11px] text-muted-foreground">
                      <input type="checkbox" checked={!!factores[key]} onChange={e => setFactores(prev => ({ ...prev, [key]: e.target.checked }))} className="mt-0.5 accent-red-500" />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div>
            <label className={labelCls}>Observaciones</label>
            <textarea value={observaciones} onChange={e => setObservaciones(e.target.value)} rows={3} placeholder="Descripción del motivo de baja..." className={`${inputCls} resize-none`} />
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 text-xs text-muted-foreground bg-secondary border border-border rounded-lg hover:text-foreground transition-colors">Cancelar</button>
            <button type="submit" disabled={loading} className="flex-1 px-4 py-2 text-xs font-semibold bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50">{loading ? 'Procesando...' : 'Confirmar y generar formato'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
