'use client';

import React, { useState, useRef } from 'react';
import { X, Upload, FileSpreadsheet, CheckCircle, AlertTriangle, Download, ChevronRight } from 'lucide-react';
import type { AssetFormData } from './AssetRegistrationModal';

interface ImportRow {
  row: number;
  data: Partial<AssetFormData>;
  status: 'valid' | 'warning' | 'error';
  message?: string;
}

interface Props {
  onClose: () => void;
  onImport: (rows: Partial<AssetFormData>[]) => void;
}

function parseExcelRows(rawData: Record<string, string>[]): ImportRow[] {
  return rawData.map((row, i) => {
    const placa = row['Placa de Inventario'] || row['PLACA'] || row['placa'] || '';
    const serial = row['Serial Pc'] || row['Serial PC'] || row['SERIAL'] || row['serial'] || '';
    const marca = row['Marca'] || row['MARCA'] || row['marca'] || '';
    const modelo = row['Modelo'] || row['MODELO'] || row['modelo'] || '';

    const data: Partial<AssetFormData> = {
      placa: placa.trim(),
      serial: serial.trim(),
      sede: (row['Sede'] || row['SEDE'] || '').trim(),
      n_ficha: (row['N° Ficha'] || row['N Ficha'] || row['FICHA'] || '').trim(),
      marca: marca.trim(),
      modelo: modelo.trim(),
      n_producto: (row['Nº Producto'] || row['N Producto'] || '').trim(),
      tipo_equipo: (row['CPU'] || row['Tipo'] || 'Desktop').trim(),
      sistema_operativo: (row['Sistema Operativo'] || row['SO'] || '').trim(),
      service_pack: (row['Service Pack'] || '').trim(),
      idioma: (row['Idioma'] || 'ESP').trim(),
      arquitectura: (row['Arquitectura'] || 'x64').trim(),
      licencia_os: (row['Licencia original S.O.'] || row['Licencia'] || '').trim(),
      procesador_marca: (row['Procesador – Marca'] || row['Procesador Marca'] || '').trim(),
      procesador_tipo: (row['Procesador – Tipo'] || row['Procesador Tipo'] || '').trim(),
      procesador_velocidad: (row['Procesador – Velocidad'] || row['Velocidad'] || '').trim(),
      ram_capacidad: (row['Memoria RAM – Capacidad'] || row['RAM'] || '').trim(),
      ram_tipo: (row['Memoria RAM – Tipo'] || row['Tipo RAM'] || 'DDR4').trim(),
      disco_capacidad: (row['Disco – Capacidad'] || row['Disco'] || '').trim(),
      disco_tecnologia: (row['Disco – Tecnología'] || row['Tecnologia Disco'] || 'SSD').trim(),
      teclado_marca: (row['Teclado – Marca'] || row['Teclado'] || '').trim(),
      mouse_marca: (row['Mouse – Marca'] || row['Mouse'] || '').trim(),
      monitor_marca: (row['Monitor Marca'] || '').trim(),
      monitor_modelo: (row['Monitor – Modelo'] || '').trim(),
      monitor_tipo: (row['Monitor – Tipo'] || 'LCD').trim(),
      monitor_tamano: (row['Monitor – Tamaño'] || '').trim(),
      monitor_serial: (row['Serial Monitor'] || '').trim(),
      impresora_marca: (row['Impresora Marca'] || '').trim(),
      impresora_modelo: (row['Impresora – Modelo'] || '').trim(),
      impresora_tipo: (row['Impresora – Tipo'] || '').trim(),
      impresora_serial: (row['Impresora – Serial'] || '').trim(),
      impresora_mac: (row['Impresora – MAC'] || '').trim(),
      nombre_equipo: (row['Nombre del Equipo'] || '').trim(),
      en_red: (row['En red'] || 'SI').trim(),
      direccion_ip: (row['Dirección IP'] || row['IP'] || '').trim(),
      mac_address: (row['MAC'] || '').trim(),
      usuario_responsable: (row['Usuario responsable'] || row['Usuario'] || '').trim(),
      area: (row['Área'] || row['Area'] || row['Área / Unidad'] || '').trim(),
      fecha_asignacion: (row['Fecha asignación'] || row['Fecha Asignacion'] || '').trim(),
      tecnico_instalador: (row['Técnico'] || row['Tecnico'] || '').trim(),
      observaciones: (row['Observaciones Adicionales'] || row['Observaciones'] || '').trim(),
      recomendaciones: (row['Recomendación'] || row['Recomendaciones'] || '').trim(),
      ubicacion: (row['Ubicación'] || row['Ubicacion'] || '').trim(),
      proveedor: (row['Proveedor'] || '').trim(),
      office_version: (row['Office'] || row['Suite Ofimatica'] || '').trim(),
      antivirus: (row['Antivirus'] || '').trim(),
    };

    let status: ImportRow['status'] = 'valid';
    let message: string | undefined;

    if (!placa && !serial) {
      status = 'error';
      message = 'Falta Placa de Inventario y Serial';
    } else if (!marca || !modelo) {
      status = 'warning';
      message = 'Marca o Modelo no especificado';
    }

    return { row: i + 2, data, status, message };
  });
}

function parseCsvText(text: string): Record<string, string>[] {
  const lines = text.split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).map(line => {
    const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    const row: Record<string, string> = {};
    headers.forEach((h, i) => { row[h] = values[i] || ''; });
    return row;
  });
}

const TEMPLATE_HEADERS = [
  'Placa de Inventario', 'Serial Pc', 'Sede', 'N° Ficha', 'Marca', 'Modelo', 'Tipo',
  'Sistema Operativo', 'Procesador – Marca', 'Procesador – Tipo', 'Procesador – Velocidad',
  'Memoria RAM – Capacidad', 'Memoria RAM – Tipo', 'Disco – Capacidad', 'Disco – Tecnología',
  'Monitor Marca', 'Monitor – Modelo', 'Monitor – Tamaño', 'Teclado – Marca', 'Mouse – Marca',
  'Impresora Marca', 'Impresora – Modelo', 'Nombre del Equipo', 'Dirección IP', 'MAC',
  'Usuario responsable', 'Área', 'Ubicación', 'Fecha asignación', 'Técnico', 'Observaciones',
];

export default function ExcelImportModal({ onClose, onImport }: Props) {
  const [step, setStep] = useState<'upload' | 'preview' | 'importing'>('upload');
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [filterService, setFilterService] = useState('all');
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase();

    if (ext === 'xlsx' || ext === 'xls') {
      // Use SheetJS for real Excel files
      try {
        const XLSX = await import('xlsx');
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawData = XLSX.utils.sheet_to_json<Record<string, string>>(worksheet, {
          defval: '',
          raw: false,
        });
        if (!rawData.length) {
          alert('No se encontraron datos en el archivo Excel.');
          return;
        }
        const parsed = parseExcelRows(rawData);
        setRows(parsed);
        setStep('preview');
      } catch (err) {
        console.error('SheetJS error:', err);
        alert('Error al leer el archivo Excel. Asegúrate de que sea un .xlsx válido.');
      }
    } else {
      // CSV fallback
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const rawData = parseCsvText(text);
        if (rawData.length === 0) {
          alert('No se pudieron leer datos del archivo. Asegúrate de que sea un CSV válido.');
          return;
        }
        const parsed = parseExcelRows(rawData);
        setRows(parsed);
        setStep('preview');
      };
      reader.readAsText(file, 'UTF-8');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleDownloadTemplate = async () => {
    try {
      const XLSX = await import('xlsx');
      const sampleRow = [
        'INV-2024-001', 'SN123456', 'Sede Principal', 'F001', 'Dell', 'OptiPlex 7090', 'Desktop',
        'Windows 11 Pro', 'Intel', 'Core i7-10700', '2.9 GHz', '16 GB', 'DDR4', '512 GB', 'NVMe SSD',
        'Dell', 'P2422H', '24"', 'Dell', 'Dell', '', '', 'PC-ADMIN', '192.168.1.45',
        'DC:A6:32:11:22:33', 'María García', 'Administración', 'Piso 2 Oficina 204', '2024-03-15',
        'Téc. Ramírez', 'Equipo en buen estado',
      ];
      const ws = XLSX.utils.aoa_to_sheet([TEMPLATE_HEADERS, sampleRow]);
      // Style header row width
      ws['!cols'] = TEMPLATE_HEADERS.map(() => ({ wch: 22 }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Inventario');
      XLSX.writeFile(wb, 'plantilla_inventario_assetdesk.xlsx');
    } catch {
      // Fallback to CSV
      const csv = TEMPLATE_HEADERS.join(',') + '\n' +
        'INV-2024-001,SN123456,Sede Principal,F001,Dell,OptiPlex 7090,Desktop,Windows 11 Pro,Intel,Core i7-10700,2.9 GHz,16 GB,DDR4,512 GB,NVMe SSD,Dell,P2422H,24,Dell,Dell,,,PC-ADMIN,192.168.1.45,DC:A6:32:11:22:33,María García,Administración,Piso 2 Oficina 204,2024-03-15,Téc. Ramírez,';
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'plantilla_inventario_assetdesk.csv';
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const validRows = rows.filter(r => r.status !== 'error');
  const areas = [...new Set(rows.map(r => r.data.area).filter(Boolean))];
  const filteredRows = filterService === 'all' ? rows : rows.filter(r => r.data.area === filterService);

  const handleImport = async () => {
    setStep('importing');
    const toImport = validRows.map(r => r.data);
    await onImport(toImport);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-3xl bg-card border border-border rounded-2xl flex flex-col max-h-[90vh] mx-4 shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div>
            <h2 className="text-base font-semibold text-foreground">Importar Equipos</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Carga masiva desde Excel (.xlsx) o CSV — powered by SheetJS</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin p-6 space-y-5">
          {step === 'upload' && (
            <>
              <div
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-colors ${dragOver ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-secondary/50'}`}>
                <FileSpreadsheet size={32} className="mx-auto text-muted-foreground mb-3" />
                <p className="text-sm font-medium text-foreground mb-1">Arrastra tu archivo aquí</p>
                <p className="text-xs text-muted-foreground">o haz clic para seleccionar</p>
                <p className="text-[10px] text-muted-foreground mt-2">Formatos: .xlsx, .xls, .csv</p>
                <input ref={fileRef} type="file" accept=".csv,.txt,.xlsx,.xls" className="hidden"
                  onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              </div>

              <div className="bg-secondary/50 border border-border rounded-xl p-4 space-y-3">
                <p className="text-xs font-semibold text-foreground">Instrucciones de Importación</p>
                <ul className="text-xs text-muted-foreground space-y-1.5">
                  <li className="flex items-start gap-2"><ChevronRight size={12} className="shrink-0 mt-0.5 text-primary" />Descarga la plantilla Excel (.xlsx) y complétala con los datos de tus equipos</li>
                  <li className="flex items-start gap-2"><ChevronRight size={12} className="shrink-0 mt-0.5 text-primary" />Columnas obligatorias: Placa de Inventario o Serial Pc</li>
                  <li className="flex items-start gap-2"><ChevronRight size={12} className="shrink-0 mt-0.5 text-primary" />Puedes filtrar por Área/Servicio antes de importar</li>
                  <li className="flex items-start gap-2"><ChevronRight size={12} className="shrink-0 mt-0.5 text-primary" />Los registros con error serán omitidos automáticamente</li>
                  <li className="flex items-start gap-2"><ChevronRight size={12} className="shrink-0 mt-0.5 text-primary" />Soporta archivos Excel nativos (.xlsx/.xls) gracias a SheetJS</li>
                </ul>
                <button onClick={handleDownloadTemplate}
                  className="flex items-center gap-2 px-4 py-2 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-lg transition-colors">
                  <Download size={13} /> Descargar Plantilla Excel (.xlsx)
                </button>
              </div>
            </>
          )}

          {step === 'preview' && (
            <>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-4 text-xs">
                  <span className="flex items-center gap-1.5 text-green-400"><CheckCircle size={12} />{rows.filter(r => r.status === 'valid').length} válidos</span>
                  <span className="flex items-center gap-1.5 text-amber-400"><AlertTriangle size={12} />{rows.filter(r => r.status === 'warning').length} advertencias</span>
                  <span className="flex items-center gap-1.5 text-red-400"><X size={12} />{rows.filter(r => r.status === 'error').length} errores</span>
                </div>
                {areas.length > 0 && (
                  <select value={filterService} onChange={e => setFilterService(e.target.value)}
                    className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-foreground focus:outline-none focus:border-primary">
                    <option value="all">Todas las áreas</option>
                    {areas.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                )}
              </div>

              <div className="bg-secondary/30 border border-border rounded-xl overflow-hidden">
                <div className="overflow-x-auto max-h-64">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-secondary/80">
                      <tr className="border-b border-border">
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">#</th>
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">Placa</th>
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">Marca / Modelo</th>
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">Área</th>
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">IP</th>
                        <th className="px-3 py-2 text-left text-muted-foreground font-semibold">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRows.map(r => (
                        <tr key={r.row} className={`border-b border-border/50 ${r.status === 'error' ? 'bg-red-500/5' : r.status === 'warning' ? 'bg-amber-500/5' : ''}`}>
                          <td className="px-3 py-2 text-muted-foreground">{r.row}</td>
                          <td className="px-3 py-2 font-mono text-primary">{r.data.placa || r.data.serial || '—'}</td>
                          <td className="px-3 py-2 text-foreground">{r.data.marca} {r.data.modelo}</td>
                          <td className="px-3 py-2 text-muted-foreground">{r.data.area || '—'}</td>
                          <td className="px-3 py-2 font-mono text-muted-foreground">{r.data.direccion_ip || '—'}</td>
                          <td className="px-3 py-2">
                            {r.status === 'valid' && <span className="text-green-400 flex items-center gap-1"><CheckCircle size={10} /> OK</span>}
                            {r.status === 'warning' && <span className="text-amber-400 flex items-center gap-1"><AlertTriangle size={10} /> {r.message}</span>}
                            {r.status === 'error' && <span className="text-red-400 flex items-center gap-1"><X size={10} /> {r.message}</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {step === 'importing' && (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-muted-foreground">Importando {validRows.length} equipos...</p>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-border shrink-0 flex items-center justify-between gap-3">
          <button onClick={onClose} className="px-4 py-2 text-sm bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors">
            Cancelar
          </button>
          {step === 'preview' && (
            <button onClick={handleImport}
              disabled={validRows.length === 0}
              className="flex items-center gap-2 px-5 py-2 text-sm bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold">
              <Upload size={14} /> Importar {validRows.length} equipos
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
