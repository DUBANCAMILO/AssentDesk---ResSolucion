'use client';

import React, { useState } from 'react';
import { X, QrCode, Monitor, Cpu, HardDrive, MapPin, User, Calendar, Ticket, Wrench, CheckCircle,  } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';
interface Asset {
  id: string;
  tag: string;
  brand: string;
  model: string;
  serial: string;
  cpu: string;
  ram: string;
  storage: string;
  os: string;
  ip: string;
  location: string;
  status: 'operational' | 'maintenance' | 'critical' | 'decommissioned';
  lastTicket: string;
  assignedTo: string;
  hasQr: boolean;
}

const HISTORY = [
  { id: 'hist-1', date: '2026-07-15', type: 'ticket', icon: Ticket, color: 'text-blue-400', label: 'Ticket TKT-2026-089 opened — Screen flickering issue' },
  { id: 'hist-2', date: '2026-07-10', type: 'maintenance', icon: Wrench, color: 'text-amber-400', label: 'RAM upgraded from 8 GB to 16 GB DDR4' },
  { id: 'hist-3', date: '2026-06-22', type: 'assignment', icon: User, color: 'text-green-400', label: 'Assigned to María García — Floor 2, Office 204' },
  { id: 'hist-4', date: '2026-05-14', type: 'ticket', icon: Ticket, color: 'text-blue-400', label: 'Ticket TKT-2026-044 resolved — OS reinstall completed' },
  { id: 'hist-5', date: '2026-03-01', type: 'registration', icon: CheckCircle, color: 'text-cyan-400', label: 'Asset registered and QR code generated' },
];

interface Props {
  asset: Asset;
  onClose: () => void;
}

export default function AssetDetailPanel({ asset, onClose }: Props) {
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'network'>('overview');

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card border-l border-border h-full flex flex-col slide-in-right overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-border flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono-data text-xs text-primary font-semibold">{asset.tag}</span>
              <StatusBadge status={asset.status} />
            </div>
            <h2 className="text-base font-semibold text-foreground">{asset.brand} {asset.model}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">S/N: {asset.serial}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors duration-150"
          >
            <X size={16} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border px-5">
          {(['overview', 'history', 'network'] as const).map((tab) => (
            <button
              key={`tab-${tab}`}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-3 text-xs font-medium capitalize transition-colors duration-150 border-b-2 -mb-px ${
                activeTab === tab
                  ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-4">
          {activeTab === 'overview' && (
            <>
              {/* Hardware specs */}
              <div className="bg-secondary rounded-xl p-4 space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Hardware</p>
                {[
                  { icon: Cpu, label: 'Processor', value: asset.cpu },
                  { icon: Monitor, label: 'Memory', value: asset.ram },
                  { icon: HardDrive, label: 'Storage', value: asset.storage },
                  { icon: Monitor, label: 'OS', value: asset.os },
                ].map((row) => {
                  const Icon = row.icon;
                  return (
                    <div key={`spec-${row.label}`} className="flex items-start gap-3">
                      <Icon size={14} className="text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1">
                        <p className="text-[10px] text-muted-foreground">{row.label}</p>
                        <p className="text-xs text-foreground font-medium">{row.value}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Assignment */}
              <div className="bg-secondary rounded-xl p-4 space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Assignment</p>
                {[
                  { icon: User, label: 'Assigned To', value: asset.assignedTo },
                  { icon: MapPin, label: 'Location', value: asset.location },
                  { icon: Calendar, label: 'Last Ticket', value: asset.lastTicket },
                ].map((row) => {
                  const Icon = row.icon;
                  return (
                    <div key={`assign-${row.label}`} className="flex items-start gap-3">
                      <Icon size={14} className="text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1">
                        <p className="text-[10px] text-muted-foreground">{row.label}</p>
                        <p className="text-xs text-foreground font-medium">{row.value}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* QR Code */}
              <div className="bg-secondary rounded-xl p-4">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">QR Identifier</p>
                {asset.hasQr ? (
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center">
                      <QrCode size={40} className="text-gray-900" />
                    </div>
                    <div>
                      <p className="text-xs text-foreground font-medium">QR Code Active</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">Scan from mobile app to open ticket</p>
                      <button
                        className="mt-2 text-[11px] text-primary hover:underline"
                        onClick={() => toast.success('QR code downloaded')}
                      >
                        Download QR
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 bg-secondary border border-dashed border-border rounded-lg flex items-center justify-center">
                      <QrCode size={24} className="text-muted-foreground/40" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">No QR code generated</p>
                      <button
                        className="mt-1.5 text-[11px] bg-primary text-primary-foreground px-2.5 py-1 rounded-lg"
                        onClick={() => toast.success(`QR code generated for ${asset.tag}`)}
                      >
                        Generate QR
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {activeTab === 'history' && (
            <div className="space-y-1">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Lifecycle Timeline
              </p>
              {HISTORY.map((entry, i) => {
                const Icon = entry.icon;
                return (
                  <div key={entry.id} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`p-1.5 rounded-full bg-secondary ${entry.color}`}>
                        <Icon size={12} />
                      </div>
                      {i < HISTORY.length - 1 && (
                        <div className="w-px flex-1 bg-border mt-1 mb-1" />
                      )}
                    </div>
                    <div className="pb-4 flex-1">
                      <p className="text-xs text-foreground leading-snug">{entry.label}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 font-mono-data">{entry.date}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'network' && (
            <div className="space-y-3">
              <div className="bg-secondary rounded-xl p-4 space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">IP Configuration</p>
                {[
                  { label: 'IP Address', value: asset.ip },
                  { label: 'Subnet Mask', value: '255.255.255.0' },
                  { label: 'Gateway', value: '192.168.1.1' },
                  { label: 'DNS Primary', value: '8.8.8.8' },
                  { label: 'DNS Secondary', value: '8.8.4.4' },
                  { label: 'Switch Port', value: 'SW-02 / Port 14' },
                  { label: 'Assignment Type', value: 'Static' },
                ].map((row) => (
                  <div key={`net-${row.label}`} className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">{row.label}</span>
                    <span className="font-mono-data text-xs text-foreground">{row.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-5 py-4 border-t border-border flex items-center gap-2">
          <button
            className="flex-1 text-xs bg-primary text-primary-foreground py-2 rounded-lg font-medium hover:bg-primary/90 transition-colors duration-150"
            onClick={() => toast.success(`Ticket opened for ${asset.tag}`)}
          >
            Open Ticket
          </button>
          <button
            className="flex-1 text-xs bg-secondary text-foreground py-2 rounded-lg font-medium hover:bg-muted transition-colors duration-150"
            onClick={() => toast.info(`Editing ${asset.tag}`)}
          >
            Edit Asset
          </button>
        </div>
      </div>
    </div>
  );
}