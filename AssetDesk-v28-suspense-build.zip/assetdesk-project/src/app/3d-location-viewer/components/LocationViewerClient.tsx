'use client';

import React, { useState } from 'react';
import FloorPlanSVG from './FloorPlanSVG';
import LocationSidebar from './LocationSidebar';
import PhotoGalleryModal from './PhotoGalleryModal';
import { Layers, Info } from 'lucide-react';

export type AssetStatus = 'operational' | 'maintenance' | 'critical';

export interface FloorAsset {
  id: string;
  tag: string;
  name: string;
  assignedTo: string;
  status: AssetStatus;
  ip: string;
  ticketId?: string;
}

export interface FloorRoom {
  id: string;
  label: string;
  sublabel: string;
  floor: number;
  x: number;
  y: number;
  width: number;
  height: number;
  assets: FloorAsset[];
  photoUrls: string[];
}

// Mock floor plan data — Backend integration point: replace with GET /api/locations/floor-plan
export const FLOOR_DATA: FloorRoom[] = [
  {
    id: 'room-f1-reception',
    label: 'Reception',
    sublabel: 'Floor 1',
    floor: 1,
    x: 40, y: 40, width: 160, height: 100,
    assets: [
      { id: 'fa-001', tag: 'AST-2024-008', name: 'Dell OptiPlex 5090', assignedTo: 'Carmen Torres', status: 'operational', ip: '192.168.1.155' },
    ],
    photoUrls: ['reception-desk.jpg'],
  },
  {
    id: 'room-f1-office-102',
    label: 'Office 102',
    sublabel: 'Floor 1',
    floor: 1,
    x: 220, y: 40, width: 140, height: 100,
    assets: [
      { id: 'fa-002', tag: 'AST-2024-002', name: 'HP EliteDesk 800 G6', assignedTo: 'Luis Fernández', status: 'critical', ip: '192.168.1.62', ticketId: 'TKT-2026-089' },
    ],
    photoUrls: ['office-102.jpg'],
  },
  {
    id: 'room-f1-office-108',
    label: 'Office 108',
    sublabel: 'Floor 1',
    floor: 1,
    x: 380, y: 40, width: 140, height: 100,
    assets: [
      { id: 'fa-003', tag: 'AST-2024-009', name: 'HP ProDesk 400 G7', assignedTo: 'Unassigned', status: 'maintenance', ip: '192.168.1.171' },
    ],
    photoUrls: ['office-108.jpg'],
  },
  {
    id: 'room-f1-exec',
    label: 'Executive Suite',
    sublabel: 'Floor 1',
    floor: 1,
    x: 40, y: 160, width: 200, height: 120,
    assets: [
      { id: 'fa-004', tag: 'AST-2024-006', name: 'HP Z2 Tower G9', assignedTo: 'Roberto Sánchez', status: 'critical', ip: '192.168.1.125', ticketId: 'TKT-2026-088' },
    ],
    photoUrls: ['exec-suite.jpg'],
  },
  {
    id: 'room-f1-warehouse',
    label: 'Warehouse',
    sublabel: 'Floor 1',
    floor: 1,
    x: 260, y: 160, width: 260, height: 120,
    assets: [
      { id: 'fa-005', tag: 'AST-2024-012', name: 'Dell Vostro 3910', assignedTo: 'Unassigned', status: 'maintenance', ip: 'Unassigned' },
    ],
    photoUrls: ['warehouse.jpg'],
  },
  {
    id: 'room-f2-office-204',
    label: 'Office 204',
    sublabel: 'Floor 2',
    floor: 2,
    x: 40, y: 40, width: 160, height: 100,
    assets: [
      { id: 'fa-006', tag: 'AST-2024-001', name: 'Dell OptiPlex 7090', assignedTo: 'María García', status: 'maintenance', ip: '192.168.1.45', ticketId: 'TKT-2026-084' },
    ],
    photoUrls: ['office-204.jpg'],
  },
  {
    id: 'room-f2-design-lab',
    label: 'Design Lab',
    sublabel: 'Floor 2',
    floor: 2,
    x: 220, y: 40, width: 180, height: 100,
    assets: [
      { id: 'fa-007', tag: 'AST-2024-004', name: 'Apple Mac Mini M2', assignedTo: 'Ana Rodríguez', status: 'operational', ip: '192.168.1.91' },
    ],
    photoUrls: ['design-lab.jpg'],
  },
  {
    id: 'room-f2-office-208',
    label: 'Office 208',
    sublabel: 'Floor 2',
    floor: 2,
    x: 420, y: 40, width: 100, height: 100,
    assets: [
      { id: 'fa-008', tag: 'AST-2024-011', name: 'Lenovo IdeaCentre 5i', assignedTo: 'Sofía Herrera', status: 'operational', ip: '192.168.1.200' },
    ],
    photoUrls: ['office-208.jpg'],
  },
  {
    id: 'room-f2-office-211',
    label: 'Office 211',
    sublabel: 'Floor 2',
    floor: 2,
    x: 40, y: 160, width: 200, height: 120,
    assets: [
      { id: 'fa-009', tag: 'AST-2024-007', name: 'Lenovo ThinkStation P360', assignedTo: 'Valentina López', status: 'maintenance', ip: '192.168.1.140', ticketId: 'TKT-2026-087' },
    ],
    photoUrls: ['office-211.jpg'],
  },
  {
    id: 'room-f3-server',
    label: 'Server Room',
    sublabel: 'Floor 3',
    floor: 3,
    x: 40, y: 40, width: 200, height: 130,
    assets: [
      { id: 'fa-010', tag: 'AST-2024-003', name: 'Lenovo ThinkCentre M720q', assignedTo: 'Unassigned', status: 'maintenance', ip: '192.168.1.78', ticketId: 'TKT-2026-086' },
    ],
    photoUrls: ['server-room-1.jpg', 'server-room-2.jpg'],
  },
  {
    id: 'room-f3-render',
    label: 'Render Farm',
    sublabel: 'Floor 3',
    floor: 3,
    x: 260, y: 40, width: 180, height: 130,
    assets: [
      { id: 'fa-011', tag: 'AST-2024-005', name: 'Dell Precision 3660', assignedTo: 'Jorge Morales', status: 'operational', ip: '192.168.1.110' },
    ],
    photoUrls: ['render-farm.jpg'],
  },
  {
    id: 'room-f3-media',
    label: 'Media Suite',
    sublabel: 'Floor 3',
    floor: 3,
    x: 40, y: 190, width: 400, height: 100,
    assets: [
      { id: 'fa-012', tag: 'AST-2024-010', name: 'Apple Mac Studio M2 Ultra', assignedTo: 'Diego Vargas', status: 'operational', ip: '192.168.1.185' },
    ],
    photoUrls: ['media-suite.jpg'],
  },
];

export default function LocationViewerClient() {
  const [activeFloor, setActiveFloor] = useState(1);
  const [selectedRoom, setSelectedRoom] = useState<FloorRoom | null>(null);
  const [photoGalleryRoom, setPhotoGalleryRoom] = useState<FloorRoom | null>(null);
  const [showLegend, setShowLegend] = useState(true);

  const floorRooms = FLOOR_DATA.filter((r) => r.floor === activeFloor);

  const floorStats = {
    operational: floorRooms.reduce((acc, r) => acc + r.assets.filter((a) => a.status === 'operational').length, 0),
    maintenance: floorRooms.reduce((acc, r) => acc + r.assets.filter((a) => a.status === 'maintenance').length, 0),
    critical: floorRooms.reduce((acc, r) => acc + r.assets.filter((a) => a.status === 'critical').length, 0),
  };

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Main floor plan area */}
      <div className="flex-1 flex flex-col overflow-hidden bg-background">
        {/* Floor selector + controls */}
        <div className="px-6 py-3 border-b border-border flex items-center justify-between bg-card">
          <div className="flex items-center gap-1">
            <Layers size={15} className="text-muted-foreground mr-2" />
            {[1, 2, 3].map((floor) => {
              const fRooms = FLOOR_DATA.filter((r) => r.floor === floor);
              const hasCritical = fRooms.some((r) => r.assets.some((a) => a.status === 'critical'));
              const hasMaintenance = fRooms.some((r) => r.assets.some((a) => a.status === 'maintenance'));
              return (
                <button
                  key={`floor-${floor}`}
                  onClick={() => { setActiveFloor(floor); setSelectedRoom(null); }}
                  className={`relative flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                    activeFloor === floor
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Floor {floor}
                  {hasCritical && (
                    <span className="w-2 h-2 rounded-full bg-red-400 shrink-0" />
                  )}
                  {!hasCritical && hasMaintenance && (
                    <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-4">
            {/* Floor stats */}
            <div className="hidden md:flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-green-400">
                <span className="w-2 h-2 rounded-full bg-green-400" />
                {floorStats.operational} operational
              </span>
              <span className="flex items-center gap-1.5 text-amber-400">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                {floorStats.maintenance} maintenance
              </span>
              <span className="flex items-center gap-1.5 text-red-400">
                <span className="w-2 h-2 rounded-full bg-red-400" />
                {floorStats.critical} critical
              </span>
            </div>

            <button
              onClick={() => setShowLegend(!showLegend)}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground px-2.5 py-1.5 rounded-lg hover:bg-secondary transition-colors duration-150"
            >
              <Info size={13} />
              Legend
            </button>
          </div>
        </div>

        {/* SVG floor plan */}
        <div className="flex-1 overflow-auto scrollbar-thin p-6 flex items-start justify-center">
          <div className="relative">
            {showLegend && (
              <div className="absolute top-0 right-0 bg-card border border-border rounded-xl p-3 z-10 min-w-[160px]">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Status Legend</p>
                {[
                  { color: 'bg-green-400', label: 'Operational' },
                  { color: 'bg-amber-400', label: 'Maintenance / Open Ticket' },
                  { color: 'bg-red-400', label: 'Critical Failure' },
                ].map((item) => (
                  <div key={`legend-${item.label}`} className="flex items-center gap-2 mb-1.5">
                    <span className={`w-3 h-3 rounded-full ${item.color}`} />
                    <span className="text-xs text-muted-foreground">{item.label}</span>
                  </div>
                ))}
                <div className="border-t border-border mt-2 pt-2">
                  <p className="text-[10px] text-muted-foreground">Click any room to inspect assets</p>
                </div>
              </div>
            )}

            <FloorPlanSVG
              rooms={floorRooms}
              selectedRoomId={selectedRoom?.id ?? null}
              onRoomClick={(room) => setSelectedRoom(room)}
              floor={activeFloor}
            />
          </div>
        </div>
      </div>

      {/* Right sidebar */}
      <LocationSidebar
        room={selectedRoom}
        onClose={() => setSelectedRoom(null)}
        onOpenGallery={(room) => setPhotoGalleryRoom(room)}
      />

      {/* Photo gallery modal */}
      {photoGalleryRoom && (
        <PhotoGalleryModal
          room={photoGalleryRoom}
          onClose={() => setPhotoGalleryRoom(null)}
        />
      )}
    </div>
  );
}