'use client';

import React from 'react';
import {
  MapPin,
  Monitor,
  Wifi,
  User,
  Ticket,
  Images,
  X,
  AlertTriangle,
  CheckCircle,
  Wrench,
  ChevronRight,
} from 'lucide-react';
import type { FloorRoom } from './LocationViewerClient';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';

interface Props {
  room: FloorRoom | null;
  onClose: () => void;
  onOpenGallery: (room: FloorRoom) => void;
}

const STATUS_ICON: Record<string, React.ElementType> = {
  operational: CheckCircle,
  maintenance: Wrench,
  critical: AlertTriangle,
};

const STATUS_COLOR: Record<string, string> = {
  operational: 'text-green-400',
  maintenance: 'text-amber-400',
  critical: 'text-red-400',
};

export default function LocationSidebar({ room, onClose, onOpenGallery }: Props) {
  if (!room) {
    return (
      <div className="w-72 border-l border-border bg-card flex flex-col items-center justify-center p-6 text-center shrink-0">
        <MapPin size={32} className="text-muted-foreground/30 mb-3" />
        <p className="text-sm font-medium text-muted-foreground">No room selected</p>
        <p className="text-xs text-muted-foreground/60 mt-1">
          Click any room on the floor plan to inspect its assets and status
        </p>
      </div>
    );
  }

  const criticalAssets = room.assets.filter((a) => a.status === 'critical');
  const maintenanceAssets = room.assets.filter((a) => a.status === 'maintenance');
  const operationalAssets = room.assets.filter((a) => a.status === 'operational');

  return (
    <div className="w-72 border-l border-border bg-card flex flex-col shrink-0 slide-in-right overflow-hidden">
      {/* Header */}
      <div className="px-4 py-4 border-b border-border flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5 mb-0.5">
            <MapPin size={13} className="text-primary" />
            <span className="text-xs text-muted-foreground">{room.sublabel}</span>
          </div>
          <h3 className="text-base font-semibold text-foreground">{room.label}</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {room.assets.length} asset{room.assets.length !== 1 ? 's' : ''} registered
          </p>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors duration-150"
        >
          <X size={15} />
        </button>
      </div>

      {/* Status summary */}
      <div className="px-4 py-3 border-b border-border flex items-center gap-3">
        {criticalAssets.length > 0 && (
          <div className="flex items-center gap-1.5 bg-red-500/10 px-2.5 py-1.5 rounded-lg">
            <AlertTriangle size={12} className="text-red-400" />
            <span className="text-xs font-semibold text-red-400">{criticalAssets.length} critical</span>
          </div>
        )}
        {maintenanceAssets.length > 0 && (
          <div className="flex items-center gap-1.5 bg-amber-500/10 px-2.5 py-1.5 rounded-lg">
            <Wrench size={12} className="text-amber-400" />
            <span className="text-xs font-semibold text-amber-400">{maintenanceAssets.length} maintenance</span>
          </div>
        )}
        {operationalAssets.length > 0 && (
          <div className="flex items-center gap-1.5 bg-green-500/10 px-2.5 py-1.5 rounded-lg">
            <CheckCircle size={12} className="text-green-400" />
            <span className="text-xs font-semibold text-green-400">{operationalAssets.length} ok</span>
          </div>
        )}
      </div>

      {/* Asset list */}
      <div className="flex-1 overflow-y-auto scrollbar-thin p-4 space-y-3">
        {room.assets.length === 0 && (
          <div className="text-center py-8">
            <Monitor size={24} className="text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-xs text-muted-foreground">No assets registered in this location</p>
          </div>
        )}

        {room.assets.map((asset) => {
          const StatusIcon = STATUS_ICON[asset.status] ?? CheckCircle;
          return (
            <div
              key={asset.id}
              className={`bg-secondary rounded-xl p-3 border transition-colors duration-150 ${
                asset.status === 'critical' ?'border-red-500/30'
                  : asset.status === 'maintenance' ?'border-amber-500/20' :'border-border'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <StatusIcon size={13} className={STATUS_COLOR[asset.status]} />
                  <span className="font-mono-data text-[11px] text-primary font-semibold">
                    {asset.tag}
                  </span>
                </div>
                <StatusBadge status={asset.status} showDot={false} />
              </div>

              <p className="text-xs font-medium text-foreground mb-2">{asset.name}</p>

              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <User size={11} className="text-muted-foreground shrink-0" />
                  <span className="text-[11px] text-muted-foreground truncate">{asset.assignedTo}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Wifi size={11} className="text-muted-foreground shrink-0" />
                  <span className={`font-mono-data text-[11px] ${asset.ip === 'Unassigned' ? 'text-muted-foreground/60' : 'text-cyan-400'}`}>
                    {asset.ip}
                  </span>
                </div>
                {asset.ticketId && (
                  <div className="flex items-center gap-2">
                    <Ticket size={11} className="text-blue-400 shrink-0" />
                    <span className="font-mono-data text-[11px] text-blue-400">{asset.ticketId}</span>
                  </div>
                )}
              </div>

              {asset.status !== 'operational' && (
                <button
                  className="mt-2.5 w-full flex items-center justify-center gap-1 text-[11px] text-primary bg-primary/10 hover:bg-primary/20 py-1.5 rounded-lg transition-colors duration-150 font-medium"
                  onClick={() => toast.info(`Opening ticket for ${asset.tag}`)}
                >
                  <Ticket size={11} />
                  {asset.ticketId ? 'View Ticket' : 'Open Ticket'}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Photo gallery button */}
      <div className="px-4 py-4 border-t border-border">
        <button
          className="w-full flex items-center justify-between px-4 py-3 bg-secondary rounded-xl hover:bg-muted transition-colors duration-150 group"
          onClick={() => onOpenGallery(room)}
        >
          <div className="flex items-center gap-2">
            <Images size={15} className="text-accent" />
            <div className="text-left">
              <p className="text-xs font-semibold text-foreground">Location Photos</p>
              <p className="text-[10px] text-muted-foreground">{room.photoUrls.length} image{room.photoUrls.length !== 1 ? 's' : ''} uploaded</p>
            </div>
          </div>
          <ChevronRight size={14} className="text-muted-foreground group-hover:text-foreground transition-colors duration-150" />
        </button>
      </div>
    </div>
  );
}