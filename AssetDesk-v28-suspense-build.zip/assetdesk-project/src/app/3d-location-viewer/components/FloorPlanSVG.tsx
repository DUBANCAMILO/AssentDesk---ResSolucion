'use client';

import React from 'react';
import type { FloorRoom } from './LocationViewerClient';

interface Props {
  rooms: FloorRoom[];
  selectedRoomId: string | null;
  onRoomClick: (room: FloorRoom) => void;
  floor: number;
}

const STATUS_FILL: Record<string, string> = {
  operational: '#22c55e',
  maintenance: '#f59e0b',
  critical: '#ef4444',
};

function getRoomStatusColor(room: FloorRoom): string {
  const hasCritical = room.assets.some((a) => a.status === 'critical');
  if (hasCritical) return '#ef4444';
  const hasMaintenance = room.assets.some((a) => a.status === 'maintenance');
  if (hasMaintenance) return '#f59e0b';
  return '#22c55e';
}

export default function FloorPlanSVG({ rooms, selectedRoomId, onRoomClick, floor }: Props) {
  const svgWidth = 580;
  const svgHeight = 340;

  return (
    <svg
      width={svgWidth}
      height={svgHeight}
      viewBox={`0 0 ${svgWidth} ${svgHeight}`}
      className="rounded-xl border border-border"
      style={{ background: 'var(--card)' }}
      aria-label={`Floor ${floor} plan`}
      role="img"
    >
      {/* Grid background */}
      <defs>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="var(--border)" strokeWidth="0.4" strokeOpacity="0.5" />
        </pattern>
        {rooms.map((room) => {
          const statusColor = getRoomStatusColor(room);
          return (
            <radialGradient key={`grad-${room.id}`} id={`glow-${room.id}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={statusColor} stopOpacity="0.08" />
              <stop offset="100%" stopColor={statusColor} stopOpacity="0.02" />
            </radialGradient>
          );
        })}
      </defs>
      <rect width={svgWidth} height={svgHeight} fill="url(#grid)" />

      {/* Floor label */}
      <text
        x={svgWidth - 16}
        y={24}
        textAnchor="end"
        fontSize="11"
        fill="var(--muted-foreground)"
        fontFamily="var(--font-sans)"
        fontWeight="600"
        letterSpacing="0.08em"
      >
        FLOOR {floor}
      </text>

      {/* Rooms */}
      {rooms.map((room) => {
        const isSelected = selectedRoomId === room.id;
        const statusColor = getRoomStatusColor(room);
        const hasCritical = room.assets.some((a) => a.status === 'critical');

        return (
          <g
            key={room.id}
            onClick={() => onRoomClick(room)}
            style={{ cursor: 'pointer' }}
            role="button"
            aria-label={`${room.label} — click to inspect assets`}
          >
            {/* Room background glow */}
            <rect
              x={room.x - 2}
              y={room.y - 2}
              width={room.width + 4}
              height={room.height + 4}
              rx={10}
              fill={`url(#glow-${room.id})`}
            />

            {/* Room border */}
            <rect
              x={room.x}
              y={room.y}
              width={room.width}
              height={room.height}
              rx={8}
              fill={isSelected ? `${statusColor}18` : 'var(--secondary)'}
              stroke={isSelected ? statusColor : 'var(--border)'}
              strokeWidth={isSelected ? 2 : 1}
              style={{ transition: 'all 0.2s ease' }}
            />

            {/* 3D depth effect — bottom edge */}
            <rect
              x={room.x + 4}
              y={room.y + room.height}
              width={room.width - 4}
              height={4}
              rx={2}
              fill={statusColor}
              fillOpacity={0.2}
            />

            {/* Room label */}
            <text
              x={room.x + room.width / 2}
              y={room.y + 20}
              textAnchor="middle"
              fontSize="11"
              fontWeight="600"
              fill="var(--foreground)"
              fontFamily="var(--font-sans)"
            >
              {room.label}
            </text>

            {/* Asset nodes */}
            {room.assets.map((asset, ai) => {
              const nodeX = room.x + 18 + (ai % 4) * 28;
              const nodeY = room.y + 38 + Math.floor(ai / 4) * 28;
              const nodeColor = STATUS_FILL[asset.status] ?? '#64748b';
              return (
                <g key={asset.id}>
                  {/* Pulse ring for critical */}
                  {asset.status === 'critical' && (
                    <circle cx={nodeX} cy={nodeY} r={10} fill={nodeColor} fillOpacity={0.15}>
                      <animate attributeName="r" from="8" to="14" dur="1.5s" repeatCount="indefinite" />
                      <animate attributeName="fill-opacity" from="0.2" to="0" dur="1.5s" repeatCount="indefinite" />
                    </circle>
                  )}
                  {/* Node */}
                  <circle
                    cx={nodeX}
                    cy={nodeY}
                    r={7}
                    fill={nodeColor}
                    fillOpacity={0.9}
                    stroke={nodeColor}
                    strokeWidth={1.5}
                    strokeOpacity={0.5}
                  />
                  {/* Monitor icon inside node — simplified */}
                  <rect
                    x={nodeX - 4}
                    y={nodeY - 3}
                    width={8}
                    height={5}
                    rx={1}
                    fill="white"
                    fillOpacity={0.7}
                  />
                  <rect
                    x={nodeX - 1.5}
                    y={nodeY + 2}
                    width={3}
                    height={2}
                    fill="white"
                    fillOpacity={0.5}
                  />
                </g>
              );
            })}

            {/* Asset count badge */}
            {room.assets.length > 0 && (
              <g>
                <circle
                  cx={room.x + room.width - 14}
                  cy={room.y + 14}
                  r={10}
                  fill={statusColor}
                  fillOpacity={0.9}
                />
                <text
                  x={room.x + room.width - 14}
                  y={room.y + 18}
                  textAnchor="middle"
                  fontSize="9"
                  fontWeight="700"
                  fill="white"
                  fontFamily="var(--font-sans)"
                >
                  {room.assets.length}
                </text>
              </g>
            )}

            {/* Critical warning icon */}
            {hasCritical && (
              <text
                x={room.x + 10}
                y={room.y + 15}
                fontSize="10"
                fill="#ef4444"
              >
                ⚠
              </text>
            )}
          </g>
        );
      })}

      {/* Corridor areas */}
      <rect
        x={0}
        y={svgHeight - 40}
        width={svgWidth}
        height={40}
        fill="var(--muted)"
        fillOpacity={0.3}
      />
      <text
        x={svgWidth / 2}
        y={svgHeight - 16}
        textAnchor="middle"
        fontSize="10"
        fill="var(--muted-foreground)"
        fontFamily="var(--font-sans)"
        letterSpacing="0.1em"
      >
        CORRIDOR — FLOOR {floor}
      </text>
    </svg>
  );
}