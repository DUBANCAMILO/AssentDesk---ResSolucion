'use client';

import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Upload, Images } from 'lucide-react';
import type { FloorRoom } from './LocationViewerClient';
import Modal from '@/components/ui/Modal';
import { toast } from 'sonner';

interface Props {
  room: FloorRoom;
  onClose: () => void;
}

// Placeholder photo data — Backend integration point: replace with presigned URLs from storage
const PHOTO_PLACEHOLDERS = [
  { id: 'photo-a', label: 'Workstation Overview', description: 'Full desk setup showing monitor, peripherals and cable management' },
  { id: 'photo-b', label: 'Equipment Detail', description: 'Close-up of tower unit and connection ports' },
  { id: 'photo-c', label: 'Cable Management', description: 'Rear panel showing network and power connections' },
];

export default function PhotoGalleryModal({ room, onClose }: Props) {
  const [activeIndex, setActiveIndex] = useState(0);
  const photos = room.photoUrls.length > 0
    ? room.photoUrls.map((url, i) => ({ ...PHOTO_PLACEHOLDERS[i % PHOTO_PLACEHOLDERS.length], url }))
    : [];

  const prev = () => setActiveIndex((i) => (i - 1 + photos.length) % photos.length);
  const next = () => setActiveIndex((i) => (i + 1) % photos.length);

  return (
    <Modal open onClose={onClose} title={`Photo Gallery — ${room.label}`} size="lg">
      <div className="space-y-4">
        {/* Location info */}
        <div className="flex items-center gap-2 pb-3 border-b border-border">
          <MapPin size={13} className="text-primary" />
          <span className="text-xs text-muted-foreground">{room.sublabel} · {room.label}</span>
          <span className="ml-auto text-xs text-muted-foreground">
            {photos.length} photo{photos.length !== 1 ? 's' : ''}
          </span>
        </div>

        {photos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <Images size={40} className="text-muted-foreground/30" />
            <p className="text-sm font-medium text-muted-foreground">No photos uploaded yet</p>
            <p className="text-xs text-muted-foreground/60 text-center max-w-xs">
              Upload real photos of this workstation or rack to help technicians identify the physical setup during incidents
            </p>
            <button
              className="flex items-center gap-2 text-sm bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors duration-150"
              onClick={() => toast.info('Photo upload — connect to backend storage')}
            >
              <Upload size={14} />
              Upload Photo
            </button>
          </div>
        ) : (
          <>
            {/* Main photo display */}
            <div className="relative bg-secondary rounded-xl overflow-hidden h-64 flex items-center justify-center border border-border">
              <div className="text-center">
                <Images size={48} className="text-muted-foreground/20 mx-auto mb-3" />
                <p className="text-sm font-medium text-muted-foreground">
                  {photos[activeIndex]?.label}
                </p>
                <p className="text-xs text-muted-foreground/60 mt-1 max-w-xs px-4">
                  {photos[activeIndex]?.description}
                </p>
                <p className="font-mono-data text-[10px] text-muted-foreground/40 mt-2">
                  {photos[activeIndex]?.url}
                </p>
              </div>

              {photos.length > 1 && (
                <>
                  <button
                    onClick={prev}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-card/80 rounded-lg text-foreground hover:bg-card transition-colors duration-150 border border-border"
                    aria-label="Previous photo"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <button
                    onClick={next}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-card/80 rounded-lg text-foreground hover:bg-card transition-colors duration-150 border border-border"
                    aria-label="Next photo"
                  >
                    <ChevronRight size={16} />
                  </button>
                </>
              )}

              {/* Photo counter */}
              <div className="absolute bottom-3 right-3 bg-card/80 text-xs text-muted-foreground px-2 py-1 rounded-lg border border-border font-mono-data">
                {activeIndex + 1} / {photos.length}
              </div>
            </div>

            {/* Thumbnail strip */}
            {photos.length > 1 && (
              <div className="flex gap-2">
                {photos.map((photo, i) => (
                  <button
                    key={photo.id}
                    onClick={() => setActiveIndex(i)}
                    className={`flex-1 h-14 bg-secondary rounded-lg border transition-all duration-150 flex items-center justify-center ${
                      activeIndex === i
                        ? 'border-primary ring-1 ring-primary/30' :'border-border hover:border-muted-foreground'
                    }`}
                    aria-label={`View photo ${i + 1}: ${photo.label}`}
                  >
                    <div className="text-center">
                      <Images size={14} className="text-muted-foreground/40 mx-auto" />
                      <p className="text-[9px] text-muted-foreground/60 mt-0.5 truncate px-1">{photo.label}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {/* Upload action */}
        <div className="flex items-center justify-between pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Photos help field technicians identify equipment during incidents
          </p>
          <button
            className="flex items-center gap-1.5 text-xs bg-secondary text-foreground px-3 py-2 rounded-lg hover:bg-muted transition-colors duration-150 border border-border"
            onClick={() => toast.info('Photo upload — connect to backend storage')}
          >
            <Upload size={12} />
            Add Photo
          </button>
        </div>
      </div>
    </Modal>
  );
}