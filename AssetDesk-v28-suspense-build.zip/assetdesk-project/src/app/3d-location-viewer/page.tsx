import React from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import LocationViewerClient from './components/LocationViewerClient';

export default function LocationViewerPage() {
  return (
    <AppLayout>
      <Topbar
        title="3D Location Viewer"
        subtitle="Physical asset distribution and status overlay"
      />
      <div className="flex-1 overflow-hidden flex">
        <LocationViewerClient />
      </div>
    </AppLayout>
  );
}