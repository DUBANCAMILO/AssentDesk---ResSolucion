'use client';

import React, { useState, useEffect, useMemo } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { Search, Archive, AlertTriangle, User, MapPin, ChevronUp, ChevronDown, ChevronsUpDown, X, Trash2, RotateCcw, RefreshCw, FileDown } from 'lucide-react';
import { bajaService } from '@/lib/services/assetService';
import { downloadTablePdf } from '@/lib/pdfReport';

interface BajaAsset {
  id: string;
  asset_id?: string;
  placa?: string;
  tag?: string;
  brand?: string;
  model?: string;
  serial?: string;
  cpu?: string;
  ram?: string;
  storage?: string;
  os?: string;
  location?: string;
  last_user?: string;
  area?: string;
  fecha_baja?: string;
  motivo_baja?: string;
  tecnico_responsable?: string;
  observaciones?: string;
  disposicion?: string;
  acta_numero?: string;
}

const MOTIVO_LABELS: Record<string, string> = {
  obsolescencia: 'Obsolescencia',
  'daño_irreparable': 'Daño Irreparable',
  robo_perdida: 'Robo / Pérdida',
  donacion: 'Donación',
  fin_vida_util: 'Fin de Vida Útil',
};

const DISPOSICION_LABELS: Record<string, string> = {
  almacenado: 'Almacenado',
  donado: 'Donado',
  destruido: 'Destruido',
  en_proceso: 'En Proceso',
};

const DISPOSICION_COLORS: Record<string, string> = {
  almacenado: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  donado: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  destruido: 'text-red-400 bg-red-500/10 border-red-500/20',
  en_proceso: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
};

const MOTIVO_COLORS: Record<string, string> = {
  obsolescencia: 'text-amber-400',
  'daño_irreparable': 'text-red-400',
  robo_perdida: 'text-red-500',
  donacion: 'text-blue-400',
  fin_vida_util: 'text-gray-400',
};

type SortKey = 'placa' | 'brand' | 'fecha_baja' | 'motivo_baja' | 'disposicion';
type SortDir = 'asc' | 'desc';

export default function BajasPage() {
  const [bajas, setBajas] = useState<BajaAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [motivoFilter, setMotivoFilter] = useState('all');
  const [disposicionFilter, setDisposicionFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('fecha_baja');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [selected, setSelected] = useState<BajaAsset | null>(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const loadBajas = async () => {
    setLoading(true);
    const data = await bajaService.getAll();
    setBajas(data);
    setLoading(false);
  };

  useEffect(() => { loadBajas(); }, []);

  const filtered = useMemo(() => {
    let data = [...bajas];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(a =>
        (a.placa || '').toLowerCase().includes(q) ||
        (a.brand || '').toLowerCase().includes(q) ||
        (a.model || '').toLowerCase().includes(q) ||
        (a.serial || '').toLowerCase().includes(q) ||
        (a.last_user || '').toLowerCase().includes(q) ||
        (a.area || '').toLowerCase().includes(q)
      );
    }
    if (motivoFilter !== 'all') data = data.filter(a => a.motivo_baja === motivoFilter);
    if (disposicionFilter !== 'all') data = data.filter(a => a.disposicion === disposicionFilter);
    data.sort((a, b) => {
      const av = String((a as unknown as Record<string, unknown>)[sortKey] || '');
      const bv = String((b as unknown as Record<string, unknown>)[sortKey] || '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return data;
  }, [bajas, search, motivoFilter, disposicionFilter, sortKey, sortDir]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
      : <ChevronsUpDown size={11} className="opacity-40" />;

  const handleReactivate = async (baja: BajaAsset) => {
    await bajaService.reactivate(baja.id, baja.asset_id);
    setSelected(null);
    loadBajas();
  };

  const handleExportReport = async () => {
    try {
      await downloadTablePdf(
        'Informe de activos dados de baja',
        ['Placa', 'Equipo', 'Serial', 'Fecha', 'Motivo', 'Disposición', 'Técnico'],
        filtered.map((item) => [
          item.placa || '',
          `${item.brand || ''} ${item.model || ''}`.trim(),
          item.serial || '',
          item.fecha_baja || '',
          MOTIVO_LABELS[item.motivo_baja || ''] || item.motivo_baja || '',
          DISPOSICION_LABELS[item.disposicion || ''] || item.disposicion || '',
          item.tecnico_responsable || '',
        ]),
        `informe_bajas_${new Date().toISOString().slice(0, 10)}`,
      );
    } catch (error) {
      console.error('Error exportando informe de bajas:', error);
      alert('No se pudo descargar el informe de bajas.');
    }
  };

  const byMotivo = Object.entries(MOTIVO_LABELS).map(([k, v]) => ({
    key: k, label: v, count: bajas.filter(a => a.motivo_baja === k).length,
  }));

  return (
    <AppLayout>
      <Topbar title="Módulo de Bajas" subtitle="Gestión de activos retirados y dados de baja" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Bajas', value: bajas.length, color: 'text-foreground', bg: 'bg-secondary', icon: Archive },
            { label: 'En Proceso', value: bajas.filter(a => a.disposicion === 'en_proceso').length, color: 'text-violet-400', bg: 'bg-violet-500/10', icon: AlertTriangle },
            { label: 'Almacenados', value: bajas.filter(a => a.disposicion === 'almacenado').length, color: 'text-amber-400', bg: 'bg-amber-500/10', icon: Archive },
            { label: 'Donados / Destruidos', value: bajas.filter(a => ['donado', 'destruido'].includes(a.disposicion || '')).length, color: 'text-blue-400', bg: 'bg-blue-500/10', icon: Trash2 },
          ].map(m => {
            const MIcon = m.icon;
            return (
              <div key={m.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                <div className={`p-2.5 rounded-xl ${m.bg}`}><MIcon size={16} className={m.color} /></div>
                <div>
                  <p className={`text-2xl font-bold font-mono-data ${m.color}`}>{m.value}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{m.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Motivo breakdown */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Distribución por Motivo de Baja</p>
          <div className="flex flex-wrap gap-2">
            {byMotivo.map(m => (
              <div key={m.key} className="flex items-center gap-2 bg-secondary/60 border border-border rounded-lg px-3 py-2">
                <span className={`text-xs font-semibold ${MOTIVO_COLORS[m.key]}`}>{m.count}</span>
                <span className="text-xs text-muted-foreground">{m.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-border">
            <div className="relative flex-1 min-w-48">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
                placeholder="Buscar por placa, marca, usuario..."
                className="w-full pl-8 pr-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
            </div>
            <select value={motivoFilter} onChange={e => { setMotivoFilter(e.target.value); setPage(1); }}
              className="px-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground focus:outline-none focus:border-primary">
              <option value="all">Todos los motivos</option>
              {Object.entries(MOTIVO_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <select value={disposicionFilter} onChange={e => { setDisposicionFilter(e.target.value); setPage(1); }}
              className="px-3 py-2 text-xs bg-secondary border border-border rounded-lg text-foreground focus:outline-none focus:border-primary">
              <option value="all">Toda disposición</option>
              {Object.entries(DISPOSICION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button onClick={handleExportReport}
              className="flex items-center gap-2 px-3 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">
              <FileDown size={14} /> Descargar informe
            </button>
            <button onClick={loadBajas} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary border border-border transition-colors">
              <RefreshCw size={14} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  {[
                    { key: 'placa', label: 'Placa' },
                    { key: 'brand', label: 'Equipo' },
                    { key: null, label: 'Último Usuario' },
                    { key: 'fecha_baja', label: 'Fecha Baja' },
                    { key: 'motivo_baja', label: 'Motivo' },
                    { key: 'disposicion', label: 'Disposición' },
                    { key: null, label: 'Acciones' },
                  ].map((col, i) => (
                    <th key={i} className={`px-4 py-3 text-left font-semibold text-muted-foreground uppercase tracking-wider ${col.key ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                      onClick={() => col.key && handleSort(col.key as SortKey)}>
                      <div className="flex items-center gap-1">{col.label}{col.key && <SortIcon col={col.key as SortKey} />}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                    <RefreshCw size={16} className="inline animate-spin mr-2" />Cargando...
                  </td></tr>
                ) : paginated.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">No hay activos dados de baja</td></tr>
                ) : paginated.map((baja, idx) => (
                  <tr key={baja.id} className={`border-b border-border/50 hover:bg-secondary/30 transition-colors ${idx % 2 === 0 ? '' : 'bg-secondary/10'}`}>
                    <td className="px-4 py-3 font-mono-data text-primary text-xs font-semibold">{baja.placa}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{baja.brand} {baja.model}</div>
                      <div className="text-[10px] text-muted-foreground">S/N: {baja.serial}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 text-muted-foreground"><User size={10} />{baja.last_user || '—'}</div>
                      <div className="flex items-center gap-1 text-muted-foreground mt-0.5"><MapPin size={10} />{baja.area || '—'}</div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{baja.fecha_baja ? new Date(baja.fecha_baja).toLocaleDateString('es-CO') : '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-semibold ${MOTIVO_COLORS[baja.motivo_baja || ''] || 'text-muted-foreground'}`}>
                        {MOTIVO_LABELS[baja.motivo_baja || ''] || baja.motivo_baja}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] font-semibold px-2 py-1 rounded-lg border ${DISPOSICION_COLORS[baja.disposicion || ''] || 'text-muted-foreground bg-secondary border-border'}`}>
                        {DISPOSICION_LABELS[baja.disposicion || ''] || baja.disposicion}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelected(baja)} title="Ver detalle"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                          <Archive size={14} />
                        </button>
                        <button onClick={() => handleReactivate(baja)} title="Reactivar equipo"
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-green-400 hover:bg-green-500/10 transition-colors">
                          <RotateCcw size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-xs text-muted-foreground">{filtered.length} registros · Página {page} de {totalPages}</span>
              <div className="flex gap-1">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">Anterior</button>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                  className="px-3 py-1.5 text-xs bg-secondary border border-border rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors">Siguiente</button>
              </div>
            </div>
          )}
        </div>

        {/* Detail Panel */}
        {selected && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/60" onClick={() => setSelected(null)} />
            <div className="relative w-full max-w-md bg-card border border-border rounded-2xl mx-4 shadow-2xl">
              <div className="flex items-center justify-between px-6 py-4 border-b border-border">
                <h3 className="text-sm font-semibold text-foreground">Detalle de Baja</h3>
                <button onClick={() => setSelected(null)} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"><X size={16} /></button>
              </div>
              <div className="p-6 space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  {[
                    ['Placa', selected.placa], ['Marca / Modelo', `${selected.brand} ${selected.model}`],
                    ['Serial', selected.serial], ['CPU', selected.cpu],
                    ['RAM', selected.ram], ['Disco', selected.storage],
                    ['S.O.', selected.os], ['Último Usuario', selected.last_user],
                    ['Área', selected.area], ['Ubicación', selected.location],
                    ['Fecha Baja', selected.fecha_baja], ['Técnico', selected.tecnico_responsable],
                    ['Motivo', MOTIVO_LABELS[selected.motivo_baja || ''] || selected.motivo_baja],
                    ['Disposición', DISPOSICION_LABELS[selected.disposicion || ''] || selected.disposicion],
                  ].map(([label, value]) => value ? (
                    <div key={label}>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
                      <p className="text-foreground font-medium">{value}</p>
                    </div>
                  ) : null)}
                </div>
                {selected.observaciones && (
                  <div className="bg-secondary/50 border border-border rounded-xl p-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Observaciones</p>
                    <p className="text-foreground">{selected.observaciones}</p>
                  </div>
                )}
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setSelected(null)}
                    className="flex-1 px-4 py-2 text-xs bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-lg transition-colors">Cerrar</button>
                  <button onClick={() => handleReactivate(selected)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs bg-green-500/10 border border-green-500/30 text-green-400 hover:bg-green-500/20 rounded-lg transition-colors">
                    <RotateCcw size={13} /> Reactivar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
