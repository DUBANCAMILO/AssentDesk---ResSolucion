'use client';

import React, { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import { assetService, type Asset, type AssetHistory } from '@/lib/services/assetService';
import { QRCodeSVG } from 'qrcode.react';
import AppImage from '@/components/ui/AppImage';
import { getAssetQrUrl } from '@/lib/qr';
import {
  Cpu, HardDrive, Network, MapPin, User, Wrench,
  Printer, Keyboard, Shield, Zap, Share2, CheckCircle, FileDown,
  Printer as PrintIcon, AlertTriangle, Clock, Package,
} from 'lucide-react';

const statusColors: Record<string, string> = {
  operational: 'bg-green-500/10 border-green-500/30 text-green-400',
  maintenance: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
  critical: 'bg-red-500/10 border-red-500/30 text-red-400',
  decommissioned: 'bg-gray-500/10 border-gray-500/30 text-gray-400',
};
const statusLabels: Record<string, string> = {
  operational: 'OPERATIVO',
  maintenance: 'MANTENIMIENTO',
  critical: 'CRÍTICO',
  decommissioned: 'DADO DE BAJA',
};
const historyColors: Record<string, string> = {
  assigned: 'text-blue-400 bg-blue-500/10',
  maintenance: 'text-amber-400 bg-amber-500/10',
  component_change: 'text-violet-400 bg-violet-500/10',
  status_change: 'text-red-400 bg-red-500/10',
  created: 'text-green-400 bg-green-500/10',
  updated: 'text-cyan-400 bg-cyan-500/10',
  baja: 'text-red-500 bg-red-500/10',
  reactivated: 'text-emerald-400 bg-emerald-500/10',
};

function InfoRow({ label, value, mono = false }: { label: string; value?: string | number | null; mono?: boolean }) {
  if (!value) return null;
  return (
    <div className="flex justify-between items-start gap-3 py-2 border-b border-white/10 last:border-0">
      <span className="text-xs text-gray-400 shrink-0">{label}</span>
      <span className={`text-xs text-white text-right font-medium ${mono ? 'font-mono' : ''}`}>{String(value)}</span>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 bg-white/5 border-b border-white/10">
        <span className="text-gray-400">{icon}</span>
        <span className="text-xs font-semibold text-gray-300 uppercase tracking-wider">{title}</span>
      </div>
      <div className="px-4 py-2">{children}</div>
    </div>
  );
}

async function getQRDataURL(value: string, size = 160): Promise<string> {
  try {
    const QRCode = (await import('qrcode')).default;
    return await QRCode.toDataURL(value, {
      width: size, margin: 1,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });
  } catch { return ''; }
}

export default function AssetPublicPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const [asset, setAsset] = useState<Asset | null>(null);
  const [history, setHistory] = useState<AssetHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [activeTab, setActiveTab] = useState<'specs' | 'assignment' | 'network' | 'history'>('specs');
  const [shareSuccess, setShareSuccess] = useState(false);

  useEffect(() => {
    const lookup = async () => {
      setLoading(true);
      const rawId = Array.isArray(params?.id) ? params.id[0] : params?.id;
      const placa = searchParams?.get('placa');
      const serial = searchParams?.get('serial');
      const tag = searchParams?.get('tag');

      let found: Asset | null = null;

      // Fast lookup by QR value; never load the whole inventory for one scan.
      if (placa) found = await assetService.getByIdentifier(placa);
      else if (serial) found = await assetService.getByIdentifier(serial);
      else if (tag) found = await assetService.getByIdentifier(tag);
      else if (rawId) found = await assetService.getByIdentifier(rawId);

      if (found) {
        // Show the asset immediately; history is secondary and must not block the QR view.
        setAsset(found);
        setLoading(false);
        assetService.getHistory(found.id).then(setHistory).catch(() => setHistory([]));
        return;
      }
      setNotFound(true);
      setLoading(false);
    };
    lookup();
  }, [params, searchParams]);

  const handleShare = async () => {
    if (!asset) return;
    const url = window.location.href;
    const text = `📋 ${asset.marca} ${asset.modelo}\nPlaca: ${asset.placa}\nEstado: ${statusLabels[asset.status || 'operational']}\n${url}`;
    if (navigator.share) {
      try { await navigator.share({ title: `Equipo ${asset.placa}`, text, url }); return; } catch { /* fallback */ }
    }
    try {
      await navigator.clipboard.writeText(url);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    } catch { alert(url); }
  };

  const handlePrintTicket = async () => {
    if (!asset) return;
    const qrValue = getAssetQrUrl(asset.id);
    const qrDataUrl = await getQRDataURL(qrValue, 100);
    const win = window.open('', '_blank', 'width=300,height=200');
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>
  @page { size: 46mm 58mm; margin: 0; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { width: 46mm; height: 58mm; overflow: hidden; font-family: 'Courier New', monospace; font-size: 7pt; color: #000; background: #fff; }
  .ticket { width: 46mm; height: 58mm; display: flex; flex-direction: column; align-items: stretch; padding: 2.2mm; gap: 1.6mm; background: linear-gradient(145deg,#ffffff 0%,#eef2ff 100%); }
  .qr-box { width: 23mm; height: 23mm; align-self: center; flex-shrink: 0; display: flex; align-items: center; justify-content: center; background:#fff; padding: 1mm; border-radius: 1.5mm; }
  .qr-box img { width: 21mm; height: 21mm; image-rendering: pixelated; }
  .info { flex: 1; display: flex; flex-direction: column; justify-content: flex-start; gap: 1.25mm; overflow: hidden; min-width: 0; border-top: 0.3pt solid #9ca3af; padding-top: 1.6mm; }
  .brand { font-size: 8.5pt; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .placa { font-size: 7.5pt; font-weight: bold; color: #1e3a8a; }
  .line { font-size: 6.2pt; color: #333; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .app-mark { display:flex; align-items:center; justify-content:center; gap:1.2mm; font-size:5.5pt; color:#334155; font-weight:bold; }
  .app-mark img { width:5mm; height:5mm; object-fit:contain; }
</style></head><body>
<div class="ticket">
  <div class="qr-box">${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR"/>` : '<div style="width:10mm;height:10mm;border:0.5pt solid #ccc;font-size:4pt;display:flex;align-items:center;justify-content:center;">QR</div>'}</div>
  <div class="info">
    <div class="brand">${(asset.marca || '') + ' ' + (asset.modelo || '')}</div>
    <div class="placa">${asset.placa || ''}</div>
    <div class="line">S/N: ${asset.serial || 'N/A'}</div>
    <div class="line">IP: ${asset.direccion_ip || 'N/A'}</div>
    <div class="line">${asset.usuario_responsable || ''}</div>
    <div class="line">${asset.ubicacion || asset.area || ''}</div>
  </div>
  <div class="app-mark"><img src="/assets/images/app_logo.png" alt="AssetDesk"/>AssetDesk</div>
</div>
<script>setTimeout(function(){ window.print(); window.close(); }, 500);</script>
</body></html>`);
    win.document.close();
  };

  const handleExportPDF = async () => {
    if (!asset) return;
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const margin = 14;
      const pageW = 210;
      const contentW = pageW - margin * 2;
      let y = margin;

      // ── Header band ──────────────────────────────────────────────────────
      doc.setFillColor(30, 30, 46);
      doc.rect(0, 0, pageW, 38, 'F');

      // QR code (top-right)
      const qrUrl = getAssetQrUrl(asset.id);
      const qrDataUrl = await getQRDataURL(qrUrl, 220);
      if (qrDataUrl) {
        doc.addImage(qrDataUrl, 'PNG', pageW - margin - 28, 5, 28, 28);
      }

      // Equipment photo (top-left)
      if (asset.foto_url) {
        try {
          const imgData = await fetch(asset.foto_url)
            .then(r => r.blob())
            .then(blob => new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.onerror = reject;
              reader.readAsDataURL(blob);
            }));
          doc.addImage(imgData, 'JPEG', margin, 5, 28, 28);
        } catch { /* CORS skip */ }
      }

      // Title in header
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(15);
      doc.setFont('helvetica', 'bold');
      doc.text(`${asset.marca || ''} ${asset.modelo || ''}`, margin + 32, 16);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(180, 180, 200);
      doc.text(`Placa: ${asset.placa || 'N/A'}   S/N: ${asset.serial || 'N/A'}`, margin + 32, 23);
      doc.text(`Sede: ${asset.sede || 'N/A'}   Área: ${asset.area || 'N/A'}`, margin + 32, 29);

      // Status badge
      const statusLabel = statusLabels[asset.status || 'operational'];
      const badgeColors: Record<string, [number, number, number]> = {
        operational: [34, 197, 94], maintenance: [245, 158, 11],
        critical: [239, 68, 68], decommissioned: [107, 114, 128],
      };
      const [r, g, b] = badgeColors[asset.status || 'operational'];
      doc.setFillColor(r, g, b);
      doc.roundedRect(margin + 32, 31, 28, 5, 1, 1, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text(statusLabel, margin + 46, 34.5, { align: 'center' });

      y = 44;
      doc.setTextColor(30, 30, 30);

      // ── Helper: draw a 2-column section ─────────────────────────────────
      const drawSection = (title: string, rows: [string, string][], colOffset = 0, colWidth = contentW) => {
        if (y > 265) { doc.addPage(); y = margin; }
        // Section header
        doc.setFillColor(245, 245, 250);
        doc.rect(margin + colOffset, y, colWidth, 7, 'F');
        doc.setDrawColor(220, 220, 230);
        doc.rect(margin + colOffset, y, colWidth, 7, 'S');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(80, 80, 100);
        doc.text(title.toUpperCase(), margin + colOffset + 3, y + 5);
        y += 8;

        const validRows = rows.filter(([, v]) => v && v !== 'N/A');
        validRows.forEach(([label, value], idx) => {
          if (y > 270) { doc.addPage(); y = margin; }
          const rowH = 6;
          if (idx % 2 === 0) {
            doc.setFillColor(252, 252, 255);
            doc.rect(margin + colOffset, y, colWidth, rowH, 'F');
          }
          doc.setDrawColor(235, 235, 240);
          doc.line(margin + colOffset, y + rowH, margin + colOffset + colWidth, y + rowH);
          doc.setFontSize(8);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(120, 120, 140);
          doc.text(label, margin + colOffset + 3, y + 4.2);
          doc.setTextColor(30, 30, 30);
          doc.setFont('helvetica', 'bold');
          const maxW = colWidth - 45;
          const truncated = doc.splitTextToSize(value, maxW)[0];
          doc.text(truncated, margin + colOffset + 42, y + 4.2);
          y += rowH;
        });
        y += 4;
      };

      // ── Two-column layout ────────────────────────────────────────────────
      const col1W = (contentW - 4) / 2;
      const col2W = (contentW - 4) / 2;
      const col2Offset = col1W + 4;

      // Save y before two-column sections
      const yBefore = y;

      // Left column: CPU & Memory
      drawSection('Procesador y Memoria', [
        ['CPU', [asset.procesador_marca, asset.procesador_tipo, asset.procesador_velocidad].filter(Boolean).join(' ') || 'N/A'],
        ['RAM', [asset.ram_capacidad, asset.ram_tipo].filter(Boolean).join(' ') || 'N/A'],
        ['Disco', [asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' ') || 'N/A'],
        ['S.O.', asset.sistema_operativo || 'N/A'],
        ['Arquitectura', asset.arquitectura || 'N/A'],
        ['Office', asset.office_version || 'N/A'],
        ['Antivirus', asset.antivirus || 'N/A'],
        ['GPU', [asset.gpu_marca, asset.gpu_modelo, asset.gpu_vram].filter(Boolean).join(' ') || 'N/A'],
      ], 0, col1W);

      const yAfterLeft = y;
      y = yBefore;

      // Right column: Assignment
      drawSection('Asignación', [
        ['Usuario', asset.usuario_responsable || 'N/A'],
        ['Área', asset.area || 'N/A'],
        ['Ubicación', asset.ubicacion || 'N/A'],
        ['Sede', asset.sede || 'N/A'],
        ['Técnico', asset.tecnico_instalador || 'N/A'],
        ['F. Asignación', asset.fecha_asignacion || 'N/A'],
        ['Garantía', asset.garantia_vencimiento || 'N/A'],
        ['Proveedor', asset.proveedor || 'N/A'],
      ], col2Offset, col2W);

      y = Math.max(yAfterLeft, y);

      // ── Full-width sections ──────────────────────────────────────────────
      drawSection('Red', [
        ['Hostname', asset.nombre_equipo || 'N/A'],
        ['Dirección IP', asset.direccion_ip || 'N/A'],
        ['MAC Address', asset.mac_address || 'N/A'],
        ['Subred', asset.subred || 'N/A'],
        ['Gateway', asset.gateway || 'N/A'],
        ['DNS Primario', asset.dns_primario || 'N/A'],
        ['DNS Secundario', asset.dns_secundario || 'N/A'],
        ['Puerto Switch', asset.puerto_switch || 'N/A'],
      ]);

      drawSection('Periféricos', [
        ['Monitor', [asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' ') || 'N/A'],
        ['Teclado', asset.teclado_marca || 'N/A'],
        ['Mouse', asset.mouse_marca || 'N/A'],
        ['Web Cam', asset.web_cam || 'N/A'],
        ['Impresora', [asset.impresora_marca, asset.impresora_modelo].filter(Boolean).join(' ') || 'N/A'],
        ['S/N Impresora', asset.impresora_serial || 'N/A'],
      ]);

      // ── Observations ─────────────────────────────────────────────────────
      if (asset.observaciones) {
        if (y > 255) { doc.addPage(); y = margin; }
        doc.setFillColor(255, 253, 230);
        doc.setDrawColor(255, 224, 130);
        const obsLines = doc.splitTextToSize(asset.observaciones, contentW - 8);
        const obsH = obsLines.length * 5 + 12;
        doc.roundedRect(margin, y, contentW, obsH, 2, 2, 'FD');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(180, 100, 0);
        doc.text('OBSERVACIONES', margin + 4, y + 6);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(80, 60, 0);
        doc.text(obsLines, margin + 4, y + 12);
        y += obsH + 4;
      }

      if (asset.recomendaciones) {
        if (y > 255) { doc.addPage(); y = margin; }
        doc.setFillColor(230, 245, 255);
        doc.setDrawColor(130, 200, 255);
        const recLines = doc.splitTextToSize(asset.recomendaciones, contentW - 8);
        const recH = recLines.length * 5 + 12;
        doc.roundedRect(margin, y, contentW, recH, 2, 2, 'FD');
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0, 80, 160);
        doc.text('RECOMENDACIONES', margin + 4, y + 6);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(0, 50, 100);
        doc.text(recLines, margin + 4, y + 12);
        y += recH + 4;
      }

      // ── History (last 5 events) ──────────────────────────────────────────
      if (history.length > 0) {
        if (y > 240) { doc.addPage(); y = margin; }
        drawSection('Historial Reciente', history.slice(0, 5).map(ev => [
          ev.event_type?.replace('_', ' ').toUpperCase(),
          `${ev.description} — ${ev.by_user || ''} (${ev.created_at ? new Date(ev.created_at).toLocaleDateString('es-CO') : ''})`,
        ]));
      }

      // ── Footer ───────────────────────────────────────────────────────────
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFillColor(245, 245, 250);
        doc.rect(0, 285, pageW, 12, 'F');
        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(140, 140, 160);
        doc.text('AssetDesk — Sistema de Gestión de Activos', margin, 291);
        doc.text(`Generado: ${new Date().toLocaleDateString('es-CO')}`, pageW / 2, 291, { align: 'center' });
        doc.text(`Página ${i} de ${totalPages}`, pageW - margin, 291, { align: 'right' });
      }

      doc.save(`ficha_${asset.placa || asset.id || 'activo'}.pdf`);
    } catch (err) {
      console.error('PDF error:', err);
      alert('Error al generar PDF.');
    }
  };

  // ── Loading ──────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400 text-sm">Cargando ficha técnica...</p>
        </div>
      </div>
    );
  }

  // ── Not found ────────────────────────────────────────────────────────────
  if (notFound || !asset) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <AlertTriangle size={28} className="text-red-400" />
          </div>
          <h1 className="text-white text-xl font-bold mb-2">Equipo no encontrado</h1>
          <p className="text-gray-400 text-sm">El código QR escaneado no corresponde a ningún activo registrado en el sistema.</p>
        </div>
      </div>
    );
  }

  const qrUrl = asset ? getAssetQrUrl(asset.id) : '';

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Top bar */}
      <div className="bg-gray-900 border-b border-white/10 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <Package size={16} className="text-indigo-400" />
          <span className="text-sm font-semibold text-white">AssetDesk</span>
          <span className="text-gray-500 text-xs">/ Ficha Técnica</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className={`p-2 rounded-lg transition-colors ${shareSuccess ? 'text-green-400 bg-green-500/10' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
            title="Compartir">
            {shareSuccess ? <CheckCircle size={16} /> : <Share2 size={16} />}
          </button>
          <button
            onClick={handlePrintTicket}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Imprimir Ticket">
            <PrintIcon size={16} />
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs font-medium rounded-lg hover:bg-indigo-500/30 transition-colors">
            <FileDown size={13} /> PDF
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">
        {/* Hero card */}
        <div className="bg-gradient-to-br from-indigo-900/40 to-gray-900 border border-indigo-500/20 rounded-2xl overflow-hidden">
          {asset.foto_url && (
            <AppImage src={asset.foto_url} alt={`${asset.marca} ${asset.modelo}`} width={960} height={384} unoptimized className="w-full h-48 object-cover" />
          )}
          <div className="p-5 flex gap-4 items-start">
            <div className="bg-white p-2 rounded-xl shrink-0">
              <QRCodeSVG
                value={qrUrl || asset.placa || asset.id}
                size={80}
                level="M"
                includeMargin={false}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="font-mono text-xs text-indigo-300 font-bold">{asset.placa || asset.tag}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${statusColors[asset.status || 'operational']}`}>
                  {statusLabels[asset.status || 'operational']}
                </span>
              </div>
              <h1 className="text-xl font-bold text-white leading-tight">{asset.marca} {asset.modelo}</h1>
              <p className="text-sm text-gray-400 mt-1">S/N: <span className="font-mono">{asset.serial || 'N/A'}</span></p>
              {asset.tipo_equipo && <p className="text-xs text-gray-500 mt-0.5">{asset.tipo_equipo}</p>}
              {asset.sede && <p className="text-xs text-gray-500">{asset.sede}</p>}
            </div>
          </div>
        </div>

        {/* Quick info pills */}
        <div className="grid grid-cols-2 gap-3">
          {asset.usuario_responsable && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-2">
              <User size={14} className="text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-[10px] text-gray-500 uppercase tracking-wide">Usuario</p>
                <p className="text-sm font-medium text-white truncate">{asset.usuario_responsable}</p>
              </div>
            </div>
          )}
          {asset.area && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-2">
              <MapPin size={14} className="text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-[10px] text-gray-500 uppercase tracking-wide">Área</p>
                <p className="text-sm font-medium text-white truncate">{asset.area}</p>
              </div>
            </div>
          )}
          {asset.direccion_ip && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-2">
              <Network size={14} className="text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-[10px] text-gray-500 uppercase tracking-wide">IP</p>
                <p className="text-sm font-mono font-medium text-white truncate">{asset.direccion_ip}</p>
              </div>
            </div>
          )}
          {asset.ubicacion && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-2">
              <MapPin size={14} className="text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-[10px] text-gray-500 uppercase tracking-wide">Ubicación</p>
                <p className="text-sm font-medium text-white truncate">{asset.ubicacion}</p>
              </div>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex bg-white/5 border border-white/10 rounded-xl p-1 gap-1 overflow-x-auto">
          {([
            { key: 'specs', label: 'Especificaciones' },
            { key: 'assignment', label: 'Asignación' },
            { key: 'network', label: 'Red' },
            { key: 'history', label: 'Historial' },
          ] as const).map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex-1 px-3 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                activeTab === tab.key ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'
              }`}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="space-y-3">
          {activeTab === 'specs' && (
            <>
              <Section title="Procesador" icon={<Cpu size={13} />}>
                <InfoRow label="Marca" value={asset.procesador_marca} />
                <InfoRow label="Tipo / Modelo" value={asset.procesador_tipo} />
                <InfoRow label="Velocidad" value={asset.procesador_velocidad} />
              </Section>
              <Section title="Memoria y Almacenamiento" icon={<HardDrive size={13} />}>
                <InfoRow label="RAM" value={asset.ram_capacidad} />
                <InfoRow label="Tipo RAM" value={asset.ram_tipo} />
                <InfoRow label="Almacenamiento" value={asset.disco_capacidad} />
                <InfoRow label="Tecnología Disco" value={asset.disco_tecnologia} />
              </Section>
              {(asset.gpu_marca || asset.gpu_modelo) && (
                <Section title="Tarjeta Gráfica" icon={<Zap size={13} />}>
                  <InfoRow label="Marca GPU" value={asset.gpu_marca} />
                  <InfoRow label="Modelo GPU" value={asset.gpu_modelo} />
                  <InfoRow label="VRAM" value={asset.gpu_vram} />
                </Section>
              )}
              <Section title="Sistema Operativo" icon={<Shield size={13} />}>
                <InfoRow label="S.O." value={asset.sistema_operativo} />
                <InfoRow label="Arquitectura" value={asset.arquitectura} />
                <InfoRow label="Office / Suite" value={asset.office_version} />
                <InfoRow label="Antivirus" value={asset.antivirus} />
                {asset.software_adicional && <InfoRow label="Software Adicional" value={asset.software_adicional} />}
              </Section>
              <Section title="Periféricos" icon={<Keyboard size={13} />}>
                <InfoRow label="Monitor" value={[asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' ')} />
                <InfoRow label="Teclado" value={asset.teclado_marca} />
                <InfoRow label="Mouse" value={asset.mouse_marca} />
                <InfoRow label="Web Cam" value={asset.web_cam} />
              </Section>
              {(asset.impresora_marca || asset.impresora_modelo) && (
                <Section title="Impresora" icon={<Printer size={13} />}>
                  <InfoRow label="Marca" value={asset.impresora_marca} />
                  <InfoRow label="Modelo" value={asset.impresora_modelo} />
                  <InfoRow label="Tipo" value={asset.impresora_tipo} />
                  <InfoRow label="Serial" value={asset.impresora_serial} />
                </Section>
              )}
              {asset.observaciones && (
                <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-4">
                  <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">Observaciones</p>
                  <p className="text-sm text-gray-300 leading-relaxed">{asset.observaciones}</p>
                </div>
              )}
            </>
          )}

          {activeTab === 'assignment' && (
            <>
              <Section title="Ubicación Actual" icon={<MapPin size={13} />}>
                <InfoRow label="Ubicación" value={asset.ubicacion} />
                <InfoRow label="Área / Unidad" value={asset.area} />
                <InfoRow label="Sede" value={asset.sede} />
              </Section>
              <Section title="Responsable" icon={<User size={13} />}>
                <InfoRow label="Usuario Asignado" value={asset.usuario_responsable} />
                <InfoRow label="Fecha de Asignación" value={asset.fecha_asignacion} />
              </Section>
              <Section title="Instalación y Compra" icon={<Wrench size={13} />}>
                <InfoRow label="Técnico Instalador" value={asset.tecnico_instalador} />
                <InfoRow label="Fecha Compra" value={asset.fecha_compra} />
                <InfoRow label="Proveedor" value={asset.proveedor} />
                <InfoRow label="Garantía hasta" value={asset.garantia_vencimiento} />
                {asset.valor_compra && <InfoRow label="Valor Compra" value={`$${asset.valor_compra.toLocaleString('es-CO')}`} />}
              </Section>
            </>
          )}

          {activeTab === 'network' && (
            <Section title="Configuración de Red" icon={<Network size={13} />}>
              <InfoRow label="Hostname" value={asset.nombre_equipo} mono />
              <InfoRow label="Dirección IP" value={asset.direccion_ip} mono />
              <InfoRow label="Máscara de Subred" value={asset.subred || '255.255.255.0'} mono />
              <InfoRow label="Puerta de Enlace" value={asset.gateway || '192.168.1.1'} mono />
              <InfoRow label="DNS Primario" value={asset.dns_primario} mono />
              <InfoRow label="DNS Secundario" value={asset.dns_secundario} mono />
              <InfoRow label="MAC Address" value={asset.mac_address} mono />
              <InfoRow label="Puerto Switch" value={asset.puerto_switch} mono />
            </Section>
          )}

          {activeTab === 'history' && (
            <div className="space-y-2">
              {history.length === 0 ? (
                <div className="text-center py-10 text-gray-500 text-sm">Sin historial registrado</div>
              ) : history.map(ev => (
                <div key={ev.id} className="flex gap-3 p-3 bg-white/5 border border-white/10 rounded-xl">
                  <div className={`text-[9px] font-bold px-2 py-1 rounded-lg shrink-0 ${historyColors[ev.event_type] || 'text-gray-400 bg-gray-500/10'}`}>
                    {ev.event_type?.replace('_', ' ').toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-white">{ev.description}</p>
                    <p className="text-[10px] text-gray-500 mt-0.5 flex items-center gap-1">
                      <Clock size={9} />
                      {ev.by_user} · {ev.created_at ? new Date(ev.created_at).toLocaleDateString('es-CO') : ''}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bottom padding */}
        <div className="h-8" />
      </div>
    </div>
  );
}
