'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Download, FileText, Printer, RefreshCw, Search } from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { assetService, transferService, type Asset, type TransferFormInput } from '@/lib/services/assetService';
import { downloadTablePdf } from '@/lib/pdfReport';

const inputCls = 'w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary';
const labelCls = 'block text-[10px] text-muted-foreground mb-1 uppercase tracking-wide';

type TransferRecord = TransferFormInput & {
  id: string;
  traslado_no?: string;
  status?: string;
  created_at?: string;
};

const emptyForm: TransferFormInput = {
  fecha: new Date().toISOString().slice(0, 10),
  servicio_origen: '',
  servicio_destino: '',
  motivo: '',
  area_realiza: 'Sistemas',
  area_otro: '',
  nombre_bien: '',
  placa_inventario: '',
  cantidad: 1,
  marca: '',
  modelo: '',
  serial: '',
  estado: 'bueno',
  vobo_subgerencia: false,
  observaciones: '',
};

function transferRows(item: TransferRecord): string[][] {
  return [
    ['Número', item.traslado_no || item.id],
    ['Fecha', item.fecha],
    ['Servicio origen', item.servicio_origen],
    ['Servicio destino', item.servicio_destino],
    ['Área que realiza', item.area_realiza === 'Otro' ? item.area_otro || 'Otro' : item.area_realiza],
    ['Motivo', item.motivo || 'No especificado'],
    ['Bien', item.nombre_bien],
    ['Placa', item.placa_inventario || 'N/A'],
    ['Estado', item.estado || 'N/A'],
    ['Marca / modelo', `${item.marca || ''} ${item.modelo || ''}`.trim()],
    ['Serial', item.serial || 'N/A'],
    ['Observaciones', item.observaciones || 'Sin observaciones'],
  ];
}

export default function TrasladosPage() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [transfers, setTransfers] = useState<TransferRecord[]>([]);
  const [assetSearch, setAssetSearch] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [saving, setSaving] = useState(false);
  const [loadingTransfers, setLoadingTransfers] = useState(true);
  const [message, setMessage] = useState('');
  const [form, setForm] = useState<TransferFormInput>({ ...emptyForm });

  const loadTransfers = async () => {
    setLoadingTransfers(true);
    const data = await transferService.getAll();
    setTransfers(data as TransferRecord[]);
    setLoadingTransfers(false);
  };

  useEffect(() => {
    assetService.getAll().then(setAssets).catch(() => setAssets([]));
    loadTransfers();
  }, []);

  const assetOptions = useMemo(() => {
    const q = assetSearch.toLowerCase();
    return assets
      .filter((a) => !q || `${a.placa} ${a.marca} ${a.modelo} ${a.serial} ${a.direccion_ip}`.toLowerCase().includes(q))
      .slice(0, 8);
  }, [assets, assetSearch]);

  const selectAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setForm((prev) => ({
      ...prev,
      asset_id: asset.id,
      nombre_bien: `${asset.marca || ''} ${asset.modelo || ''}`.trim(),
      placa_inventario: asset.placa || '',
      marca: asset.marca || '',
      modelo: asset.modelo || '',
      serial: asset.serial || '',
      estado: 'bueno',
    }));
    setAssetSearch(asset.placa || '');
  };

  const update = (key: keyof TransferFormInput, value: string | number | boolean) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleDownload = async (item: TransferRecord) => {
    try {
      await downloadTablePdf(
        `Formato de traslado ${item.traslado_no || item.id}`,
        ['Campo', 'Información'],
        transferRows(item),
        `traslado_${item.traslado_no || item.id}`,
      );
    } catch (error) {
      console.error('Error descargando traslado:', error);
      setMessage('No se pudo descargar el archivo del traslado.');
    }
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setMessage('');
    try {
      const result = await transferService.create(form);
      if (!result) {
        setMessage('No se pudo guardar. Verifica la tabla de traslados y los campos obligatorios.');
        return;
      }
      const saved = result as TransferRecord;
      setMessage(`Traslado ${saved.traslado_no || saved.id} generado correctamente.`);
      await handleDownload(saved);
      await loadTransfers();
    } catch (error) {
      console.error('Error generando traslado:', error);
      setMessage(error instanceof Error ? error.message : 'Ocurrió un error al generar el traslado.');
    } finally {
      setSaving(false);
    }
  };

  const startNew = () => {
    setSelectedAsset(null);
    setAssetSearch('');
    setForm({ ...emptyForm, fecha: new Date().toISOString().slice(0, 10) });
    setMessage('');
  };

  return (
    <AppLayout>
      <Topbar title="Traslados Internos" subtitle="Formato institucional y trazabilidad del activo" />
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
        <form onSubmit={submit} className="max-w-5xl mx-auto space-y-5">
          <div className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <FileText size={16} className="text-primary" />
              <h2 className="text-sm font-semibold">Seleccionar equipo</h2>
            </div>
            <div className="relative">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={assetSearch} onChange={(event) => setAssetSearch(event.target.value)} placeholder="Buscar por placa, IP, marca, modelo o serial" className={`${inputCls} pl-8`} />
              {assetOptions.length > 0 && assetSearch && !selectedAsset && (
                <div className="absolute z-20 left-0 right-0 mt-1 bg-card border border-border rounded-lg overflow-hidden">
                  {assetOptions.map((asset) => (
                    <button type="button" key={asset.id} onClick={() => selectAsset(asset)} className="w-full text-left px-3 py-2 text-xs hover:bg-secondary border-b border-border last:border-0">
                      <strong className="text-primary font-mono">{asset.placa}</strong> · {asset.marca} {asset.modelo} · S/N {asset.serial || 'N/A'} · IP {asset.direccion_ip || 'N/A'}
                    </button>
                  ))}
                </div>
              )}
            </div>
            {selectedAsset && (
              <div className="mt-3 flex items-center justify-between bg-primary/5 border border-primary/20 rounded-lg px-3 py-2 text-xs">
                <span><strong>{selectedAsset.placa}</strong> · {selectedAsset.marca} {selectedAsset.modelo}</span>
                <button type="button" onClick={startNew} className="text-muted-foreground hover:text-foreground">Cambiar</button>
              </div>
            )}
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div><label className={labelCls}>Fecha</label><input type="date" value={form.fecha} onChange={(event) => update('fecha', event.target.value)} className={inputCls} required /></div>
              <div><label className={labelCls}>Servicio origen *</label><input value={form.servicio_origen} onChange={(event) => update('servicio_origen', event.target.value)} className={inputCls} required /></div>
              <div><label className={labelCls}>Servicio destino *</label><input value={form.servicio_destino} onChange={(event) => update('servicio_destino', event.target.value)} className={inputCls} required /></div>
              <div><label className={labelCls}>Área que realiza</label><select value={form.area_realiza} onChange={(event) => update('area_realiza', event.target.value)} className={inputCls}><option>Mantenimiento</option><option>Mantenimiento biomédico</option><option>Sistemas</option><option>Subgerencia</option><option>Almacén</option><option>Otro</option></select></div>
              <div><label className={labelCls}>Motivo</label><input value={form.motivo} onChange={(event) => update('motivo', event.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Cantidad</label><input type="number" min={1} value={form.cantidad} onChange={(event) => update('cantidad', Number(event.target.value))} className={inputCls} /></div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="text-sm font-semibold mb-4">Descripción del bien</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div><label className={labelCls}>Nombre del bien *</label><input value={form.nombre_bien} onChange={(event) => update('nombre_bien', event.target.value)} className={inputCls} required /></div>
              <div><label className={labelCls}>Placa inventario</label><input value={form.placa_inventario || ''} onChange={(event) => update('placa_inventario', event.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Estado</label><select value={form.estado} onChange={(event) => update('estado', event.target.value)} className={inputCls}><option value="bueno">Bueno</option><option value="regular">Regular</option><option value="malo">Malo</option></select></div>
              <div><label className={labelCls}>Marca</label><input value={form.marca || ''} onChange={(event) => update('marca', event.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Modelo</label><input value={form.modelo || ''} onChange={(event) => update('modelo', event.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Serial</label><input value={form.serial || ''} onChange={(event) => update('serial', event.target.value)} className={inputCls} /></div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <label className={labelCls}>Observaciones</label>
            <textarea value={form.observaciones || ''} onChange={(event) => update('observaciones', event.target.value)} rows={3} className={`${inputCls} resize-none`} />
            <label className="flex items-center gap-2 mt-4 text-xs text-muted-foreground"><input type="checkbox" checked={form.vobo_subgerencia} onChange={(event) => update('vobo_subgerencia', event.target.checked)} className="accent-primary" /> Visto bueno de Subgerencia</label>
          </div>

          {message && <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-primary text-xs">{message}</div>}
          <div className="flex justify-end"><button type="submit" disabled={saving || !form.nombre_bien || !form.servicio_origen || !form.servicio_destino} className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold bg-primary text-primary-foreground rounded-lg disabled:opacity-50"><Printer size={14} />{saving ? 'Guardando...' : 'Guardar y descargar formato'}</button></div>
        </form>

        <section className="max-w-5xl mx-auto bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-border">
            <div><h2 className="text-sm font-semibold">Traslados generados</h2><p className="text-xs text-muted-foreground">Cada registro queda disponible para descargar nuevamente.</p></div>
            <button type="button" onClick={loadTransfers} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary"><RefreshCw size={14} /></button>
          </div>
          {loadingTransfers ? <div className="p-8 text-center text-xs text-muted-foreground">Cargando traslados...</div> : transfers.length === 0 ? <div className="p-8 text-center text-xs text-muted-foreground">Todavía no hay traslados guardados.</div> : (
            <div className="divide-y divide-border/50">
              {transfers.map((item) => (
                <div key={item.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                  <div className="flex-1 min-w-[220px]"><p className="text-xs font-semibold text-foreground">{item.traslado_no || item.id}</p><p className="text-[11px] text-muted-foreground">{item.placa_inventario || 'Sin placa'} · {item.nombre_bien} · {item.fecha}</p></div>
                  <span className="text-[10px] px-2 py-1 rounded border border-border text-muted-foreground">{item.status || 'completado'}</span>
                  <button type="button" onClick={() => handleDownload(item)} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-primary text-xs"><Download size={13} /> Descargar</button>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </AppLayout>
  );
}
