'use client';

import React, { Suspense, useState, useEffect, useRef, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { QrCode, Search, AlertTriangle, CheckCircle, Wrench, Camera, X, RefreshCw, Zap, Users, Wifi, WifiOff, UserCheck, Share2, Download, FileDown, FileSpreadsheet, ShieldCheck, ChevronDown, ChevronUp,  } from 'lucide-react';
import { assetService, type Asset } from '@/lib/services/assetService';
import { getAssetQrUrl } from '@/lib/qr';
import { createClient } from '@/lib/supabase/client';
import { QRCodeSVG } from 'qrcode.react';
import AppImage from '@/components/ui/AppImage';

type ScanState = 'idle' | 'scanning' | 'found' | 'not_found';

interface Technician {
  id: string;
  name: string;
  status: string;
  current_location?: string;
  last_seen?: string;
  avatar_color?: string;
}

const statusColors = {
  operational: 'bg-green-500/10 border-green-500/30 text-green-400',
  maintenance: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
  critical: 'bg-red-500/10 border-red-500/30 text-red-400',
  decommissioned: 'bg-gray-500/10 border-gray-500/30 text-gray-400',
};
const statusLabels: Record<string, string> = {
  operational: 'OPERATIVO', maintenance: 'MANTENIMIENTO',
  critical: 'CRÍTICO', decommissioned: 'BAJA',
};
const statusIcons: Record<string, React.ReactNode> = {
  operational: <CheckCircle size={14} className="text-green-400" />,
  maintenance: <Wrench size={14} className="text-amber-400" />,
  critical: <AlertTriangle size={14} className="text-red-400" />,
  decommissioned: <X size={14} className="text-gray-400" />,
};

const techColors = ['bg-blue-500', 'bg-violet-500', 'bg-emerald-500', 'bg-amber-500', 'bg-rose-500', 'bg-cyan-500'];

const CACHE_KEY = 'assetdesk_field_cache';

function InfoCard({ label, value, mono = false }: { label: string; value?: string | null; mono?: boolean }) {
  if (!value) return null;
  return (
    <div className="bg-secondary/50 border border-border/60 rounded-xl p-3">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
      <p className={`text-sm font-semibold text-foreground break-all ${mono ? 'font-mono' : ''}`}>{value}</p>
    </div>
  );
}

function TechnicianPageContent() {
  const searchParams = useSearchParams();
  const [scanState, setScanState] = useState<ScanState>('idle');
  const [searchQuery, setSearchQuery] = useState('');
  const [asset, setAsset] = useState<Asset | null>(null);
  const [recentAssets, setRecentAssets] = useState<Asset[]>([]);
  const [loadingRecent, setLoadingRecent] = useState(true);
  const [cameraActive, setCameraActive] = useState(false);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [realtimeConnected, setRealtimeConnected] = useState(false);
  const [qrDecoding, setQrDecoding] = useState(false);
  const [lastDecodedQR, setLastDecodedQR] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(true);
  const [pendingSync, setPendingSync] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [showExportPanel, setShowExportPanel] = useState(false);
  const [showCompliancePanel, setShowCompliancePanel] = useState(false);
  const [exportLoading, setExportLoading] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Offline cache helpers ────────────────────────────────────────────────
  const saveToCache = useCallback((assets: Asset[]) => {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), assets }));
    } catch { /* storage full */ }
  }, []);

  const loadFromCache = useCallback((): Asset[] => {
    try {
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return parsed.assets || [];
    } catch { return []; }
  }, []);

  // ── Online / offline detection + SW sync relay ──────────────────────────
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setPendingSync(true);
    };
    const handleOffline = () => setIsOnline(false);
    // Listen for service worker sync trigger (fired when connectivity restored)
    const handleSwSync = () => {
      setIsOnline(true);
      setPendingSync(true);
    };
    setIsOnline(navigator.onLine);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('assetdesk:sync', handleSwSync);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('assetdesk:sync', handleSwSync);
    };
  }, []);

  // ── Load priority assets (with offline fallback) ─────────────────────────
  const loadPriorityAssets = useCallback(async () => {
    setLoadingRecent(true);
    if (!navigator.onLine) {
      const cached = loadFromCache();
      const priority = cached.filter(a => a.status === 'critical' || a.status === 'maintenance').slice(0, 6);
      setRecentAssets(priority);
      setLoadingRecent(false);
      return;
    }
    try {
      const data = await assetService.getAll();
      saveToCache(data);
      const priority = data.filter(a => a.status === 'critical' || a.status === 'maintenance').slice(0, 6);
      setRecentAssets(priority);
    } catch {
      const cached = loadFromCache();
      const priority = cached.filter(a => a.status === 'critical' || a.status === 'maintenance').slice(0, 6);
      setRecentAssets(priority);
    } finally {
      setLoadingRecent(false);
    }
  }, [loadFromCache, saveToCache]);

  useEffect(() => {
    loadPriorityAssets();
  }, [loadPriorityAssets]);

  // ── Sync when back online ────────────────────────────────────────────────
  useEffect(() => {
    if (pendingSync && isOnline) {
      setPendingSync(false);
      loadPriorityAssets();
    }
  }, [pendingSync, isOnline, loadPriorityAssets]);

  // ── Load technicians from Supabase ───────────────────────────────────────
  const loadTechnicians = useCallback(async () => {
    if (!navigator.onLine) return;
    const supabase = createClient();
    const { data } = await supabase.from('technicians').select('*').order('name');
    if (data) {
      setTechnicians(data.map((t, i) => ({ ...t, avatar_color: techColors[i % techColors.length] })));
    }
  }, []);

  // ── Supabase Realtime — live technician sync ─────────────────────────────
  useEffect(() => {
    loadTechnicians();
    if (!navigator.onLine) return;
    const supabase = createClient();
    const channel = supabase
      .channel('technicians-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'technicians' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setTechnicians(prev => [...prev, { ...(payload.new as Technician), avatar_color: techColors[prev.length % techColors.length] }]);
        } else if (payload.eventType === 'UPDATE') {
          setTechnicians(prev => prev.map((t, i) =>
            t.id === payload.new.id ? { ...(payload.new as Technician), avatar_color: techColors[i % techColors.length] } : t
          ));
        } else if (payload.eventType === 'DELETE') {
          setTechnicians(prev => prev.filter(t => t.id !== payload.old.id));
        }
      })
      .subscribe((status) => setRealtimeConnected(status === 'SUBSCRIBED'));
    return () => { supabase.removeChannel(channel); };
  }, [loadTechnicians]);

  const stopCamera = useCallback(() => {
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
    setQrDecoding(false);
  }, []);

  useEffect(() => {
    if (!cameraActive || !videoRef.current || !streamRef.current) return;
    const video = videoRef.current;
    video.srcObject = streamRef.current;
    video.play().catch(() => setCameraError('La cámara se abrió, pero el navegador bloqueó la reproducción. Toca Activar Escáner otra vez.'));
  }, [cameraActive]);

  useEffect(() => { return () => { stopCamera(); }; }, [stopCamera]);

  // ── jsQR auto-decode loop ────────────────────────────────────────────────
  const startQRDecodeLoop = useCallback(async () => {
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    const jsQR = (await import('jsqr')).default;
    scanIntervalRef.current = setInterval(async () => {
      if (!videoRef.current || !canvasRef.current) return;
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video.readyState !== video.HAVE_ENOUGH_DATA) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      try {
        const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'dontInvert' });
        if (code && code.data && code.data !== lastDecodedQR) {
          setLastDecodedQR(code.data);
          setQrDecoding(false);
          const qrValue = code.data.trim();
          setScanState('scanning');

          // If QR encodes a full URL pointing to /asset/..., navigate directly
          try {
            const url = new URL(qrValue);
            const assetMatch = url.pathname.match(/^\/asset\/(.+)$/);
            if (assetMatch) {
              stopCamera();
              // Keep the current host when a printed QR contains localhost.
              window.location.href = `/asset/${decodeURIComponent(assetMatch[1])}`;
              return;
            }
          } catch { /* not a URL, treat as placa/serial/tag */ }

          // Search in cache first if offline
          let found: Asset | null = null;
          if (!navigator.onLine) {
            const cached = loadFromCache();
            found = cached.find(a =>
              a.placa === qrValue || a.serial === qrValue || a.id === qrValue ||
              a.tag === qrValue
            ) || null;
          } else {
            found = await assetService.getByIdentifier(qrValue);
          }

          if (found) {
            setAsset(found);
            setScanState('found');
            stopCamera();
          } else {
            setSearchQuery(qrValue);
            setScanState('not_found');
            stopCamera();
          }
        }
      } catch { /* jsqr not available */ }
    }, 300);
  }, [lastDecodedQR, stopCamera, loadFromCache]);

  const startCamera = async () => {
    setCameraError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('Este navegador no permite cámara. Usa HTTPS, localhost o la aplicación Android.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      // The video element is rendered only after cameraActive changes.
      setCameraActive(true);
      setQrDecoding(true);
      setScanState('scanning');
      setTimeout(() => { void startQRDecodeLoop(); }, 250);
    } catch (error) {
      const name = (error as DOMException)?.name;
      setCameraError(name === 'NotAllowedError'
        ? 'Permiso de cámara bloqueado. Pulsa Permitir cuando aparezca el aviso o habilítalo en los permisos del navegador.'
        : 'No se pudo iniciar la cámara. Verifica que otra aplicación no la esté usando.');
      setCameraActive(false);
      setQrDecoding(false);
    }
  };

  useEffect(() => {
    if (searchParams.get('scan') === '1' && !cameraActive) {
      void startCamera();
    }
    // The query flag intentionally starts the camera once when entering from the floating scanner.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const handleManualSearch = async () => {
    if (!searchQuery.trim()) return;
    setScanState('scanning');
    let found: Asset | null = null;
    if (!navigator.onLine) {
      const cached = loadFromCache();
      found = cached.find(a =>
        a.placa === searchQuery.trim() || a.serial === searchQuery.trim() ||
        (a.nombre_equipo || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (a.usuario_responsable || '').toLowerCase().includes(searchQuery.toLowerCase())
      ) || null;
    } else {
      found = await assetService.getByIdentifier(searchQuery.trim());
      if (!found) {
        const all = await assetService.getAll();
        found = all.find(a =>
          a.serial === searchQuery.trim() ||
          (a.nombre_equipo || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
          (a.usuario_responsable || '').toLowerCase().includes(searchQuery.toLowerCase())
        ) || null;
      }
    }
    if (found) { setAsset(found); setScanState('found'); }
    else setScanState('not_found');
  };

  const handleSelectAsset = (a: Asset) => {
    setAsset(a);
    setScanState('found');
    stopCamera();
  };

  const handleReset = () => {
    setAsset(null);
    setScanState('idle');
    setSearchQuery('');
    setLastDecodedQR(null);
    stopCamera();
  };

  // ── Share asset info ─────────────────────────────────────────────────────
  const handleShare = async (a: Asset) => {
    const text = [
      `📋 ${a.marca || ''} ${a.modelo || ''}`,
      `Placa: ${a.placa || 'N/A'}`,
      `S/N: ${a.serial || 'N/A'}`,
      `Estado: ${statusLabels[a.status || 'operational']}`,
      a.usuario_responsable ? `Usuario: ${a.usuario_responsable}` : '',
      a.area ? `Área: ${a.area}` : '',
      a.ubicacion ? `Ubicación: ${a.ubicacion}` : '',
      a.direccion_ip ? `IP: ${a.direccion_ip}` : '',
    ].filter(Boolean).join('\n');

    if (navigator.share) {
      try {
        await navigator.share({ title: `Equipo ${a.placa}`, text });
        return;
      } catch { /* fallback */ }
    }
    try {
      await navigator.clipboard.writeText(text);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    } catch {
      alert(text);
    }
  };

  // ── Export helpers ───────────────────────────────────────────────────────
  const handleExportExcel = async () => {
    if (!asset) return;
    setExportLoading('excel');
    try {
      const XLSX = await import('xlsx');
      const rows = [
        ['ASSETDESK — FICHA TÉCNICA DEL ACTIVO', ''],
        ['Generado', new Date().toLocaleString('es-CO')],
        ['Campo', 'Valor'],
        ['Placa', asset.placa || ''],
        ['Marca', asset.marca || ''],
        ['Modelo', asset.modelo || ''],
        ['Serial', asset.serial || ''],
        ['Estado', statusLabels[asset.status || 'operational']],
        ['Usuario', asset.usuario_responsable || ''],
        ['Área', asset.area || ''],
        ['Ubicación', asset.ubicacion || ''],
        ['Sede', asset.sede || ''],
        ['IP', asset.direccion_ip || ''],
        ['MAC', asset.mac_address || ''],
        ['CPU', [asset.procesador_marca, asset.procesador_tipo].filter(Boolean).join(' ')],
        ['RAM', asset.ram_capacidad || ''],
        ['Disco', asset.disco_capacidad || ''],
        ['S.O.', asset.sistema_operativo || ''],
        ['Técnico', asset.tecnico_instalador || ''],
        ['F. Asignación', asset.fecha_asignacion || ''],
        ['Observaciones', asset.observaciones || ''],
      ];
      const ws = XLSX.utils.aoa_to_sheet(rows);
      ws['!cols'] = [{ wch: 30 }, { wch: 58 }];
      ws['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }];
      ws['!freeze'] = { xSplit: 0, ySplit: 3 };
      ws['!autofilter'] = { ref: `A3:B${rows.length}` };
      const headerStyle = { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: '1E1E2E' } }, alignment: { horizontal: 'center' } };
      const sectionStyle = { font: { bold: true, color: { rgb: '1E1E2E' } }, fill: { fgColor: { rgb: 'DCE6FF' } } };
      if (ws.A1) ws.A1.s = headerStyle;
      if (ws.A3) ws.A3.s = sectionStyle;
      if (ws.B3) ws.B3.s = sectionStyle;
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Ficha técnica');
      const resumen = XLSX.utils.aoa_to_sheet([
        ['ASSETDESK — RESUMEN'],
        ['Activo', `${asset.marca || ''} ${asset.modelo || ''}`.trim()],
        ['Placa', asset.placa || ''],
        ['Estado', statusLabels[asset.status || 'operational']],
        ['IP', asset.direccion_ip || ''],
        ['Responsable', asset.usuario_responsable || ''],
        ['Ubicación', asset.ubicacion || asset.area || ''],
      ]);
      resumen['!cols'] = [{ wch: 24 }, { wch: 58 }];
      resumen['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }];
      if (resumen.A1) resumen.A1.s = headerStyle;
      XLSX.utils.book_append_sheet(wb, resumen, 'Resumen');
      XLSX.writeFile(wb, `assetdesk_${asset.placa || asset.id}.xlsx`);
    } catch (e) { console.error(e); alert('Error al exportar Excel'); }
    finally { setExportLoading(null); }
  };

  const handleExportPDF = async () => {
    if (!asset) return;
    setExportLoading('pdf');
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const m = 15;
      let y = m;

      doc.setFontSize(16); doc.setFont('helvetica', 'bold');
      doc.text(`${asset.marca || ''} ${asset.modelo || ''}`, m, y); y += 7;
      doc.setFontSize(10); doc.setFont('helvetica', 'normal'); doc.setTextColor(80, 80, 80);
      doc.text(`Placa: ${asset.placa || 'N/A'}  |  S/N: ${asset.serial || 'N/A'}`, m, y); y += 5;
      doc.text(`Estado: ${statusLabels[asset.status || 'operational']}  |  Sede: ${asset.sede || 'N/A'}`, m, y); y += 8;
      doc.setDrawColor(200, 200, 200); doc.line(m, y, 210 - m, y); y += 6;

      const section = (title: string, rows: [string, string][]) => {
        doc.setFontSize(9); doc.setFont('helvetica', 'bold'); doc.setTextColor(60, 60, 60);
        doc.text(title.toUpperCase(), m, y); y += 4;
        doc.setFont('helvetica', 'normal');
        rows.forEach(([lbl, val]) => {
          if (!val || val === 'N/A') return;
          doc.setFontSize(8.5); doc.setTextColor(120, 120, 120); doc.text(lbl + ':', m, y);
          doc.setTextColor(30, 30, 30); doc.text(val, m + 45, y); y += 5;
        });
        y += 3;
      };

      section('Identificación', [
        ['Placa', asset.placa || 'N/A'],
        ['Serial', asset.serial || 'N/A'],
        ['Tipo', asset.tipo_equipo || 'N/A'],
      ]);
      section('Hardware', [
        ['CPU', [asset.procesador_marca, asset.procesador_tipo, asset.procesador_velocidad].filter(Boolean).join(' ') || 'N/A'],
        ['RAM', [asset.ram_capacidad, asset.ram_tipo].filter(Boolean).join(' ') || 'N/A'],
        ['Disco', [asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' ') || 'N/A'],
        ['S.O.', asset.sistema_operativo || 'N/A'],
      ]);
      section('Asignación', [
        ['Usuario', asset.usuario_responsable || 'N/A'],
        ['Área', asset.area || 'N/A'],
        ['Ubicación', asset.ubicacion || 'N/A'],
        ['Técnico', asset.tecnico_instalador || 'N/A'],
        ['F. Asignación', asset.fecha_asignacion || 'N/A'],
      ]);
      section('Red', [
        ['IP', asset.direccion_ip || 'N/A'],
        ['MAC', asset.mac_address || 'N/A'],
        ['DNS', asset.dns_primario || 'N/A'],
      ]);

      if (asset.observaciones) {
        doc.setFontSize(9); doc.setFont('helvetica', 'bold'); doc.setTextColor(60, 60, 60);
        doc.text('OBSERVACIONES', m, y); y += 4;
        doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(80, 80, 80);
        const lines = doc.splitTextToSize(asset.observaciones, 180 - m);
        doc.text(lines, m, y);
      }

      doc.setFontSize(7); doc.setTextColor(150, 150, 150);
      doc.text(`AssetDesk — Generado: ${new Date().toLocaleDateString('es-CO')}`, m, 287);
      doc.save(`equipo_${asset.placa || asset.id}.pdf`);
    } catch (e) { console.error(e); alert('Error al generar PDF'); }
    finally { setExportLoading(null); }
  };

  // ── Compliance check ─────────────────────────────────────────────────────
  const complianceItems = asset ? [
    { label: 'Sistema Operativo registrado', ok: !!asset.sistema_operativo },
    { label: 'Antivirus registrado', ok: !!asset.antivirus },
    { label: 'Dirección IP asignada', ok: !!asset.direccion_ip },
    { label: 'MAC Address registrada', ok: !!asset.mac_address },
    { label: 'Usuario responsable asignado', ok: !!asset.usuario_responsable },
    { label: 'Técnico instalador registrado', ok: !!asset.tecnico_instalador },
    { label: 'Fecha de asignación registrada', ok: !!asset.fecha_asignacion },
    { label: 'Foto del equipo cargada', ok: !!asset.foto_url },
    { label: 'Serial registrado', ok: !!asset.serial },
    { label: 'Garantía registrada', ok: !!asset.garantia_vencimiento },
  ] : [];
  const complianceScore = complianceItems.length > 0
    ? Math.round((complianceItems.filter(i => i.ok).length / complianceItems.length) * 100)
    : 0;

  return (
    <AppLayout>
      <Topbar title="Vista Técnico de Campo" subtitle="Escaneo QR automático y sincronización en vivo" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-4 max-w-2xl mx-auto w-full">

        {/* ── Status Bar ── */}
        <div className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-xs font-medium ${
          !isOnline
            ? 'bg-red-500/5 border-red-500/20 text-red-400'
            : realtimeConnected
              ? 'bg-green-500/5 border-green-500/20 text-green-400' :'bg-amber-500/5 border-amber-500/20 text-amber-400'
        }`}>
          <div className="flex items-center gap-2">
            {isOnline ? <Wifi size={13} /> : <WifiOff size={13} />}
            {!isOnline
              ? 'Sin conexión — usando caché local'
              : realtimeConnected
                ? 'Sincronización en vivo activa' :'Conectando...'}
          </div>
          <div className="flex items-center gap-3">
            {!isOnline && (
              <span className="text-[10px] px-2 py-0.5 bg-red-500/10 rounded-full">OFFLINE</span>
            )}
            <div className="flex items-center gap-1.5">
              <Users size={12} />
              <span>{technicians.length} técnico{technicians.length !== 1 ? 's' : ''}</span>
            </div>
          </div>
        </div>

        {/* ── Live Technicians Panel ── */}
        {technicians.length > 0 && (
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <UserCheck size={15} className="text-primary" /> Técnicos en Campo
              </h2>
              <div className={`flex items-center gap-1.5 text-[10px] font-semibold px-2 py-1 rounded-full ${
                realtimeConnected ? 'bg-green-500/10 text-green-400' : 'bg-amber-500/10 text-amber-400'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${realtimeConnected ? 'bg-green-400 animate-pulse' : 'bg-amber-400'}`} />
                EN VIVO
              </div>
            </div>
            <div className="p-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {technicians.map(tech => (
                <div key={tech.id} className="flex items-center gap-3 p-3 bg-secondary/40 border border-border/60 rounded-xl">
                  <div className={`w-8 h-8 rounded-full ${tech.avatar_color || 'bg-primary'} flex items-center justify-center text-white text-xs font-bold shrink-0`}>
                    {tech.name?.charAt(0)?.toUpperCase() || 'T'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground truncate">{tech.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{tech.current_location || 'Sin ubicación'}</p>
                  </div>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-semibold shrink-0 ${
                    tech.status === 'active' ? 'bg-green-500/10 text-green-400' :
                    tech.status === 'busy' ? 'bg-amber-500/10 text-amber-400' : 'bg-gray-500/10 text-gray-400'
                  }`}>
                    {tech.status === 'active' ? 'ACTIVO' : tech.status === 'busy' ? 'OCUPADO' : 'INACTIVO'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Scanner / Search Panel ── */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <QrCode size={16} className="text-primary" /> Escáner QR Automático
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isOnline ? 'Decodificación automática con jsQR — apunta al código QR' : 'Modo offline — búsqueda en caché local'}
            </p>
          </div>

          <div className="p-4 space-y-3">
            {/* Camera viewfinder */}
            {cameraActive && (
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video">
                <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
                <canvas ref={canvasRef} className="hidden" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-44 h-44 relative">
                    <div className="absolute top-0 left-0 w-7 h-7 border-t-4 border-l-4 border-primary rounded-tl-lg" />
                    <div className="absolute top-0 right-0 w-7 h-7 border-t-4 border-r-4 border-primary rounded-tr-lg" />
                    <div className="absolute bottom-0 left-0 w-7 h-7 border-b-4 border-l-4 border-primary rounded-bl-lg" />
                    <div className="absolute bottom-0 right-0 w-7 h-7 border-b-4 border-r-4 border-primary rounded-br-lg" />
                    <div className="absolute inset-x-0 top-1/2 h-0.5 bg-primary/70 animate-pulse" />
                  </div>
                </div>
                <button onClick={stopCamera}
                  className="absolute top-3 right-3 p-2 bg-black/60 rounded-full text-white hover:bg-black/80 transition-colors z-10">
                  <X size={16} />
                </button>
                <div className="absolute bottom-3 inset-x-0 text-center pointer-events-none">
                  {qrDecoding ? (
                    <span className="text-xs text-white/90 bg-black/60 px-3 py-1 rounded-full flex items-center gap-1.5 w-fit mx-auto">
                      <RefreshCw size={10} className="animate-spin" /> Decodificando QR automáticamente...
                    </span>
                  ) : (
                    <span className="text-xs text-white/80 bg-black/50 px-3 py-1 rounded-full">Apunta al código QR del equipo</span>
                  )}
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-2">
              <button onClick={cameraActive ? stopCamera : startCamera}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-colors ${
                  cameraActive
                    ? 'bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20' :'bg-primary text-primary-foreground hover:bg-primary/90'
                }`}>
                <Camera size={16} />
                {cameraActive ? 'Detener Cámara' : 'Activar Escáner QR'}
              </button>
            </div>
            {cameraError && (
              <div className="flex items-start gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl text-amber-300 text-xs">
                <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                <span>{cameraError}</span>
              </div>
            )}

            {/* Manual search */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleManualSearch()}
                  placeholder="Buscar por placa, serial, usuario..."
                  className="w-full pl-8 pr-3 py-2.5 text-sm bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
                />
              </div>
              <button onClick={handleManualSearch}
                className="px-4 py-2.5 bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors text-sm">
                Buscar
              </button>
            </div>

            {scanState === 'scanning' && (
              <div className="flex items-center justify-center gap-2 py-3 text-muted-foreground text-sm">
                <RefreshCw size={14} className="animate-spin" /> Buscando...
              </div>
            )}
            {scanState === 'not_found' && (
              <div className="flex items-center gap-2 p-3 bg-red-500/5 border border-red-500/20 rounded-xl text-red-400 text-sm">
                <AlertTriangle size={14} /> No se encontró ningún equipo con esa placa
                {!isOnline && <span className="text-[10px] ml-1">(modo offline)</span>}
              </div>
            )}
          </div>
        </div>

        {/* ── Asset Detail Card (full info + image) ── */}
        {asset && scanState === 'found' && (
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {/* Card header */}
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="font-mono text-primary text-sm font-bold">{asset.placa}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${statusColors[asset.status || 'operational']}`}>
                    {statusLabels[asset.status || 'operational']}
                  </span>
                </div>
                <h3 className="text-base font-bold text-foreground">{asset.marca} {asset.modelo}</h3>
                <p className="text-xs text-muted-foreground">S/N: {asset.serial}</p>
              </div>
              <div className="flex items-center gap-1.5">
                {statusIcons[asset.status || 'operational']}
                {/* Share button */}
                <button
                  onClick={() => handleShare(asset)}
                  title={shareSuccess ? 'Copiado!' : 'Compartir información'}
                  className={`p-1.5 rounded-lg transition-colors ${shareSuccess ? 'text-green-400 bg-green-500/10' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
                  {shareSuccess ? <CheckCircle size={16} /> : <Share2 size={16} />}
                </button>
                <button onClick={handleReset}
                  className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Equipment image */}
            {asset.foto_url && (
              <div className="px-4 pt-4">
                <AppImage
                  src={asset.foto_url}
                  alt={`Foto de ${asset.marca} ${asset.modelo}`}
                  width={960}
                  height={384}
                  unoptimized
                  className="w-full h-48 object-cover rounded-xl border border-border"
                />
              </div>
            )}

            {/* QR + basic info row */}
            <div className="px-4 pt-4 flex items-start gap-4">
              <div className="bg-white p-2 rounded-xl border border-border shrink-0">
                <QRCodeSVG
                  value={getAssetQrUrl(asset.id)}
                  size={80}
                  level="M"
                  includeMargin={false}
                />
                <p className="text-[9px] text-gray-500 text-center mt-1 font-mono">{asset.placa || asset.serial}</p>
              </div>
              <div className="flex-1 min-w-0 space-y-1">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">Código QR del Equipo</p>
                {asset.tipo_equipo && <p className="text-xs text-foreground"><span className="text-muted-foreground">Tipo:</span> {asset.tipo_equipo}</p>}
                {asset.sede && <p className="text-xs text-foreground"><span className="text-muted-foreground">Sede:</span> {asset.sede}</p>}
                {asset.n_ficha && <p className="text-xs text-foreground"><span className="text-muted-foreground">N° Ficha:</span> {asset.n_ficha}</p>}
                {asset.tag && <p className="text-xs text-foreground"><span className="text-muted-foreground">TAG:</span> {asset.tag}</p>}
              </div>
            </div>

            {/* Full info grid */}
            <div className="p-4 grid grid-cols-2 gap-2.5">
              <InfoCard label="Usuario" value={asset.usuario_responsable} />
              <InfoCard label="Área" value={asset.area} />
              <InfoCard label="Ubicación" value={asset.ubicacion} />
              <InfoCard label="Sede" value={asset.sede} />
              <InfoCard label="Procesador" value={[asset.procesador_marca, asset.procesador_tipo, asset.procesador_velocidad].filter(Boolean).join(' ') || null} />
              <InfoCard label="RAM" value={[asset.ram_capacidad, asset.ram_tipo].filter(Boolean).join(' ') || null} />
              <InfoCard label="Disco" value={[asset.disco_capacidad, asset.disco_tecnologia].filter(Boolean).join(' ') || null} />
              <InfoCard label="S.O." value={asset.sistema_operativo} />
              <InfoCard label="IP" value={asset.direccion_ip} mono />
              <InfoCard label="MAC" value={asset.mac_address} mono />
              <InfoCard label="Hostname" value={asset.nombre_equipo} mono />
              <InfoCard label="DNS" value={asset.dns_primario} mono />
              <InfoCard label="Técnico Instalador" value={asset.tecnico_instalador} />
              <InfoCard label="Fecha Asignación" value={asset.fecha_asignacion} />
              <InfoCard label="Garantía" value={asset.garantia_vencimiento} />
              <InfoCard label="Proveedor" value={asset.proveedor} />
              {asset.office_version && <InfoCard label="Office" value={asset.office_version} />}
              {asset.antivirus && <InfoCard label="Antivirus" value={asset.antivirus} />}
            </div>

            {/* Monitor / Peripherals */}
            {(asset.monitor_marca || asset.teclado_marca || asset.mouse_marca) && (
              <div className="px-4 pb-2">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold mb-2">Periféricos</p>
                <div className="grid grid-cols-2 gap-2">
                  {asset.monitor_marca && <InfoCard label="Monitor" value={[asset.monitor_marca, asset.monitor_modelo, asset.monitor_tamano ? `${asset.monitor_tamano}"` : ''].filter(Boolean).join(' ')} />}
                  {asset.teclado_marca && <InfoCard label="Teclado" value={asset.teclado_marca} />}
                  {asset.mouse_marca && <InfoCard label="Mouse" value={asset.mouse_marca} />}
                  {asset.impresora_marca && <InfoCard label="Impresora" value={[asset.impresora_marca, asset.impresora_modelo].filter(Boolean).join(' ')} />}
                </div>
              </div>
            )}

            {asset.observaciones && (
              <div className="px-4 pb-4">
                <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3">
                  <p className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider mb-1">Observaciones</p>
                  <p className="text-xs text-muted-foreground">{asset.observaciones}</p>
                </div>
              </div>
            )}

            {/* Export Panel */}
            <div className="px-4 pb-2">
              <button
                onClick={() => setShowExportPanel(v => !v)}
                className="w-full flex items-center justify-between px-4 py-2.5 bg-secondary/50 border border-border rounded-xl text-xs font-semibold text-foreground hover:bg-secondary transition-colors">
                <div className="flex items-center gap-2">
                  <Download size={13} className="text-primary" />
                  Panel de Exportación
                </div>
                {showExportPanel ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </button>
              {showExportPanel && (
                <div className="mt-2 p-3 bg-secondary/30 border border-border rounded-xl space-y-2">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold mb-2">Exportar información del equipo</p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleExportExcel}
                      disabled={exportLoading === 'excel'}
                      className="flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold bg-green-500/10 border border-green-500/30 text-green-400 hover:bg-green-500/20 rounded-xl transition-colors disabled:opacity-50">
                      {exportLoading === 'excel' ? <RefreshCw size={13} className="animate-spin" /> : <FileSpreadsheet size={13} />}
                      Excel (.xlsx)
                    </button>
                    <button
                      onClick={handleExportPDF}
                      disabled={exportLoading === 'pdf'}
                      className="flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold bg-blue-500/10 border border-blue-500/30 text-blue-400 hover:bg-blue-500/20 rounded-xl transition-colors disabled:opacity-50">
                      {exportLoading === 'pdf' ? <RefreshCw size={13} className="animate-spin" /> : <FileDown size={13} />}
                      PDF
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Compliance Panel */}
            <div className="px-4 pb-4">
              <button
                onClick={() => setShowCompliancePanel(v => !v)}
                className="w-full flex items-center justify-between px-4 py-2.5 bg-secondary/50 border border-border rounded-xl text-xs font-semibold text-foreground hover:bg-secondary transition-colors">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={13} className={complianceScore >= 80 ? 'text-green-400' : complianceScore >= 50 ? 'text-amber-400' : 'text-red-400'} />
                  Cumplimiento de Datos
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    complianceScore >= 80 ? 'bg-green-500/10 text-green-400' :
                    complianceScore >= 50 ? 'bg-amber-500/10 text-amber-400' : 'bg-red-500/10 text-red-400'
                  }`}>{complianceScore}%</span>
                </div>
                {showCompliancePanel ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </button>
              {showCompliancePanel && (
                <div className="mt-2 p-3 bg-secondary/30 border border-border rounded-xl">
                  <div className="mb-3">
                    <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                      <span>Completitud del registro</span>
                      <span>{complianceItems.filter(i => i.ok).length}/{complianceItems.length} campos</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${complianceScore >= 80 ? 'bg-green-500' : complianceScore >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
                        style={{ width: `${complianceScore}%` }}
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    {complianceItems.map((item, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs">
                        {item.ok
                          ? <CheckCircle size={12} className="text-green-400 shrink-0" />
                          : <AlertTriangle size={12} className="text-amber-400 shrink-0" />}
                        <span className={item.ok ? 'text-foreground' : 'text-muted-foreground'}>{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="px-4 pb-4">
              <button onClick={handleReset}
                className="w-full py-2.5 text-sm bg-secondary border border-border text-muted-foreground hover:text-foreground rounded-xl transition-colors">
                Nueva Búsqueda
              </button>
            </div>
          </div>
        )}

        {/* ── Priority Assets ── */}
        {scanState === 'idle' && (
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Zap size={16} className="text-amber-400" /> Equipos Prioritarios
                </h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Críticos y en mantenimiento{!isOnline ? ' (caché local)' : ''}
                </p>
              </div>
              <button onClick={loadPriorityAssets} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <RefreshCw size={13} />
              </button>
            </div>
            <div className="p-3 space-y-2">
              {loadingRecent ? (
                <div className="text-center py-6 text-muted-foreground text-xs">
                  <RefreshCw size={14} className="inline animate-spin mr-2" />Cargando...
                </div>
              ) : recentAssets.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-xs">
                  <CheckCircle size={20} className="inline text-green-400 mr-2" />Todos los equipos están operativos
                </div>
              ) : recentAssets.map(a => (
                <button key={a.id} onClick={() => handleSelectAsset(a)}
                  className="w-full flex items-center gap-3 p-3 bg-secondary/50 border border-border rounded-xl hover:bg-secondary transition-colors text-left">
                  {/* Thumbnail */}
                  {a.foto_url ? (
                    <AppImage
                      src={a.foto_url}
                      alt={`${a.marca} ${a.modelo}`}
                      width={40}
                      height={40}
                      unoptimized
                      className="w-10 h-10 object-cover rounded-lg border border-border shrink-0"
                    />
                  ) : (
                    <div className={`p-2 rounded-lg shrink-0 ${a.status === 'critical' ? 'bg-red-500/10' : 'bg-amber-500/10'}`}>
                      {a.status === 'critical' ? <AlertTriangle size={14} className="text-red-400" /> : <Wrench size={14} className="text-amber-400" />}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-primary font-semibold">{a.placa}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full border font-semibold ${statusColors[a.status || 'operational']}`}>
                        {statusLabels[a.status || 'operational']}
                      </span>
                    </div>
                    <p className="text-xs text-foreground font-medium truncate">{a.marca} {a.modelo}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{a.ubicacion || a.area} · {a.usuario_responsable}</p>
                  </div>
                  <div className="bg-white p-1 rounded-lg shrink-0">
                    <QRCodeSVG value={getAssetQrUrl(a.id)} size={32} level="M" includeMargin />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

    </AppLayout>
  );
}

export default function TechnicianPage() {
  return (
    <Suspense fallback={<div className="flex h-screen items-center justify-center bg-background text-sm text-muted-foreground">Preparando escáner...</div>}>
      <TechnicianPageContent />
    </Suspense>
  );
}
