import React from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import AssetTableSection from './components/AssetTableSection';

export default function AssetInventoryPage() {
  return (
    <AppLayout>
      <Topbar
        title="Inventario de Activos"
        subtitle="Hoja de vida de equipos de cómputo — Registro y gestión"
      />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">
        <AssetTableSection />
      </div>
    </AppLayout>
  );
}