'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import Topbar from '@/components/Topbar';
import { Settings, Save, RefreshCw, Building, Network, Bell, Tag, CheckCircle } from 'lucide-react';
import { settingsService } from '@/lib/services/assetService';

interface Setting {
  id: string;
  key: string;
  value?: string;
  label?: string;
  description?: string;
  category?: string;
}

const categoryIcons: Record<string, React.ReactNode> = {
  general: <Building size={14} />,
  network: <Network size={14} />,
  notifications: <Bell size={14} />,
  inventory: <Tag size={14} />,
  tickets: <Tag size={14} />,
};

const categoryLabels: Record<string, string> = {
  general: 'Organización',
  network: 'Configuración de Red',
  notifications: 'Notificaciones',
  inventory: 'Inventario',
  tickets: 'Tickets',
};

export default function SettingsPage() {
  const [settings, setSettings] = useState<Setting[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [localValues, setLocalValues] = useState<Record<string, string>>({});

  const loadSettings = async () => {
    setLoading(true);
    const data = await settingsService.getAll();
    setSettings(data as Setting[]);
    const vals: Record<string, string> = {};
    (data as Setting[]).forEach(s => { vals[s.key] = s.value || ''; });
    setLocalValues(vals);
    setLoading(false);
  };

  useEffect(() => { loadSettings(); }, []);

  const handleSave = async (key: string) => {
    setSaving(key);
    const ok = await settingsService.update(key, localValues[key] || '');
    setSaving(null);
    if (ok) {
      setSaved(key);
      setTimeout(() => setSaved(null), 2000);
    }
  };

  const grouped = settings.reduce<Record<string, Setting[]>>((acc, s) => {
    const cat = s.category || 'general';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(s);
    return acc;
  }, {});

  return (
    <AppLayout>
      <Topbar title="Configuración" subtitle="Parámetros del sistema AssetDesk" />
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
            <RefreshCw size={16} className="animate-spin" /> Cargando configuración...
          </div>
        ) : (
          Object.entries(grouped).map(([category, items]) => (
            <div key={category} className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-secondary/30">
                <span className="text-muted-foreground">{categoryIcons[category] || <Settings size={14} />}</span>
                <h2 className="text-sm font-semibold text-foreground">{categoryLabels[category] || category}</h2>
              </div>
              <div className="divide-y divide-border/50">
                {items.map(setting => (
                  <div key={setting.key} className="flex items-center gap-4 px-5 py-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{setting.label || setting.key}</p>
                      {setting.description && (
                        <p className="text-xs text-muted-foreground mt-0.5">{setting.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {setting.key.includes('notify') ? (
                        <button
                          onClick={() => {
                            const newVal = localValues[setting.key] === 'true' ? 'false' : 'true';
                            setLocalValues(prev => ({ ...prev, [setting.key]: newVal }));
                            settingsService.update(setting.key, newVal);
                          }}
                          className={`relative w-10 h-5 rounded-full transition-colors ${localValues[setting.key] === 'true' ? 'bg-primary' : 'bg-secondary border border-border'}`}>
                          <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${localValues[setting.key] === 'true' ? 'translate-x-5' : 'translate-x-0.5'}`} />
                        </button>
                      ) : (
                        <>
                          <input
                            type="text"
                            value={localValues[setting.key] || ''}
                            onChange={e => setLocalValues(prev => ({ ...prev, [setting.key]: e.target.value }))}
                            className="w-56 bg-secondary border border-border rounded-lg px-3 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary"
                          />
                          <button
                            onClick={() => handleSave(setting.key)}
                            disabled={saving === setting.key}
                            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 rounded-lg transition-colors disabled:opacity-50">
                            {saved === setting.key ? (
                              <><CheckCircle size={12} /> Guardado</>
                            ) : saving === setting.key ? (
                              <><RefreshCw size={12} className="animate-spin" /> Guardando...</>
                            ) : (
                              <><Save size={12} /> Guardar</>
                            )}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}

        {/* System Info */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Settings size={14} className="text-muted-foreground" /> Información del Sistema
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-xs">
            {[
              ['Aplicación', 'AssetDesk v2.0'],
              ['Framework', 'Next.js 15'],
              ['Base de Datos', 'Supabase PostgreSQL'],
              ['Versión Schema', '20260717'],
              ['Módulos Activos', 'Inventario, Bajas, IPs, Técnico, Notificaciones'],
              ['Soporte QR', 'Generación + Escaneo'],
            ].map(([label, value]) => (
              <div key={label} className="bg-secondary/50 border border-border/60 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
                <p className="text-foreground font-medium">{value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
