'use client';

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Search, X, Monitor, Wifi, ChevronRight, Loader2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

interface SearchResult {
  id: string;
  type: 'asset' | 'ip' | 'wifi';
  title: string;
  subtitle: string;
  href: string;
  status?: string;
}

interface GlobalSearchProps {
  onClose: () => void;
}

export default function GlobalSearch({ onClose }: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const search = useCallback(async (q: string) => {
    const safeQuery = q.trim().replace(/[%,()]/g, ' ');
    if (safeQuery.length < 2) { setResults([]); return; }
    setLoading(true);
    const [assetsRes, ipsRes, wifiRes] = await Promise.all([
      supabase.from('assets').select('id, placa, marca, modelo, serial, direccion_ip, usuario_responsable, ubicacion, status, tipo_equipo').or(
        `placa.ilike.%${safeQuery}%,marca.ilike.%${safeQuery}%,modelo.ilike.%${safeQuery}%,serial.ilike.%${safeQuery}%,direccion_ip.ilike.%${safeQuery}%,usuario_responsable.ilike.%${safeQuery}%,ubicacion.ilike.%${safeQuery}%,nombre_equipo.ilike.%${safeQuery}%,area.ilike.%${safeQuery}%`
      ).limit(8),
      supabase.from('ip_addresses').select('id, direccion_ip, hostname, asignado_a, tipo_asignacion').or(
        `direccion_ip.ilike.%${safeQuery}%,hostname.ilike.%${safeQuery}%,asignado_a.ilike.%${safeQuery}%`
      ).limit(4),
      supabase.from('wifi_networks').select('id, nombre, ssid, area, sede').or(
        `nombre.ilike.%${safeQuery}%,ssid.ilike.%${safeQuery}%,area.ilike.%${safeQuery}%`
      ).limit(3),
    ]);

    const combined: SearchResult[] = [
      ...(assetsRes.data || []).map(a => ({
        id: a.id,
        type: 'asset' as const,
        title: `${a.marca || ''} ${a.modelo || ''}`.trim() || a.placa || 'Equipo',
        subtitle: `${a.placa || ''} · ${a.tipo_equipo || ''} · ${a.ubicacion || 'Sin ubicación'}`,
        href: `/asset/${a.id}`,
        status: a.status,
      })),
      ...(ipsRes.data || []).map(ip => ({
        id: ip.id,
        type: 'ip' as const,
        title: ip.direccion_ip || 'IP',
        subtitle: `${ip.hostname || 'Sin hostname'} · ${ip.asignado_a || 'Sin asignar'}`,
        href: '/ip-management',
      })),
      ...(wifiRes.data || []).map(w => ({
        id: w.id,
        type: 'wifi' as const,
        title: w.nombre || w.ssid || 'Red WiFi',
        subtitle: `SSID: ${w.ssid || ''} · ${w.area || w.sede || 'Sin área'}`,
        href: '/ip-management',
      })),
    ];
    setResults(combined);
    setSelected(0);
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    const t = setTimeout(() => search(query), 250);
    return () => clearTimeout(t);
  }, [query, search]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, results.length - 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)); }
    if (e.key === 'Enter' && results[selected]) { router.push(results[selected].href); onClose(); }
    if (e.key === 'Escape') onClose();
  };

  const typeIcon = (type: string) => {
    if (type === 'asset') return <Monitor size={14} className="text-primary" />;
    if (type === 'ip') return <Wifi size={14} className="text-cyan-400" />;
    return <Wifi size={14} className="text-green-400" />;
  };

  const statusColor = (status?: string) => {
    if (status === 'operational') return 'bg-green-500/20 text-green-400';
    if (status === 'critical') return 'bg-red-500/20 text-red-400';
    if (status === 'maintenance') return 'bg-amber-500/20 text-amber-400';
    return '';
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-20 px-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden">
        {/* Search input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
          {loading ? <Loader2 size={16} className="text-muted-foreground animate-spin shrink-0" /> : <Search size={16} className="text-muted-foreground shrink-0" />}
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Buscar equipos, IPs, redes WiFi, usuarios..."
            className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-muted-foreground hover:text-foreground transition-colors">
              <X size={14} />
            </button>
          )}
          <kbd className="text-[10px] bg-secondary px-1.5 py-0.5 rounded text-muted-foreground border border-border">ESC</kbd>
        </div>

        {/* Results */}
        {query.length >= 2 && (
          <div className="max-h-96 overflow-y-auto scrollbar-thin">
            {results.length === 0 && !loading ? (
              <div className="px-4 py-8 text-center">
                <Search size={24} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Sin resultados para &ldquo;{query}&rdquo;</p>
              </div>
            ) : (
              <div className="py-2">
                {results.map((r, i) => (
                  <button
                    key={`${r.type}-${r.id}`}
                    onClick={() => { router.push(r.href); onClose(); }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${i === selected ? 'bg-secondary' : 'hover:bg-secondary/50'}`}
                  >
                    <div className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                      {typeIcon(r.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{r.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{r.subtitle}</p>
                    </div>
                    {r.status && <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${statusColor(r.status)}`}>{r.status}</span>}
                    <ChevronRight size={13} className="text-muted-foreground shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Hints */}
        {query.length < 2 && (
          <div className="px-4 py-4">
            <p className="text-xs text-muted-foreground mb-3">Búsqueda rápida por:</p>
            <div className="flex flex-wrap gap-2">
              {['Placa inventario', 'Marca / Modelo', 'Usuario responsable', 'Dirección IP', 'Ubicación', 'Área'].map(hint => (
                <span key={hint} className="text-xs bg-secondary border border-border px-2 py-1 rounded-md text-muted-foreground">{hint}</span>
              ))}
            </div>
          </div>
        )}

        <div className="px-4 py-2 border-t border-border flex items-center gap-4 text-[10px] text-muted-foreground">
          <span><kbd className="bg-secondary px-1 rounded border border-border">↑↓</kbd> Navegar</span>
          <span><kbd className="bg-secondary px-1 rounded border border-border">↵</kbd> Abrir</span>
          <span><kbd className="bg-secondary px-1 rounded border border-border">ESC</kbd> Cerrar</span>
        </div>
      </div>
    </div>
  );
}
