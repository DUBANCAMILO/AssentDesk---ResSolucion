'use client';

import Link from 'next/link';
import { ScanLine } from 'lucide-react';

export default function FloatingScanner() {
  return (
    <Link
      href="/tecnico?scan=1"
      aria-label="Abrir escáner QR"
      title="Escanear QR"
      className="fixed right-4 bottom-24 md:bottom-6 z-40 flex items-center gap-2 rounded-full border border-primary/50 bg-primary px-4 py-3 text-primary-foreground shadow-2xl transition-transform hover:scale-105"
    >
      <ScanLine size={19} />
      <span className="hidden text-xs font-semibold sm:inline">Escanear QR</span>
    </Link>
  );
}
