'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Sidebar from './Sidebar';
import MobileBottomNav from './MobileBottomNav';
import FloatingScanner from './FloatingScanner';

const SplashScreen = dynamic(() => import('./SplashScreen'), { ssr: false });

interface AppLayoutProps {
  children: React.ReactNode;
}

// Track if splash has been shown in this session
let splashShownThisSession = false;

export default function AppLayout({ children }: AppLayoutProps) {
  const [showSplash, setShowSplash] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    if (!splashShownThisSession) {
      splashShownThisSession = true;
      setShowSplash(true);
    }
  }, []);

  const handleSplashDone = () => {
    setShowSplash(false);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {mounted && showSplash && <SplashScreen onDone={handleSplashDone} />}
      <Sidebar />
      <main className="flex-1 overflow-hidden flex flex-col pb-16 md:pb-0">
        {children}
      </main>
      <MobileBottomNav />
      <FloatingScanner />
    </div>
  );
}