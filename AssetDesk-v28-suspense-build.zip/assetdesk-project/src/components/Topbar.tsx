'use client';

import React, { useState, useEffect } from 'react';
import { Search, Bell, RefreshCw } from 'lucide-react';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import { notificationService } from '@/lib/services/assetService';

const GlobalSearch = dynamic(() => import('./GlobalSearch'), { ssr: false });

interface TopbarProps {
  title: string;
  subtitle?: string;
}

export default function Topbar({ title, subtitle }: TopbarProps) {
  const router = useRouter();
  const [searchOpen, setSearchOpen] = useState(false);
  const [lastUpdated, setLastUpdated] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const now = new Date();
    setLastUpdated(now.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' }));
  }, []);

  useEffect(() => {
    let active = true;
    const refreshUnread = async () => {
      const count = await notificationService.getUnreadCount();
      if (active) setUnreadCount(count);
    };
    refreshUnread();
    const channel = notificationService.subscribeToNew(() => refreshUnread());
    return () => {
      active = false;
      channel.unsubscribe();
    };
  }, []);

  // Keyboard shortcut Cmd/Ctrl+K
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <>
      <header className="h-16 bg-card border-b border-border flex items-center justify-between px-6 shrink-0">
        <div>
          <h1 className="text-base font-semibold text-foreground">{title}</h1>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors duration-150 px-3 py-1.5 rounded-lg hover:bg-secondary border border-transparent hover:border-border"
          >
            <Search size={15} />
            <span className="text-xs hidden lg:block">Buscar</span>
            <kbd className="hidden lg:block text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">⌘K</kbd>
          </button>

          {lastUpdated && (
            <div className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground">
              <RefreshCw size={11} />
              <span>Actualizado {lastUpdated}</span>
            </div>
          )}

          <button
            onClick={() => router.push('/notificaciones')}
            aria-label={unreadCount > 0 ? `${unreadCount} notificaciones sin leer` : 'Notificaciones'}
            title="Abrir notificaciones"
            className="relative p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-all duration-150"
          >
            <Bell size={17} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 flex items-center justify-center bg-red-500 rounded-full text-[9px] font-bold text-white">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {searchOpen && <GlobalSearch onClose={() => setSearchOpen(false)} />}
    </>
  );
}
