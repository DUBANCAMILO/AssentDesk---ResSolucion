import React from 'react';

type StatusVariant =
  | 'operational' |'maintenance' |'critical' |'decommissioned' |'open' |'in-progress' |'pending-parts' |'resolved' |'closed' |'available' |'assigned';

const variantMap: Record<
  StatusVariant,
  { bg: string; text: string; dot: string; label: string }
> = {
  operational: {
    bg: 'bg-green-500/10',
    text: 'text-green-400',
    dot: 'bg-green-400',
    label: 'Operational',
  },
  maintenance: {
    bg: 'bg-amber-500/10',
    text: 'text-amber-400',
    dot: 'bg-amber-400',
    label: 'Maintenance',
  },
  critical: {
    bg: 'bg-red-500/10',
    text: 'text-red-400',
    dot: 'bg-red-400',
    label: 'Critical',
  },
  decommissioned: {
    bg: 'bg-slate-500/10',
    text: 'text-slate-400',
    dot: 'bg-slate-400',
    label: 'Decommissioned',
  },
  open: {
    bg: 'bg-blue-500/10',
    text: 'text-blue-400',
    dot: 'bg-blue-400',
    label: 'Open',
  },
  'in-progress': {
    bg: 'bg-purple-500/10',
    text: 'text-purple-400',
    dot: 'bg-purple-400',
    label: 'In Progress',
  },
  'pending-parts': {
    bg: 'bg-orange-500/10',
    text: 'text-orange-400',
    dot: 'bg-orange-400',
    label: 'Pending Parts',
  },
  resolved: {
    bg: 'bg-green-500/10',
    text: 'text-green-400',
    dot: 'bg-green-400',
    label: 'Resolved',
  },
  closed: {
    bg: 'bg-slate-500/10',
    text: 'text-slate-400',
    dot: 'bg-slate-400',
    label: 'Closed',
  },
  available: {
    bg: 'bg-cyan-500/10',
    text: 'text-cyan-400',
    dot: 'bg-cyan-400',
    label: 'Available',
  },
  assigned: {
    bg: 'bg-blue-500/10',
    text: 'text-blue-400',
    dot: 'bg-blue-400',
    label: 'Assigned',
  },
};

interface StatusBadgeProps {
  status: StatusVariant;
  showDot?: boolean;
  size?: 'sm' | 'md';
}

export default function StatusBadge({
  status,
  showDot = true,
  size = 'sm',
}: StatusBadgeProps) {
  const v = variantMap[status] ?? variantMap['operational'];
  const sizeClass = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-medium ${v.bg} ${v.text} ${sizeClass}`}
    >
      {showDot && (
        <span className={`w-1.5 h-1.5 rounded-full ${v.dot}`} />
      )}
      {v.label}
    </span>
  );
}