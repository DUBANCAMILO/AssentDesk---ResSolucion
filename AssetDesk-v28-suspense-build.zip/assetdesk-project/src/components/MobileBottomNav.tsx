'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Bell, ClipboardList, QrCode, Settings, Wrench } from 'lucide-react';

const items = [
  { href: '/tecnico', label: 'Escanear', icon: QrCode },
  { href: '/', label: 'Inventario', icon: ClipboardList },
  { href: '/mantenimientos', label: 'Mantenimientos', icon: Wrench },
  { href: '/notificaciones', label: 'Alertas', icon: Bell },
  { href: '/configuracion', label: 'Config.', icon: Settings },
];

export default function MobileBottomNav() {
  const pathname = usePathname();

  return (
    <nav
      aria-label="Navegación móvil"
      className="fixed inset-x-0 bottom-0 z-40 flex h-[calc(4.25rem+env(safe-area-inset-bottom))] items-start justify-around border-t border-border bg-card/95 px-1 pt-2 pb-[env(safe-area-inset-bottom)] shadow-[0_-8px_24px_rgba(0,0,0,.24)] backdrop-blur md:hidden"
    >
      {items.map(({ href, label, icon: Icon }) => {
        const active = href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`);
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? 'page' : undefined}
            className={`flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1 text-[10px] font-medium transition-colors ${
              active ? 'text-primary' : 'text-muted-foreground'
            }`}
          >
            <span className={`rounded-xl px-3 py-1 ${active ? 'bg-primary/15' : ''}`}>
              <Icon size={19} strokeWidth={active ? 2.4 : 1.8} />
            </span>
            <span className="truncate">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
