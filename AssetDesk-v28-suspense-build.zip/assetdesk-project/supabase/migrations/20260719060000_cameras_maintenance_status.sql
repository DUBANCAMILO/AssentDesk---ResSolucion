-- Migration: cameras/DVR table, maintenance schedules, asset status labels
-- Idempotent

-- ─── Cameras / DVR table ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.cameras (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL,
  placa TEXT,
  marca TEXT,
  modelo TEXT,
  tipo TEXT DEFAULT 'IP',           -- IP, Analógica, PTZ, DVR, NVR, Domo, Bala, etc.
  serial TEXT,
  mac_address TEXT,
  direccion_ip TEXT,
  subred TEXT DEFAULT '255.255.255.0',
  gateway TEXT DEFAULT '192.168.1.1',
  dns_primario TEXT DEFAULT '8.8.8.8',
  dns_secundario TEXT DEFAULT '8.8.4.4',
  puerto TEXT,
  canal_dvr TEXT,
  dvr_nvr_asociado TEXT,
  resolucion TEXT,
  fps TEXT,
  vision_nocturna TEXT DEFAULT 'SI',
  angulo_vision TEXT,
  almacenamiento TEXT,
  dias_grabacion TEXT,
  area TEXT,
  sede TEXT,
  ubicacion TEXT,
  usuario_responsable TEXT,
  tecnico_instalador TEXT,
  proveedor TEXT,
  orden_compra TEXT,
  garantia_vencimiento DATE,
  garantia_tipo TEXT,
  status TEXT DEFAULT 'operational' CHECK (status IN ('operational','maintenance','critical','decommissioned')),
  en_red TEXT DEFAULT 'SI',
  observaciones TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Maintenance schedules ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.maintenance_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_type TEXT NOT NULL DEFAULT 'asset',  -- 'asset', 'printer', 'camera'
  asset_id UUID NOT NULL,
  asset_name TEXT,
  asset_placa TEXT,
  tipo_mantenimiento TEXT NOT NULL,          -- Preventivo, Correctivo, Limpieza, Calibración, etc.
  descripcion TEXT,
  fecha_programada DATE NOT NULL,
  fecha_realizado DATE,
  tecnico_asignado TEXT,
  estado TEXT DEFAULT 'pendiente' CHECK (estado IN ('pendiente','en_proceso','completado','cancelado')),
  prioridad TEXT DEFAULT 'media' CHECK (prioridad IN ('baja','media','alta','critica')),
  costo_estimado NUMERIC(10,2),
  costo_real NUMERIC(10,2),
  observaciones TEXT,
  alerta_enviada BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Asset status labels (visual tags) ──────────────────────────────────────
-- Add label column to assets if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'assets' AND column_name = 'etiqueta_estado'
  ) THEN
    ALTER TABLE public.assets ADD COLUMN etiqueta_estado TEXT DEFAULT NULL;
  END IF;
END $$;

-- Add label column to printers if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'printers' AND column_name = 'etiqueta_estado'
  ) THEN
    ALTER TABLE public.printers ADD COLUMN etiqueta_estado TEXT DEFAULT NULL;
  END IF;
END $$;

-- Add maintenance date columns to assets if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'assets' AND column_name = 'proximo_mantenimiento'
  ) THEN
    ALTER TABLE public.assets ADD COLUMN proximo_mantenimiento DATE DEFAULT NULL;
  END IF;
END $$;

-- ─── RLS ────────────────────────────────────────────────────────────────────
ALTER TABLE public.cameras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maintenance_schedules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cameras_all" ON public.cameras;
CREATE POLICY "cameras_all" ON public.cameras FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "maintenance_all" ON public.maintenance_schedules;
CREATE POLICY "maintenance_all" ON public.maintenance_schedules FOR ALL USING (true) WITH CHECK (true);

-- ─── Notify schema cache reload ─────────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
