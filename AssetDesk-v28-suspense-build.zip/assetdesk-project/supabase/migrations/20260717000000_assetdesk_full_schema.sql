-- AssetDesk Full Schema Migration
-- Tables: assets, asset_history, bajas, ip_addresses, notifications, app_settings, technicians

-- ============================================================
-- TYPES
-- ============================================================
DROP TYPE IF EXISTS public.asset_status CASCADE;
CREATE TYPE public.asset_status AS ENUM ('operational', 'critical', 'maintenance', 'decommissioned');

DROP TYPE IF EXISTS public.baja_motivo CASCADE;
CREATE TYPE public.baja_motivo AS ENUM ('obsolescencia', 'daño_irreparable', 'robo_perdida', 'donacion', 'fin_vida_util');

DROP TYPE IF EXISTS public.baja_disposicion CASCADE;
CREATE TYPE public.baja_disposicion AS ENUM ('almacenado', 'donado', 'destruido', 'en_proceso');

DROP TYPE IF EXISTS public.ip_status CASCADE;
CREATE TYPE public.ip_status AS ENUM ('ocupada', 'disponible', 'reservada');

DROP TYPE IF EXISTS public.notification_type CASCADE;
CREATE TYPE public.notification_type AS ENUM ('critical', 'warning', 'info', 'success');

DROP TYPE IF EXISTS public.history_event_type CASCADE;
CREATE TYPE public.history_event_type AS ENUM ('assigned', 'maintenance', 'component_change', 'status_change', 'baja', 'reactivated', 'created', 'updated');

-- ============================================================
-- CORE TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS public.technicians (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL,
  email TEXT,
  telefono TEXT,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Identification
  placa TEXT UNIQUE,
  tag TEXT,
  serial TEXT,
  n_ficha TEXT,
  sede TEXT,
  -- Equipment
  marca TEXT,
  modelo TEXT,
  n_producto TEXT,
  tipo_equipo TEXT DEFAULT 'Desktop',
  -- OS
  sistema_operativo TEXT,
  service_pack TEXT,
  idioma TEXT DEFAULT 'ESP',
  arquitectura TEXT DEFAULT 'x64',
  licencia_os TEXT,
  -- CPU
  procesador_marca TEXT,
  procesador_tipo TEXT,
  procesador_velocidad TEXT,
  -- RAM
  ram_capacidad TEXT,
  ram_tipo TEXT DEFAULT 'DDR4',
  ram_slot TEXT,
  -- Storage
  disco_capacidad TEXT,
  disco_tecnologia TEXT DEFAULT 'SSD',
  -- Optical
  unidad_optica TEXT DEFAULT 'NO',
  unidad_marca TEXT,
  -- Peripherals
  teclado_marca TEXT,
  mouse_marca TEXT,
  web_cam TEXT DEFAULT 'NO',
  -- Monitor
  monitor_marca TEXT,
  monitor_modelo TEXT,
  monitor_tipo TEXT DEFAULT 'LCD',
  monitor_tamano TEXT,
  monitor_serial TEXT,
  -- Printer
  impresora_marca TEXT,
  impresora_tipo TEXT,
  impresora_serial TEXT,
  impresora_modelo TEXT,
  impresora_mac TEXT,
  -- Network
  nombre_equipo TEXT,
  en_red TEXT DEFAULT 'SI',
  direccion_ip TEXT,
  mac_address TEXT,
  subred TEXT DEFAULT '255.255.255.0',
  gateway TEXT DEFAULT '192.168.1.1',
  dns_primario TEXT,
  dns_secundario TEXT,
  puerto_switch TEXT,
  -- Assignment
  usuario_responsable TEXT,
  area TEXT,
  ubicacion TEXT,
  fecha_asignacion DATE,
  tecnico_instalador TEXT,
  -- Additional modern fields
  numero_inventario_anterior TEXT,
  garantia_vencimiento DATE,
  proveedor TEXT,
  valor_compra DECIMAL(12,2),
  fecha_compra DATE,
  -- Software
  office_version TEXT,
  antivirus TEXT,
  software_adicional TEXT,
  -- GPU
  gpu_marca TEXT,
  gpu_modelo TEXT,
  gpu_vram TEXT,
  -- Battery (for laptops)
  bateria_estado TEXT,
  -- Photo
  foto_url TEXT,
  -- Status & Notes
  status public.asset_status DEFAULT 'operational',
  observaciones TEXT,
  recomendaciones TEXT,
  has_qr BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.asset_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID REFERENCES public.assets(id) ON DELETE CASCADE,
  event_type public.history_event_type DEFAULT 'updated',
  description TEXT NOT NULL,
  by_user TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.bajas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  -- Snapshot of asset at time of baja
  placa TEXT,
  tag TEXT,
  brand TEXT,
  model TEXT,
  serial TEXT,
  cpu TEXT,
  ram TEXT,
  storage TEXT,
  os TEXT,
  location TEXT,
  last_user TEXT,
  area TEXT,
  -- Baja details
  fecha_baja DATE DEFAULT CURRENT_DATE,
  motivo_baja public.baja_motivo NOT NULL,
  tecnico_responsable TEXT,
  observaciones TEXT,
  disposicion public.baja_disposicion DEFAULT 'en_proceso',
  acta_numero TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.ip_addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  direccion_ip TEXT NOT NULL UNIQUE,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  nombre TEXT,
  area TEXT,
  tipo_dispositivo TEXT DEFAULT 'PC',
  mac_address TEXT,
  subred TEXT DEFAULT '255.255.255.0',
  gateway TEXT DEFAULT '192.168.1.1',
  dns_primario TEXT,
  dns_secundario TEXT,
  puerto_switch TEXT,
  tipo_asignacion TEXT DEFAULT 'estatica',
  status public.ip_status DEFAULT 'disponible',
  observaciones TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type public.notification_type DEFAULT 'info',
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.app_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE,
  value TEXT,
  label TEXT,
  description TEXT,
  category TEXT DEFAULT 'general',
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_assets_placa ON public.assets(placa);
CREATE INDEX IF NOT EXISTS idx_assets_status ON public.assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_area ON public.assets(area);
CREATE INDEX IF NOT EXISTS idx_asset_history_asset_id ON public.asset_history(asset_id);
CREATE INDEX IF NOT EXISTS idx_bajas_motivo ON public.bajas(motivo_baja);
CREATE INDEX IF NOT EXISTS idx_bajas_disposicion ON public.bajas(disposicion);
CREATE INDEX IF NOT EXISTS idx_ip_status ON public.ip_addresses(status);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON public.notifications(read);

-- ============================================================
-- FUNCTIONS
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- ============================================================
-- RLS
-- ============================================================
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bajas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ip_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technicians ENABLE ROW LEVEL SECURITY;

-- Open access policies (IT admin app - all authenticated or public)
DROP POLICY IF EXISTS "open_access_assets" ON public.assets;
CREATE POLICY "open_access_assets" ON public.assets FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_asset_history" ON public.asset_history;
CREATE POLICY "open_access_asset_history" ON public.asset_history FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_bajas" ON public.bajas;
CREATE POLICY "open_access_bajas" ON public.bajas FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_ip_addresses" ON public.ip_addresses;
CREATE POLICY "open_access_ip_addresses" ON public.ip_addresses FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_notifications" ON public.notifications;
CREATE POLICY "open_access_notifications" ON public.notifications FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_app_settings" ON public.app_settings;
CREATE POLICY "open_access_app_settings" ON public.app_settings FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "open_access_technicians" ON public.technicians;
CREATE POLICY "open_access_technicians" ON public.technicians FOR ALL TO public USING (true) WITH CHECK (true);

-- ============================================================
-- TRIGGERS
-- ============================================================
DROP TRIGGER IF EXISTS assets_updated_at ON public.assets;
CREATE TRIGGER assets_updated_at BEFORE UPDATE ON public.assets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS bajas_updated_at ON public.bajas;
CREATE TRIGGER bajas_updated_at BEFORE UPDATE ON public.bajas
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS ip_updated_at ON public.ip_addresses;
CREATE TRIGGER ip_updated_at BEFORE UPDATE ON public.ip_addresses
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============================================================
-- DEFAULT SETTINGS
-- ============================================================
INSERT INTO public.app_settings (key, value, label, description, category) VALUES
  ('org_name', 'Mi Organización', 'Nombre de la Organización', 'Nombre que aparece en reportes y fichas', 'general'),
  ('org_address', '', 'Dirección', 'Dirección física de la organización', 'general'),
  ('org_phone', '', 'Teléfono', 'Teléfono de contacto', 'general'),
  ('org_email', '', 'Email', 'Email de contacto TI', 'general'),
  ('default_subnet', '255.255.255.0', 'Máscara de Subred por Defecto', 'Máscara usada al registrar nuevos equipos', 'network'),
  ('default_gateway', '192.168.1.1', 'Gateway por Defecto', 'Puerta de enlace predeterminada', 'network'),
  ('default_dns_primary', '8.8.8.8', 'DNS Primario por Defecto', 'Servidor DNS primario', 'network'),
  ('default_dns_secondary', '8.8.4.4', 'DNS Secundario por Defecto', 'Servidor DNS secundario', 'network'),
  ('ip_range_start', '192.168.1.1', 'IP Inicio de Rango', 'Primera IP del rango de red', 'network'),
  ('ip_range_end', '192.168.1.254', 'IP Fin de Rango', 'Última IP del rango de red', 'network'),
  ('notify_critical', 'true', 'Notificar Equipos Críticos', 'Enviar alerta cuando un equipo pase a estado crítico', 'notifications'),
  ('notify_maintenance', 'true', 'Notificar Mantenimiento', 'Enviar alerta cuando un equipo entre en mantenimiento', 'notifications'),
  ('ticket_prefix', 'TKT', 'Prefijo de Ticket', 'Prefijo para numeración de tickets', 'tickets'),
  ('asset_prefix', 'INV', 'Prefijo de Inventario', 'Prefijo para placas de inventario', 'inventory'),
  ('qr_base_url', '', 'URL Base para QR', 'URL base para los códigos QR de activos', 'inventory')
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- TECHNICIANS SEED
-- ============================================================
INSERT INTO public.technicians (nombre, email, telefono) VALUES
  ('Téc. Ramírez', 'ramirez@ti.local', ''),
  ('Téc. López', 'lopez@ti.local', ''),
  ('Admin TI', 'admin@ti.local', '')
ON CONFLICT DO NOTHING;

-- ============================================================
-- MOCK ASSETS
-- ============================================================
DO $$
DECLARE
  a1 UUID := gen_random_uuid();
  a2 UUID := gen_random_uuid();
  a3 UUID := gen_random_uuid();
  a4 UUID := gen_random_uuid();
  a5 UUID := gen_random_uuid();
BEGIN
  INSERT INTO public.assets (
    id, placa, tag, serial, sede, marca, modelo, tipo_equipo,
    procesador_marca, procesador_tipo, procesador_velocidad,
    ram_capacidad, ram_tipo, disco_capacidad, disco_tecnologia,
    sistema_operativo, direccion_ip, mac_address, subred, gateway,
    usuario_responsable, area, ubicacion, fecha_asignacion, tecnico_instalador,
    monitor_marca, monitor_modelo, monitor_tamano, teclado_marca, mouse_marca,
    status, has_qr, observaciones
  ) VALUES
    (a1, 'INV-2024-001', 'AST-2024-001', 'DL7090X3821', 'Sede Principal',
     'Dell', 'OptiPlex 7090', 'Desktop',
     'Intel', 'Core i7-10700', '2.9 GHz',
     '16 GB', 'DDR4', '512 GB', 'NVMe SSD',
     'Windows 11 Pro', '192.168.1.45', 'DC:A6:32:11:22:33', '255.255.255.0', '192.168.1.1',
     'María García', 'Administración', 'Piso 2 — Oficina 204', '2024-03-15', 'Téc. Ramírez',
     'Dell', 'P2422H', '24', 'Dell', 'Dell',
     'operational', true, ''),
    (a2, 'INV-2024-002', 'AST-2024-002', 'HP800G6K2291', 'Sede Principal',
     'HP', 'EliteDesk 800 G6', 'Desktop',
     'Intel', 'Core i5-10500', '3.1 GHz',
     '8 GB', 'DDR4', '256 GB', 'SATA SSD',
     'Windows 10 Pro', '192.168.1.62', 'DC:A6:32:44:55:66', '255.255.255.0', '192.168.1.1',
     'Luis Fernández', 'Contabilidad', 'Piso 1 — Oficina 102', '2024-01-10', 'Téc. Ramírez',
     'HP', 'V24i', '24', 'HP', 'HP',
     'critical', true, 'Falla en fuente de poder detectada.'),
    (a3, 'INV-2024-003', 'AST-2024-003', 'LNV720QP9934', 'Sede Principal',
     'Lenovo', 'ThinkCentre M720q', 'Desktop',
     'Intel', 'Core i5-8500T', '2.1 GHz',
     '16 GB', 'DDR4', '1 TB', 'HDD',
     'Ubuntu 22.04 LTS', '192.168.1.78', 'DC:A6:32:77:88:99', '255.255.255.0', '192.168.1.1',
     'Sin asignar', 'TI / Sistemas', 'Piso 3 — Sala de Servidores', '2023-11-05', 'Téc. López',
     'Lenovo', 'ThinkVision T24i', '24', 'Lenovo', 'Lenovo',
     'maintenance', true, 'Reemplazo de HDD en progreso.'),
    (a4, 'INV-2024-004', 'AST-2024-004', 'APMMM2C0041', 'Sede Principal',
     'Apple', 'Mac Mini M2', 'Mini PC',
     'Apple', 'M2 8-core', '3.5 GHz',
     '16 GB', 'Unified Memory', '512 GB', 'NVMe SSD',
     'macOS Ventura 13.5', '192.168.1.91', 'A4:C3:F0:AA:BB:CC', '255.255.255.0', '192.168.1.1',
     'Ana Rodríguez', 'Diseño', 'Piso 2 — Lab Diseño', '2024-05-20', 'Téc. Ramírez',
     'Apple', 'Studio Display', '27', 'Apple', 'Apple',
     'operational', true, ''),
    (a5, 'INV-2024-005', 'AST-2024-005', 'DLP3660B7712', 'Sede Principal',
     'Dell', 'Precision 3660', 'Workstation',
     'Intel', 'Xeon W-1370', '2.8 GHz',
     '32 GB', 'ECC DDR4', '2 TB', 'NVMe SSD',
     'Windows 11 Pro for Workstations', '192.168.1.110', 'DC:A6:32:DD:EE:FF', '255.255.255.0', '192.168.1.1',
     'Jorge Morales', 'Producción', 'Piso 3 — Render Farm', '2024-02-28', 'Téc. López',
     'Dell', 'U2722D', '27', 'Dell', 'Dell',
     'operational', true, '')
  ON CONFLICT (placa) DO NOTHING;

  -- Asset history
  INSERT INTO public.asset_history (asset_id, event_type, description, by_user) VALUES
    (a1, 'created', 'Equipo registrado en inventario', 'Admin'),
    (a1, 'assigned', 'Asignación inicial a María García', 'Admin'),
    (a1, 'component_change', 'RAM actualizada de 8 GB a 16 GB DDR4', 'Téc. Ramírez'),
    (a2, 'created', 'Equipo registrado en inventario', 'Admin'),
    (a2, 'assigned', 'Asignado a Luis Fernández', 'Admin'),
    (a2, 'status_change', 'Estado cambiado a Crítico — falla en PSU detectada', 'Téc. Ramírez'),
    (a3, 'created', 'Equipo registrado en inventario', 'Admin'),
    (a3, 'maintenance', 'Reemplazo de HDD en progreso', 'Téc. López'),
    (a4, 'created', 'Equipo registrado en inventario', 'Admin'),
    (a4, 'assigned', 'Asignado a Lab Diseño — Ana Rodríguez', 'Admin'),
    (a5, 'created', 'Equipo registrado en inventario', 'Admin'),
    (a5, 'component_change', 'Agregado segundo NVMe de 1 TB', 'Téc. Ramírez')
  ON CONFLICT DO NOTHING;

  -- Notifications
  INSERT INTO public.notifications (title, message, type, asset_id) VALUES
    ('Equipo Crítico', 'HP EliteDesk 800 G6 (INV-2024-002) reporta falla en fuente de poder', 'critical', a2),
    ('Mantenimiento Activo', 'Lenovo ThinkCentre M720q (INV-2024-003) en mantenimiento — reemplazo de HDD', 'warning', a3),
    ('Equipo Registrado', 'Dell Precision 3660 (INV-2024-005) agregado al inventario', 'success', a5)
  ON CONFLICT DO NOTHING;

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Mock data error: %', SQLERRM;
END $$;

-- Mock Bajas
DO $$
BEGIN
  INSERT INTO public.bajas (placa, tag, brand, model, serial, cpu, ram, storage, os, location, last_user, area, fecha_baja, motivo_baja, tecnico_responsable, observaciones, disposicion) VALUES
    ('INV-2019-045', 'AST-2019-045', 'HP', 'ProDesk 400 G4', 'HP400G4A1122', 'Intel Core i3-7100', '4 GB DDR4', '500 GB HDD', 'Windows 7 Pro', 'Piso 1 — Bodega', 'Pedro Jiménez', 'Contabilidad', '2026-03-15', 'obsolescencia', 'Téc. Ramírez', 'Equipo sin soporte de SO. No arranca correctamente.', 'almacenado'),
    ('INV-2018-012', 'AST-2018-012', 'Dell', 'OptiPlex 3050', 'DL3050B2234', 'Intel Core i5-7500', '8 GB DDR4', '256 GB SSD', 'Windows 10 Pro', 'Piso 2 — Archivo', 'Sin asignar', 'Archivo General', '2026-01-20', 'daño_irreparable', 'Téc. López', 'Tarjeta madre quemada. Reparación no es costo-efectiva.', 'destruido'),
    ('INV-2020-078', 'AST-2020-078', 'Lenovo', 'ThinkCentre M720', 'LNV720M5567', 'Intel Core i5-8400', '8 GB DDR4', '1 TB HDD', 'Windows 10 Pro', 'Piso 3 — Sala Reuniones', 'Ana Vargas', 'Gerencia', '2026-05-10', 'fin_vida_util', 'Téc. Ramírez', 'Ciclo de vida completado. 6 años en servicio.', 'donado')
  ON CONFLICT DO NOTHING;

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Bajas mock data error: %', SQLERRM;
END $$;

-- Mock IP Addresses
DO $$
BEGIN
  INSERT INTO public.ip_addresses (direccion_ip, nombre, area, tipo_dispositivo, mac_address, subred, gateway, tipo_asignacion, status) VALUES
    ('192.168.1.1', 'Router Principal', 'Infraestructura', 'Router', 'AA:BB:CC:00:00:01', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada'),
    ('192.168.1.2', 'Switch Core', 'Infraestructura', 'Switch', 'AA:BB:CC:00:00:02', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada'),
    ('192.168.1.10', 'Servidor Principal', 'TI / Sistemas', 'Servidor', 'AA:BB:CC:00:00:10', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada'),
    ('192.168.1.45', 'PC-ADMIN-204', 'Administración', 'PC', 'DC:A6:32:11:22:33', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada'),
    ('192.168.1.62', 'PC-CONT-102', 'Contabilidad', 'PC', 'DC:A6:32:44:55:66', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada'),
    ('192.168.1.100', NULL, NULL, 'PC', NULL, '255.255.255.0', '192.168.1.1', 'dinamica', 'disponible'),
    ('192.168.1.101', NULL, NULL, 'PC', NULL, '255.255.255.0', '192.168.1.1', 'dinamica', 'disponible'),
    ('192.168.1.200', 'Impresora Recepción', 'Recepción', 'Impresora', 'BB:CC:DD:00:00:01', '255.255.255.0', '192.168.1.1', 'estatica', 'ocupada')
  ON CONFLICT (direccion_ip) DO NOTHING;

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'IP mock data error: %', SQLERRM;
END $$;
