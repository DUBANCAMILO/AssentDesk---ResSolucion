-- Migration: Add new tech fields to assets and create wifi_networks table
-- Safe: uses ADD COLUMN IF NOT EXISTS and CREATE TABLE IF NOT EXISTS

-- ── New asset columns ────────────────────────────────────────────────────────
ALTER TABLE public.assets
  ADD COLUMN IF NOT EXISTS procesador_nucleos TEXT,
  ADD COLUMN IF NOT EXISTS procesador_generacion TEXT,
  ADD COLUMN IF NOT EXISTS ram_slots_totales TEXT,
  ADD COLUMN IF NOT EXISTS ram_slots_libres TEXT,
  ADD COLUMN IF NOT EXISTS disco_interfaz TEXT,
  ADD COLUMN IF NOT EXISTS disco_rpm TEXT,
  ADD COLUMN IF NOT EXISTS disco2_capacidad TEXT,
  ADD COLUMN IF NOT EXISTS disco2_tecnologia TEXT,
  ADD COLUMN IF NOT EXISTS gpu_tipo TEXT,
  ADD COLUMN IF NOT EXISTS display_tamano TEXT,
  ADD COLUMN IF NOT EXISTS display_resolucion TEXT,
  ADD COLUMN IF NOT EXISTS display_tipo TEXT,
  ADD COLUMN IF NOT EXISTS display_frecuencia TEXT,
  ADD COLUMN IF NOT EXISTS display_tactil TEXT DEFAULT 'NO',
  ADD COLUMN IF NOT EXISTS bateria_ciclos TEXT,
  ADD COLUMN IF NOT EXISTS bateria_capacidad TEXT,
  ADD COLUMN IF NOT EXISTS bateria_modelo TEXT,
  ADD COLUMN IF NOT EXISTS firmware_version TEXT,
  ADD COLUMN IF NOT EXISTS bios_version TEXT,
  ADD COLUMN IF NOT EXISTS tpm_version TEXT,
  ADD COLUMN IF NOT EXISTS secure_boot TEXT,
  ADD COLUMN IF NOT EXISTS puertos_usb TEXT,
  ADD COLUMN IF NOT EXISTS puertos_usb_c TEXT,
  ADD COLUMN IF NOT EXISTS puertos_hdmi TEXT,
  ADD COLUMN IF NOT EXISTS puertos_thunderbolt TEXT,
  ADD COLUMN IF NOT EXISTS lector_tarjetas TEXT DEFAULT 'NO',
  ADD COLUMN IF NOT EXISTS bluetooth TEXT,
  ADD COLUMN IF NOT EXISTS wifi_estandar TEXT,
  ADD COLUMN IF NOT EXISTS garantia_tipo TEXT,
  ADD COLUMN IF NOT EXISTS orden_compra TEXT;

-- ── WiFi Networks table ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.wifi_networks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL,
  ssid TEXT NOT NULL,
  password TEXT,
  seguridad TEXT NOT NULL DEFAULT 'WPA2',
  banda TEXT NOT NULL DEFAULT '2.4 GHz',
  canal TEXT,
  velocidad_max TEXT,
  router_marca TEXT,
  router_modelo TEXT,
  router_ip TEXT,
  area TEXT,
  sede TEXT,
  status TEXT NOT NULL DEFAULT 'activa',
  observaciones TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.wifi_networks ENABLE ROW LEVEL SECURITY;

-- RLS policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'wifi_networks' AND policyname = 'wifi_networks_select'
  ) THEN
    CREATE POLICY wifi_networks_select ON public.wifi_networks FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'wifi_networks' AND policyname = 'wifi_networks_insert'
  ) THEN
    CREATE POLICY wifi_networks_insert ON public.wifi_networks FOR INSERT WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'wifi_networks' AND policyname = 'wifi_networks_update'
  ) THEN
    CREATE POLICY wifi_networks_update ON public.wifi_networks FOR UPDATE USING (true) WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'wifi_networks' AND policyname = 'wifi_networks_delete'
  ) THEN
    CREATE POLICY wifi_networks_delete ON public.wifi_networks FOR DELETE USING (true);
  END IF;
END $$;

-- Updated_at trigger for wifi_networks
CREATE OR REPLACE FUNCTION public.update_wifi_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS wifi_networks_updated_at ON public.wifi_networks;
CREATE TRIGGER wifi_networks_updated_at
  BEFORE UPDATE ON public.wifi_networks
  FOR EACH ROW EXECUTE FUNCTION public.update_wifi_updated_at();
