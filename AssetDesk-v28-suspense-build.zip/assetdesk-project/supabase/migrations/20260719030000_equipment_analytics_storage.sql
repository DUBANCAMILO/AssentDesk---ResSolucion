-- ============================================================
-- Equipment Management, Analytics & Storage Setup
-- ============================================================

-- Create asset-photos storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'asset-photos',
  'asset-photos',
  true,
  2097152, -- 2MB max (images compressed client-side before upload)
  ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 2097152,
  allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];

-- Storage RLS policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'asset_photos_public_read'
  ) THEN
    CREATE POLICY "asset_photos_public_read" ON storage.objects
      FOR SELECT USING (bucket_id = 'asset-photos');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'asset_photos_insert'
  ) THEN
    CREATE POLICY "asset_photos_insert" ON storage.objects
      FOR INSERT WITH CHECK (bucket_id = 'asset-photos');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'asset_photos_update'
  ) THEN
    CREATE POLICY "asset_photos_update" ON storage.objects
      FOR UPDATE USING (bucket_id = 'asset-photos');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'asset_photos_delete'
  ) THEN
    CREATE POLICY "asset_photos_delete" ON storage.objects
      FOR DELETE USING (bucket_id = 'asset-photos');
  END IF;
END $$;

-- Add equipment_groups table for Equipment Management
CREATE TABLE IF NOT EXISTS public.equipment_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL,
  descripcion TEXT,
  tipo TEXT DEFAULT 'general',
  responsable TEXT,
  area TEXT,
  sede TEXT,
  color TEXT DEFAULT '#6366f1',
  icono TEXT DEFAULT 'monitor',
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.equipment_groups ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'equipment_groups' AND policyname = 'equipment_groups_all'
  ) THEN
    CREATE POLICY "equipment_groups_all" ON public.equipment_groups FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;

-- Add group_id to assets if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'assets' AND column_name = 'group_id'
  ) THEN
    ALTER TABLE public.assets ADD COLUMN group_id UUID REFERENCES public.equipment_groups(id) ON DELETE SET NULL;
  END IF;
END $$;
