-- Migration: Force PostgREST schema cache reload for printers table
-- Timestamp: 20260719050000

-- The printers table exists but PostgREST schema cache may not have picked it up.
-- This migration ensures the schema is refreshed by notifying PostgREST.

-- Ensure the printers table is properly registered by re-applying RLS
ALTER TABLE public.printers ENABLE ROW LEVEL SECURITY;

-- Re-create policy idempotently to trigger schema refresh
DROP POLICY IF EXISTS "printers_all_access" ON public.printers;
CREATE POLICY "printers_all_access" ON public.printers FOR ALL USING (true) WITH CHECK (true);

-- Notify PostgREST to reload schema cache
NOTIFY pgrst, 'reload schema';
