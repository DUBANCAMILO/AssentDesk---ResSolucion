-- AssetDesk: campos de formularios institucionales de baja y traslado
-- Esta migración es aditiva y no elimina columnas existentes.
-- Revisar RLS de producción antes de aplicar en un entorno real.

ALTER TABLE public.bajas
  ADD COLUMN IF NOT EXISTS reporte_no TEXT,
  ADD COLUMN IF NOT EXISTS cantidad INTEGER DEFAULT 1,
  ADD COLUMN IF NOT EXISTS ubicacion TEXT,
  ADD COLUMN IF NOT EXISTS valoracion_tecnica TEXT,
  ADD COLUMN IF NOT EXISTS frecuencia_trabajo TEXT,
  ADD COLUMN IF NOT EXISTS factor_mantenimiento_correctivo BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS factor_repuestos_no_comerciales BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS factor_costo_reparacion_70 BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS factor_ciclo_vida BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS factor_hurto BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS factor_riesgo_usuario BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS responsable_analisis_nombre TEXT,
  ADD COLUMN IF NOT EXISTS firma_analisis_url TEXT,
  ADD COLUMN IF NOT EXISTS documento_url TEXT;

ALTER TABLE public.bajas
  DROP CONSTRAINT IF EXISTS bajas_frecuencia_trabajo_check;

ALTER TABLE public.bajas
  ADD CONSTRAINT bajas_frecuencia_trabajo_check
  CHECK (frecuencia_trabajo IS NULL OR frecuencia_trabajo IN (
    'continuo', 'semanal', 'mensual', 'una_vez_al_dia', 'esporadicamente'
  ));

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'transfer_status'
  ) THEN
    CREATE TYPE public.transfer_status AS ENUM ('borrador', 'pendiente', 'aprobado', 'rechazado', 'completado', 'cancelado');
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.traslados (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  traslado_no TEXT,
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  servicio_origen TEXT NOT NULL,
  servicio_destino TEXT NOT NULL,
  motivo TEXT,
  area_realiza TEXT,
  area_otro TEXT,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  nombre_bien TEXT NOT NULL,
  placa_inventario TEXT,
  cantidad INTEGER NOT NULL DEFAULT 1,
  marca TEXT,
  modelo TEXT,
  serial TEXT,
  estado TEXT CHECK (estado IS NULL OR estado IN ('bueno', 'regular', 'malo')),
  vobo_subgerencia BOOLEAN DEFAULT FALSE,
  firma_subgerencia_url TEXT,
  firma_servicio_origen_url TEXT,
  firma_servicio_destino_url TEXT,
  observaciones TEXT,
  documento_url TEXT,
  status public.transfer_status NOT NULL DEFAULT 'pendiente',
  created_by UUID,
  approved_by UUID,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_traslados_asset_id ON public.traslados(asset_id);
CREATE INDEX IF NOT EXISTS idx_traslados_fecha ON public.traslados(fecha);
CREATE INDEX IF NOT EXISTS idx_traslados_status ON public.traslados(status);
CREATE INDEX IF NOT EXISTS idx_traslados_placa ON public.traslados(placa_inventario);

ALTER TABLE public.traslados ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'traslados' AND policyname = 'traslados_all_access'
  ) THEN
    CREATE POLICY traslados_all_access ON public.traslados FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;

DROP TRIGGER IF EXISTS traslados_updated_at ON public.traslados;
CREATE TRIGGER traslados_updated_at
  BEFORE UPDATE ON public.traslados
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- PostgreSQL permite añadir el evento sin eliminar los valores anteriores.
ALTER TYPE public.history_event_type ADD VALUE IF NOT EXISTS 'transferred';

NOTIFY pgrst, 'reload schema';
