-- Fix: Restore asset_status enum and status column on assets table
-- The previous migration dropped the enum with CASCADE which removed the status column
-- from the already-existing assets table. This migration restores it safely.

-- Step 1: Recreate the enum type (safe - DROP IF EXISTS first)
DROP TYPE IF EXISTS public.asset_status CASCADE;
CREATE TYPE public.asset_status AS ENUM ('operational', 'critical', 'maintenance', 'decommissioned');

-- Step 2: Re-add the status column if it was dropped by CASCADE
ALTER TABLE public.assets
  ADD COLUMN IF NOT EXISTS status public.asset_status DEFAULT 'operational';

-- Step 3: Ensure the index on status exists
CREATE INDEX IF NOT EXISTS idx_assets_status ON public.assets(status);

-- Step 4: Restore default values for any rows that have NULL status
UPDATE public.assets SET status = 'operational' WHERE status IS NULL;
