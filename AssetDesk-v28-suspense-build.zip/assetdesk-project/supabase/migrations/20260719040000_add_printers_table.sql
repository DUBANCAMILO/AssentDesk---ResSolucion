-- Migration: Add printers table
-- Timestamp: 20260719040000

CREATE TABLE IF NOT EXISTS public.printers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  placa TEXT,
  nombre TEXT NOT NULL,
  marca TEXT,
  modelo TEXT,
  tipo TEXT,
  serial TEXT,
  mac_address TEXT,
  direccion_ip TEXT,
  subred TEXT DEFAULT '255.255.255.0',
  gateway TEXT DEFAULT '192.168.1.1',
  dns_primario TEXT,
  dns_secundario TEXT,
  puerto_switch TEXT,
  tipo_asignacion TEXT DEFAULT 'Estática',
  area TEXT,
  sede TEXT,
  ubicacion TEXT,
  usuario_responsable TEXT,
  tecnico_instalador TEXT,
  proveedor TEXT,
  orden_compra TEXT,
  garantia_vencimiento DATE,
  garantia_tipo TEXT,
  status TEXT DEFAULT 'operational' CHECK (status IN ('operational', 'maintenance', 'critical', 'decommissioned')),
  en_red TEXT DEFAULT 'SI',
  observaciones TEXT,
  foto_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS
ALTER TABLE public.printers ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'printers' AND policyname = 'printers_all_access'
  ) THEN
    CREATE POLICY printers_all_access ON public.printers FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS printers_updated_at ON public.printers;
CREATE TRIGGER printers_updated_at
  BEFORE UPDATE ON public.printers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
