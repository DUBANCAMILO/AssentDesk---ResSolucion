# AssetDesk — conexión web, móvil y base de datos

## Arquitectura confirmada

La web y el móvil deben usar el mismo proyecto de Supabase:

```text
Navegador web ───────┐
                     ├── Supabase Auth / PostgreSQL / Realtime / Storage
AssetDesk Field ─────┘
```

No se debe crear una base de datos distinta para el APK. Si ambos clientes apuntan al mismo `NEXT_PUBLIC_SUPABASE_URL`, verán los mismos activos, mantenimientos, técnicos, notificaciones, IPs, fotos e historial.

## Variables que deben coincidir

```env
NEXT_PUBLIC_SUPABASE_URL=https://TU-PROYECTO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=TU_CLAVE_ANON
NEXT_PUBLIC_SITE_URL=https://TU-DOMINIO
```

Estas variables deben configurarse en:

- entorno de despliegue web;
- build del APK si la app usa contenido local;
- configuración del proveedor de CI/CD.

Nunca se debe incluir una `service_role key` en el navegador ni en el APK.

## Sincronización

- Un cambio hecho en la web aparece en el móvil mediante consultas y Supabase Realtime.
- Un cambio hecho en el móvil aparece en la web usando la misma base.
- La vista de técnicos ya escucha cambios de técnicos y notificaciones.
- El caché local solo sirve para consultar activos prioritarios cuando no hay internet.
- Para crear o modificar datos sin conexión hace falta una cola persistente en IndexedDB; `localStorage` no debe ser la única cola de trabajo.

## Orden recomendado de base de datos

El repositorio contiene dos migraciones iniciales históricas. Para una instalación nueva se debe elegir una sola base inicial. La ruta recomendada es:

1. `20260717021314_assetdesk_schema_v2.sql`
2. `20260717030000_fix_assets_status_column.sql`
3. `20260719020000_add_tech_fields_and_wifi.sql`
4. `20260719030000_equipment_analytics_storage.sql`
5. `20260719040000_add_printers_table.sql`
6. `20260719050000_reload_schema_cache.sql`
7. `20260719060000_cameras_maintenance_status.sql`

`20260717000000_assetdesk_full_schema.sql` es una base inicial anterior. No se debe ejecutar junto con otra base inicial en una instalación limpia sin revisar diferencias.

## Datos existentes

Las migraciones crean estructura, funciones, índices y políticas; no necesariamente contienen los datos actuales. Para trasladar datos existentes se necesita:

1. exportar tablas desde el proyecto Supabase actual;
2. respaldar Storage, especialmente `asset-photos`;
3. crear la base destino con la misma estructura;
4. importar datos respetando UUID y relaciones;
5. verificar fotos, historiales y notificaciones;
6. probar Realtime y permisos.

## Seguridad pendiente

Las migraciones actuales tienen políticas abiertas para varias tablas. Antes de usar la app en producción, cambiar `USING (true)` y `WITH CHECK (true)` por políticas basadas en `auth.uid()` y roles. La conexión móvil debe autenticarse igual que la web y no debe confiar solo en que el APK sea privado.

## Prueba de conexión web/móvil

1. Registrar o editar un activo desde la web.
2. Abrir AssetDesk Field en el móvil.
3. Buscar el mismo activo por placa o escanear su QR.
4. Cambiar el estado desde el móvil.
5. Confirmar el cambio en la web.
6. Crear una notificación y verificar que aparezca en ambos clientes.
7. Desconectar el móvil, consultar el caché y luego reconectar.
8. Confirmar la fecha del último sincronizado.

## Decisión de implementación

La primera versión móvil debe ser conectada y usar el mismo Supabase que la web. Luego se añade offline completo mediante IndexedDB y una cola de sincronización con control de conflictos.
