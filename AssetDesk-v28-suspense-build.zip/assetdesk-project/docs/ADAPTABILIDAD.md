

---

# Actualización 1.1 — Mejoras de adaptabilidad web y móvil

## 26. Perspectiva adaptable

[[IMAGEN_RESPONSIVE]]

La aplicación debe conservar la misma información y cambiar la distribución según el dispositivo. El escritorio favorece administración y análisis; el móvil favorece velocidad, QR, mantenimiento y trabajo en campo; la tableta combina ambos.

### Escritorio

- Sidebar completo.
- Tablas amplias.
- Métricas y gráficas simultáneas.
- Paneles de actividad.
- Importación, reportes y configuración avanzada.

### Tableta

- Sidebar reducido o plegable.
- Tablas con menos columnas.
- Paneles en dos columnas.
- Formularios divididos por pasos.

### Móvil

- Navegación inferior.
- Tarjetas en lugar de tablas densas.
- Botón de escaneo QR visible.
- Filtros en panel deslizable.
- Ficha de activo por secciones.
- Acciones grandes y fáciles de tocar.
- Estado de conexión y última sincronización visibles.

## 27. Mejoras prioritarias

### P0 — experiencia y funcionamiento

1. Convertir todas las tablas móviles en tarjetas con acciones contextuales.
2. Mantener la navegación inferior en todos los módulos de campo.
3. Añadir un botón QR persistente en AssetDesk Field.
4. Mostrar siempre conexión, último sincronizado y operaciones pendientes.
5. Unificar validaciones de formularios web y móvil.
6. Evitar que un modal de escritorio se salga de la pantalla móvil.
7. Añadir estados de carga, vacío, error y reintento en cada módulo.
8. Mantener el mismo estado de datos mediante Supabase.

### P1 — calidad de uso

1. Búsqueda global optimizada para teclado móvil.
2. Filtros como hojas inferiores.
3. Fotos comprimidas antes de subir.
4. Paginación y carga progresiva.
5. Confirmaciones claras para bajas y cambios críticos.
6. Compartir ficha mediante menú nativo.
7. Modo oscuro y contraste alto.
8. Atajos QR desde el icono de la PWA.
9. Recordatorio de sincronización pendiente.
10. Diseño de formularios por pasos.

### P2 — producción

1. IndexedDB para cola offline.
2. Resolución de conflictos.
3. Notificaciones push.
4. Firma digital de mantenimiento.
5. Impresión Bluetooth.
6. Biometría.
7. Analítica de uso y errores.
8. Soporte iOS.

## 28. Mejoras de backend y datos

- Mantener Supabase como backend único.
- Revisar RLS antes de producción.
- Aplicar roles por operación.
- Suscribir activos y mantenimientos a Realtime.
- Implementar cola de operaciones offline.
- Añadir `updated_at`, `updated_by` y versión de registro.
- Comprimir fotos y limitar tamaño.
- Respaldar PostgreSQL y Storage.
- Separar desarrollo, pruebas y producción.
- Auditar migraciones y no ejecutar dos bases iniciales a la vez.

## 29. Mejoras visuales

- Sistema de colores único para estados.
- Tipografía y tamaños consistentes.
- Iconos con significado repetible.
- Menos información simultánea en móvil.
- Tablas completas solo donde haya espacio.
- Mensajes de error accionables.
- Panel de actividad en escritorio.
- Tarjetas resumidas en móvil.
- Indicador de sincronización visible.
- Diseño accesible para contraste y tamaño de texto.

## 30. Mejoras de calidad y producción

- Pruebas unitarias de validaciones y servicios.
- Pruebas de integración con Supabase.
- Pruebas en navegadores y Android.
- Pruebas con conexión lenta y sin conexión.
- Revisión de permisos de roles.
- Registro de errores.
- Checklist de despliegue.
- Versionado semántico.
- Pull Request obligatorio para cambios.
- Changelog por versión.

## 31. Resultado esperado

El resultado final debe ser una sola aplicación con dos presentaciones coordinadas:

- **AssetDesk Web:** administración, análisis, reportes y configuración.
- **AssetDesk Field:** operación móvil, QR, consulta, fotos y mantenimiento.

Ambas usan el mismo código de servicios y la misma base de datos; solo cambia la interfaz y el nivel de detalle apropiado para cada pantalla.
