# Impresión de ticket de activo

## Tamaño actual solicitado

El ticket de activo quedó configurado a:

- **Ancho:** 48 mm
- **Alto:** 56 mm
- **Orientación:** vertical
- **QR:** 26 mm
- **Contenido:** marca/modelo, placa, serial, IP, responsable y ubicación.

## Prueba

1. Abrir la ficha de un activo.
2. Elegir imprimir ticket.
3. Seleccionar la impresora térmica.
4. Configurar papel personalizado de 48 × 56 mm.
5. Desactivar “ajustar a página” si el controlador lo ofrece.
6. Verificar que no aplique márgenes adicionales.
7. Revisar QR, placa y serial.

El navegador y el controlador de la impresora pueden imponer márgenes. La prueba física con la impresora real es necesaria para ajustar escala, densidad y separación.
