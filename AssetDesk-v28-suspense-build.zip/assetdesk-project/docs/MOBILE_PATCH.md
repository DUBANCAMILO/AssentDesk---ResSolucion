# AssetDesk Field — parche móvil inicial

Este parche prepara la interfaz web para un uso móvil de técnicos sin cambiar la lógica de inventario ni la base de datos.

## Cambios incluidos

- Navegación inferior móvil con accesos a Escanear, Inventario, Mantenimientos, Alertas y Configuración.
- Sidebar administrativo oculto en pantallas pequeñas.
- Espacio inferior seguro para que la navegación no tape formularios ni fichas.
- Manifest PWA actualizado para iniciar en `/tecnico`.
- Atajos rápidos de la PWA para escanear e inventario.
- Idioma del documento HTML corregido a español.
- `capacitor.config.ts` inicial para empaquetar la vista de campo como `com.dubancamilo.assetdesk.field`.
- `docs/DATA_CONNECTION.md` con la conexión compartida web/móvil y el orden de migraciones.

## Antes de generar el APK

1. Definir si el APK cargará una versión web alojada o una exportación estática.
2. Si se usa exportación estática, revisar las rutas que dependen de Supabase SSR y moverlas a clientes del navegador o API segura.
3. Añadir las dependencias de Capacitor y generar la plataforma Android en un entorno con Android SDK.
4. Configurar permisos de cámara, almacenamiento y notificaciones.
5. Probar QR, fotos, PDF, compartir y modo offline en equipos reales.
6. Revisar autenticación y políticas RLS de Supabase antes de distribución.

## Alcance de este parche

Este es un primer cambio de interfaz y empaquetado. No incluye todavía una compilación APK ni publica cambios en GitHub. El repositorio conserva la lógica existente y la vista móvil de técnico.
