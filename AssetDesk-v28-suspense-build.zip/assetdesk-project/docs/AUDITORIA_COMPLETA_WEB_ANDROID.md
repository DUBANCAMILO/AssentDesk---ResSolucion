# AssetDesk — auditoría integral y prediseño de documentación

## 0. Alcance

Esta auditoría cubre:

- aplicación web Next.js;
- Supabase y persistencia;
- módulo técnico y cámara;
- QR y ficha pública del activo;
- IPs y sincronización bidireccional;
- bajas y traslados;
- notificaciones;
- PWA;
- Capacitor, Android e iOS;
- seguridad, errores, pruebas y operación.

El objetivo realista es eliminar errores conocidos, detectar fallos antes de producción y definir una matriz de aceptación. Ningún software puede prometer cero fallos sin probarlo en el Supabase, navegador, celular e impresora reales.

## 1. Estado verificado

### Completado en la versión de trabajo

- `npm run type-check` pasó en la prueba local reportada.
- `npm run build` generó correctamente las 18 rutas antes de los últimos cambios de auditoría.
- Se agregó búsqueda QR rápida sin cargar todo el inventario.
- La ficha del activo muestra primero los datos y carga el historial después.
- El QR impreso codifica la URL de la ficha, no solamente la placa.
- Ticket institucional configurado a 46 × 58 mm, con logo local y alto contraste.
- Botón flotante de escaneo en la vista técnico.
- Campanita con contador real, navegación y realtime.
- Referencias externas de branding retiradas del código.
- Bajas y traslados autollenados con impresión/guardado PDF desde el diálogo del navegador.
- Sincronización de IP después de obtener `asset_id`.

### Pendiente de verificar después de esta auditoría

1. Ejecutar nuevamente `npm run type-check`.
2. Ejecutar nuevamente `npm run build` con validación estricta.
3. Aplicar y comprobar la migración institucional en el Supabase correcto.
4. Probar datos reales, RLS y Realtime.
5. Probar cámara en Chrome Android y en Capacitor.
6. Probar la impresora física con 46 × 58 mm.
7. Generar el primer APK.
8. Probar iOS desde macOS/Xcode.

### Hallazgo de lint resuelto

La consola de tickets tenía numerosos avisos de formato Prettier y dos errores de regla real: una expresión ternaria usada como sentencia y una expresión regular con escape innecesario. Se corrigieron los dos errores de código. También se eliminaron tipos `any` y bloques `catch` vacíos de la sesión Supabase, se tipó el contexto de autenticación, se retiró un import sin uso y se reemplazaron imágenes directas por `AppImage` en la vista técnico. Prettier quedó como advertencia para que el formato no bloquee el build; `npm run format` queda disponible para formatear los archivos cuando Node/npm esté disponible en el equipo.

## 2. Arquitectura objetivo

```text
Web/PWA ───────────────┐
                       ├── Supabase Auth + PostgreSQL + Storage + Realtime
Android/Capacitor ────┤
                       └── mismo proyecto, mismas tablas, mismas fotos e historial

autoresponsabilidad:
- Web: administración, inventario, reportes y configuración.
- Técnico: QR, cámara, diagnóstico, fotos y mantenimiento.
- Administrador: todos los módulos, incluida la vista técnico.
```

## 3. Flujo QR optimizado

### Generación

1. El activo se guarda y recibe `id`.
2. Se genera un QR con la ruta de la ficha del activo.
3. El ticket incluye QR, placa, serial, IP, responsable, ubicación y marca.
4. Para escanear desde otro dispositivo, `NEXT_PUBLIC_SITE_URL` debe ser accesible desde ese dispositivo; `localhost` y una dirección `169.254.x.x` no son una base estable para uso móvil.
4. El tamaño institucional es 46 × 58 mm.
5. El logo se carga desde el paquete local, sin depender de un proveedor externo.

### Escaneo

1. El técnico pulsa el botón flotante o el botón principal.
2. El navegador solicita permiso de cámara.
3. Se conecta el stream cuando el elemento de video ya está renderizado.
4. `jsQR` analiza los cuadros de cámara.
5. Si el código contiene una ficha, se navega directamente.
6. Si contiene placa, serial, tag o ID, se consulta con búsquedas puntuales.
7. La ficha se muestra sin esperar el historial.
8. El historial se carga en segundo plano.
9. Si no hay conexión, se busca en caché local.
10. Si no existe el equipo, se ofrece búsqueda manual.

### Criterios de velocidad

- No llamar `getAll()` para resolver un QR puntual.
- No esperar historial antes de mostrar la ficha.
- Importar `jsQR` una vez por sesión de cámara.
- Detener intervalos y pistas al cerrar la cámara.
- Evitar generar PDF o QR de alta resolución hasta que el usuario lo solicite.
- Usar QR con margen y corrección de error suficiente para impresión térmica.

## 4. Manejo de excepciones

### Reglas obligatorias

- Toda llamada a Supabase debe comprobar `error`.
- La interfaz debe mostrar un mensaje entendible.
- No cerrar formularios si el guardado falló.
- No mostrar una lista vacía como si fuera una base sin datos cuando hubo error de red.
- No ocultar errores de migración.
- Los procesos de cámara deben capturar permisos denegados, dispositivo ocupado y contexto inseguro.
- Las descargas PDF deben capturar ventanas bloqueadas y fallos de generación.
- Las operaciones de IP deben ser idempotentes.
- Las operaciones de baja deben conservar snapshot e historial.
- Las operaciones de traslado deben poder repetirse sin duplicar silenciosamente el documento.

### Mensajes mínimos

- Sin conexión: `No hay conexión. Se mostrará la información disponible en caché.`
- Supabase no configurado: `Falta configurar la conexión de datos.`
- Permiso de cámara: `Autoriza la cámara para escanear el código.`
- IP ocupada: `La IP ya está vinculada a otro activo.`
- Documento: `No se pudo generar el documento. Verifica la ventana de impresión.`

## 5. Datos e integridad

### Activos

- `assets.id` es la referencia principal.
- La placa debe validarse para evitar duplicados.
- El serial debe advertir duplicados.
- El activo debe guardar fecha de actualización.
- Toda baja debe conservar snapshot.

### IP

- `ip_addresses.asset_id` vincula la IP al activo.
- Crear equipo con IP ocupa la IP.
- Cambiar equipo libera la anterior.
- Liberar desde red limpia el activo.
- Dar de baja libera la IP.
- Nunca se debe reemplazar una IP ocupada por otro activo sin confirmación.

### Bajas

- Número de reporte/acta.
- Fecha.
- Snapshot del equipo.
- Valoración técnica.
- Motivo y disposición.
- Factores institucionales.
- Responsable.
- Evidencia y documento PDF.

### Traslados

- Número de traslado.
- Origen y destino.
- Motivo.
- Área que realiza.
- Bien y snapshot.
- Estado físico.
- Visto bueno.
- Firmas.
- Historial anterior y nuevo.

## 6. Seguridad

### Situación actual

- El `anon key` puede estar en el cliente, como exige Supabase.
- No debe existir `service_role` en navegador, APK ni repositorio.
- Las políticas RLS históricas son demasiado abiertas para producción.
- El `AuthContext` existe como base, pero las rutas aún deben protegerse.

### Objetivo

Roles:

- Administrador: acceso total, incluida Vista Técnico.
- Técnico: QR, cámara, diagnóstico, fotos, mantenimientos y consulta.
- Consulta: lectura.
- Aprobador: bajas y traslados.

Antes de producción:

1. activar Supabase Auth;
2. crear perfiles y roles;
3. proteger rutas;
4. endurecer RLS;
5. registrar usuario creador/modificador/aprobador;
6. probar recuperación de contraseña;
7. revisar Storage;
8. retirar datos de demostración.

## 7. Web/PWA

### Pruebas funcionales

- abrir inventario;
- crear equipo sin IP;
- crear equipo con IP nueva;
- editar IP;
- retirar IP;
- duplicar placa;
- duplicar serial;
- subir foto;
- exportar Excel;
- generar PDF;
- generar baja;
- generar traslado;
- leer QR desde ficha;
- leer QR desde móvil;
- recibir notificación realtime;
- marcar notificación leída;
- abrir en móvil;
- comprobar navegación inferior.

### Pruebas de error

- Supabase sin variables;
- URL inválida;
- red desconectada;
- cámara denegada;
- cámara ocupada por otra aplicación;
- QR ilegible;
- activo inexistente;
- IP ocupada;
- ventana emergente bloqueada;
- archivo Excel corrupto;
- fotografía demasiado grande.

## 8. Android/Capacitor

### Preparación

- Node LTS;
- Android Studio;
- JDK 17;
- SDK Platform;
- Build-Tools;
- Platform-Tools;
- dispositivo o emulador.

### Secuencia

1. validar web;
2. instalar dependencias Capacitor;
3. definir estrategia de salida web;
4. agregar Android;
5. sincronizar plugins;
6. abrir proyecto Android;
7. declarar cámara;
8. declarar almacenamiento si aplica;
9. ejecutar en emulador;
10. ejecutar en celular;
11. probar offline;
12. crear APK debug;
13. crear AAB firmado para publicación.

### Criterios móviles

- cámara trasera;
- permiso solicitado en primer uso;
- botón flotante no tapa navegación;
- datos legibles en pantalla pequeña;
- fotos comprimidas;
- aplicación no guarda claves privadas;
- el APK usa el mismo Supabase;
- reintento de sincronización al volver la conexión.

## 9. iOS

La misma base puede usarse en iPhone, pero la compilación requiere macOS y Xcode.

Pruebas:

- permiso de cámara;
- navegación segura;
- descarga/impresión;
- fotografías;
- conexión Supabase;
- suspensión y reanudación;
- tamaño de pantalla;
- firma de aplicación.

## 10. Documentación final propuesta

### Documento 1 — Visión general

- propósito;
- alcance;
- usuarios;
- módulos;
- arquitectura;
- limitaciones;
- glosario.

### Documento 2 — Instalación

- requisitos;
- instalación Windows;
- variables de entorno;
- Supabase;
- ejecución local;
- errores frecuentes;
- actualización por Git.

### Documento 3 — Manual administrativo

- inventario;
- equipos;
- IPs;
- impresoras;
- cámaras;
- usuarios;
- configuración;
- notificaciones;
- reportes.

### Documento 4 — Manual técnico

- iniciar vista técnico;
- permitir cámara;
- escanear QR;
- interpretar ficha;
- tomar fotografía;
- revisar IP;
- registrar mantenimiento;
- trabajar offline;
- sincronizar.

### Documento 5 — Bajas

- crear baja;
- campos automáticos;
- valoración técnica;
- factores;
- disposición;
- generar PDF;
- guardar evidencia;
- aprobar;
- reactivar con trazabilidad.

### Documento 6 — Traslados

- seleccionar activo;
- origen/destino;
- motivo;
- estado físico;
- visto bueno;
- firmas;
- generar documento;
- actualizar área;
- revisar historial.

### Documento 7 — QR e impresión

- generación;
- contenido;
- tamaño 46 × 58 mm;
- logo;
- contraste;
- impresora térmica;
- lectura;
- solución de problemas.

### Documento 8 — Seguridad

- Auth;
- roles;
- RLS;
- Storage;
- claves;
- auditoría;
- copias de seguridad;
- incidentes.

### Documento 9 — Pruebas

- matriz de casos;
- datos de prueba;
- resultado esperado;
- evidencia;
- regresión;
- aceptación.

### Documento 10 — Despliegue

- web;
- PWA;
- Android APK;
- Android AAB;
- iOS;
- variables de producción;
- monitoreo;
- recuperación.

## 11. Criterios de aceptación

La versión se considera lista para pruebas piloto cuando:

- type-check no tiene errores;
- build no omite validaciones;
- Supabase responde correctamente;
- QR abre ficha en menos de unos segundos en red normal;
- IP se sincroniza en ambos sentidos;
- baja genera documento y libera IP;
- traslado genera documento y actualiza historial;
- campana recibe y marca alertas;
- cámara funciona con permiso concedido;
- ticket 46 × 58 mm se lee con celular;
- no hay referencia externa de la plataforma de generación;
- se conserva copia de seguridad;
- existe una cuenta administrativa protegida.

## 12. Próxima iteración

1. Ejecutar nuevamente type-check y build tras esta auditoría.
2. Aplicar migración en Supabase correcto.
3. Probar QR con impresora real.
4. Añadir descarga directa desde el listado histórico de bajas/traslados.
5. Añadir editor visual de colores y marca desde Configuración.
6. Completar Auth y RLS.
7. Preparar Android.
8. Probar iOS desde Mac.
