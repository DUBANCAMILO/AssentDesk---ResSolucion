# Referencia Técnica — AssetDesk

## Arquitectura

```
┌─────────────────────────────────────────────────────────┐
│                    Next.js 15 App Router                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐  │
│  │Dashboard │  │ Técnico  │  │  Bajas   │  │Config  │  │
│  │ /page.tsx│  │/tecnico  │  │ /bajas   │  │/config │  │
│  └──────────┘  └──────────┘  └──────────┘  └────────┘  │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │              Shared Components                  │    │
│  │  AppLayout · Sidebar · Topbar · Modal           │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │              Service Layer                      │    │
│  │  assetService.ts (CRUD + History + Metrics)     │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │           Supabase Client Layer                 │    │
│  │  client.ts (browser) · server.ts (SSR)          │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│                    Supabase Backend                     │
│  PostgreSQL · Realtime · Storage · Auth                 │
└─────────────────────────────────────────────────────────┘
```

---

## Módulo QR — Implementación

### Generación (qrcode.react)

```tsx
import { QRCodeSVG } from 'qrcode.react';

<QRCodeSVG
  value={asset.placa || asset.serial || asset.id}
  size={72}          // px
  level="M"          // Error correction: L | M | Q | H
  includeMargin={false}
/>
```

El valor codificado es la **placa de inventario** del activo. Si no tiene placa, usa el serial o el UUID.

### Decodificación Automática (jsQR)

```typescript
// Importación dinámica para evitar errores SSR
const jsQR = (await import('jsqr')).default;

// Captura frame del video
const ctx = canvas.getContext('2d');
ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

// Decodificar
const code = jsQR(imageData.data, imageData.width, imageData.height, {
  inversionAttempts: 'dontInvert',
});

if (code) {
  console.log('QR detectado:', code.data);
}
```

El loop de decodificación corre cada **300ms** usando `setInterval`.

---

## Módulo Realtime — Técnicos en Vivo

### Suscripción a Cambios

```typescript
const supabase = createClient();

const channel = supabase
  .channel('technicians-live')
  .on('postgres_changes', {
    event: '*',           // INSERT | UPDATE | DELETE
    schema: 'public',
    table: 'technicians'
  }, (payload) => {
    // payload.eventType: 'INSERT' | 'UPDATE' | 'DELETE'
    // payload.new: nuevo registro
    // payload.old: registro anterior (solo en UPDATE/DELETE)
  })
  .subscribe((status) => {
    // status: 'SUBSCRIBED' | 'CHANNEL_ERROR' | 'TIMED_OUT'
  });

// Cleanup
return () => { supabase.removeChannel(channel); };
```

### Tabla `technicians`

```sql
CREATE TABLE public.technicians (
  id              uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name            text NOT NULL,
  status          text DEFAULT 'active',  -- active | busy | inactive
  current_location text,
  last_seen       timestamptz DEFAULT now(),
  created_at      timestamptz DEFAULT now()
);
```

---

## Módulo Excel — SheetJS

### Leer archivo .xlsx

```typescript
import * as XLSX from 'xlsx';

const arrayBuffer = await file.arrayBuffer();
const workbook = XLSX.read(arrayBuffer, { type: 'array' });
const sheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[sheetName];
const data = XLSX.utils.sheet_to_json(worksheet, {
  defval: '',   // valor por defecto para celdas vacías
  raw: false,   // convertir todo a string
});
```

### Generar plantilla .xlsx

```typescript
const ws = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
ws['!cols'] = headers.map(() => ({ wch: 22 })); // ancho de columnas
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, 'Inventario');
XLSX.writeFile(wb, 'plantilla.xlsx');
```

---

## Módulo PDF — jsPDF

### Exportar ficha técnica

```typescript
import { jsPDF } from 'jspdf';

const doc = new jsPDF({
  orientation: 'portrait',
  unit: 'mm',
  format: 'a4'
});

// Texto
doc.setFontSize(16);
doc.setFont('helvetica', 'bold');
doc.text('Título', 15, 15);

// Línea divisoria
doc.setDrawColor(200, 200, 200);
doc.line(15, 25, 195, 25);

// Guardar
doc.save('ficha_activo.pdf');
```

---

## Impresión de Ticket 12×30mm

El ticket usa CSS `@page` para forzar el tamaño de página:

```css
@page {
  size: 30mm 12mm;
  margin: 0;
}
html, body {
  width: 30mm;
  height: 12mm;
  overflow: hidden;
}
```

El layout interno usa **flexbox** con dirección row:
- Columna izquierda (10mm): QR renderizado en `<canvas>`
- Columna derecha (18mm): Datos del equipo en fuente monospace 5.5pt

El QR en el ticket se renderiza con JavaScript puro (sin dependencias) usando un algoritmo de hash determinístico para generar el patrón de módulos.

---

## assetService — API Reference

```typescript
// Obtener todos los activos (excluye dados de baja)
assetService.getAll(): Promise<Asset[]>

// Obtener por ID
assetService.getById(id: string): Promise<Asset | null>

// Obtener por placa
assetService.getByPlaca(placa: string): Promise<Asset | null>

// Crear activo (también registra historial y notificación)
assetService.create(asset: Omit<Asset, 'id' | 'created_at' | 'updated_at'>): Promise<Asset | null>

// Actualizar activo
assetService.update(id: string, asset: Partial<Asset>): Promise<Asset | null>

// Dar de baja
assetService.moveToBaja(
  id: string,
  motivo: string,
  observaciones: string,
  tecnico: string,
  disposicion: string
): Promise<boolean>

// Historial de cambios
assetService.getHistory(assetId: string): Promise<AssetHistory[]>

// Subir foto
assetService.uploadPhoto(assetId: string, file: File): Promise<string | null>

// Métricas del dashboard
assetService.getMetrics(): Promise<{ total, operational, critical, maintenance }>
```

---

## Variables de Entorno

| Variable | Descripción | Requerida |
|----------|-------------|-----------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL del proyecto Supabase | ✅ Sí |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Clave anónima de Supabase | ✅ Sí |
| `NEXT_PUBLIC_SITE_URL` | URL pública de la aplicación | ✅ Sí |

---

## Políticas RLS (Row Level Security)

Todas las tablas tienen RLS habilitado con políticas permisivas para uso interno:

```sql
-- Política de lectura pública (ajustar según necesidades de seguridad)
CREATE POLICY "Allow all" ON public.assets
  FOR ALL USING (true) WITH CHECK (true);
```

> ⚠️ Para producción, reemplaza las políticas permisivas con autenticación basada en `auth.uid()`.

---

## Compatibilidad

| Navegador | Escáner QR | Realtime | Excel | PDF |
|-----------|-----------|----------|-------|-----|
| Chrome 90+ | ✅ | ✅ | ✅ | ✅ |
| Firefox 88+ | ✅ | ✅ | ✅ | ✅ |
| Safari 14+ | ⚠️ (HTTPS requerido) | ✅ | ✅ | ✅ |
| Edge 90+ | ✅ | ✅ | ✅ | ✅ |

> El escáner QR requiere HTTPS en producción para acceder a `getUserMedia`.
