# Formularios físicos pendientes de digitalizar

Esta carpeta queda preparada para incorporar los documentos escaneados de:

- acta de baja;
- formato de traslado;
- entrega/recibo de equipo;
- otros formatos físicos de inventario.

## Flujo de implementación

1. Recibir escaneo o fotografía legible.
2. Identificar campos, encabezados, firmas, sellos y numeración.
3. Comparar con las tablas actuales.
4. Diseñar el formulario web/móvil sin duplicar datos del activo.
5. Crear tablas o columnas solo si el formato exige información nueva.
6. Generar PDF con el mismo diseño y tamaño solicitado.
7. Adjuntar el documento al historial del activo.
8. Probar impresión y descarga antes de activar producción.

## Campos previstos para traslado

- número de traslado;
- fecha;
- activo y placa;
- origen;
- destino;
- responsable que entrega;
- responsable que recibe;
- motivo;
- observaciones;
- estado;
- firmas o evidencias;
- historial de ubicaciones.

## Campos previstos para baja

- número de acta;
- fecha;
- activo y snapshot de datos;
- motivo;
- disposición final;
- responsable;
- aprobación;
- observaciones;
- evidencia adjunta;
- firma o constancia.

No se agrega todavía una migración de base de datos porque primero hay que revisar los escaneos y respetar exactamente los campos que usa la organización.
