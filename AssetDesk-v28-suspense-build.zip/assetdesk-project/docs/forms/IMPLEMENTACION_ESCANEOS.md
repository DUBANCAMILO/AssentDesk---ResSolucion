# Digitalización de formularios físicos

## Documento de referencia

Se recibió y archivó:

`docs/forms/references/formularios_baja_traslado_original.pdf`

Contiene dos formatos de la E.S.E. Hospital San Juan de Dios de Floridablanca, Gestión de Recursos Físicos:

1. Formato sugerencia de bajas.
2. Formato traslado interno de bienes.

La implementación conserva los campos administrativos y la intención del formato, pero no reemplaza el documento físico original hasta que el usuario valide el diseño final.

## Formato 1 — Sugerencia de bajas

### Encabezado

- entidad y logotipo;
- nombre: Formato sugerencia de bajas;
- área: Gestión de Recursos Físicos;
- código: F-GRF-ME-07;
- versión: 01;
- fecha de aprobación;
- número de página.

### Identificación

- reporte número;
- fecha;
- nombre del equipo;
- cantidad;
- número de inventario;
- ubicación;
- motivo de baja.

### Valoración técnica

Campo amplio para justificar técnicamente la baja.

### Frecuencia de trabajo

- continuo;
- semanal;
- mensual;
- una vez al día;
- esporádicamente.

### Observaciones

Campo amplio de varias líneas.

### Factores para determinar la baja

- mantenimiento correctivo constante;
- repuestos no comerciales;
- costo de reparación superior al 70% del valor comercial actual;
- ciclo de vida útil cumplido;
- hurto;
- riesgo para el usuario.

### Responsable

- nombre del responsable del análisis técnico;
- firma o evidencia de firma.

## Formato 2 — Traslado interno de bienes

### Encabezado

- entidad y logotipo;
- nombre: Formato traslado interno de bienes;
- área: Gestión de Recursos Físicos;
- fecha;
- número de traslado.

### Traslado

- servicio origen;
- servicio destino;
- motivo del traslado.

### Área que realiza el traslado

- mantenimiento;
- mantenimiento biomédico;
- sistemas;
- subgerencia;
- almacén;
- otro.

### Descripción del bien

- nombre;
- placa de inventario número;
- cantidad;
- marca;
- modelo;
- serial;
- estado: bueno, regular o malo.

### Responsables y aprobación

- visto bueno de subgerencia: sí/no;
- firma o evidencia de firma de subgerencia;
- firma del servicio origen;
- firma del servicio destino.

### Trazabilidad adicional recomendada

Aunque no aparece como campo independiente en el escaneo, el sistema debe conservar:

- activo relacionado;
- ubicación anterior;
- ubicación nueva;
- usuario que registra;
- fecha de creación;
- fecha de aprobación;
- estado del traslado;
- archivo PDF final;
- historial del activo.

## Reglas de implementación

- No duplicar datos del activo si existe `asset_id`.
- Guardar un snapshot de placa, nombre, marca, modelo y serial para conservar la evidencia histórica.
- Un traslado aprobado debe actualizar ubicación/área del activo y registrar un evento `transferred` en el historial.
- Una baja aprobada debe conservar el snapshot del activo y el documento generado.
- Las firmas deben poder guardarse como imagen, trazo o archivo adjunto según la política de la entidad.
- El PDF debe mantener el formato institucional y mostrar el número de documento.
