# AssetDesk — Documentación completa del sistema
## Documento académico, técnico y de preparación para producción

**Proyecto:** AssetDesk — Sistema de Gestión de Activos TI  
**Versión documental:** 1.0  
**Repositorio:** https://github.com/DUBANCAMILO/assetdesk  
**Fecha:** 14 de agosto de 2026  
**Autor:** Duban Camilo Arias Bohórquez  
**Estado:** Base funcional web + preparación de adaptación móvil AssetDesk Field

---

## 1. Resumen ejecutivo

AssetDesk es una plataforma web y móvil para registrar, consultar, mantener, auditar y dar de baja activos tecnológicos. Está orientada a equipos de tecnología, técnicos de campo, supervisores y administradores de inventario.

El sistema centraliza:

- inventario de computadores y equipos;
- impresoras y cámaras/DVR;
- direcciones IP;
- responsables, sedes y áreas;
- mantenimientos preventivos y correctivos;
- tickets y bajas;
- historial de cambios;
- fotografías y códigos QR;
- reportes PDF y hojas Excel;
- notificaciones;
- sincronización en tiempo real;
- consulta desde navegador y móvil.

La solución utiliza una sola base de datos Supabase. El navegador web y AssetDesk Field para Android funcionan como clientes del mismo backend, de forma que la información se mantiene unificada.

---

## 2. Problema que resuelve

En muchas organizaciones el inventario TI se encuentra repartido en hojas de cálculo, documentos, correos y registros manuales. Esto genera:

- equipos sin ubicación actualizada;
- dificultad para saber quién tiene un activo;
- mantenimientos olvidados;
- poca trazabilidad de cambios;
- bajas sin historial suficiente;
- duplicación de información;
- demora en consultar un equipo en campo;
- falta de evidencia fotográfica;
- dificultad para auditar la infraestructura.

AssetDesk propone una fuente única de información, con consulta rápida por QR y continuidad entre oficina y campo.

---

## 3. Justificación académica y empresarial

### 3.1. Justificación académica

El proyecto integra análisis de requisitos, diseño de software, bases de datos, desarrollo web, experiencia móvil, seguridad, pruebas y despliegue. Puede presentarse como un caso aplicado de transformación digital para la gestión de infraestructura TI.

### 3.2. Justificación empresarial

La solución reduce el tiempo de consulta, mejora la trazabilidad y permite priorizar activos críticos y mantenimientos vencidos. También crea una base para auditorías, control de garantías y toma de decisiones.

### 3.3. Beneficiarios

- administradores TI;
- técnicos de soporte;
- responsables de inventario;
- supervisores;
- áreas financieras y de compras;
- auditoría interna;
- usuarios responsables de equipos.

---

## 4. Objetivos

### 4.1. Objetivo general

Desarrollar y documentar una plataforma web y móvil para la gestión centralizada, trazable y segura de activos tecnológicos.

### 4.2. Objetivos específicos

1. Registrar y consultar activos mediante datos tradicionales y códigos QR.
2. Mantener historial de asignaciones, estados, mantenimientos y bajas.
3. Permitir trabajo de técnicos desde dispositivos móviles.
4. Sincronizar la información entre web y móvil mediante un backend único.
5. Generar reportes técnicos y administrativos.
6. Facilitar importación masiva desde Excel y CSV.
7. Notificar cambios y estados críticos.
8. Preparar una arquitectura escalable para producción.

---

## 5. Alcance

### Incluido

- inventario de activos;
- equipos, impresoras y cámaras;
- QR;
- técnicos;
- mantenimientos;
- bajas;
- IPs;
- reportes;
- notificaciones;
- Supabase Auth, Database, Realtime y Storage;
- PWA y preparación Android;
- modo offline inicial para consulta;
- documentación y diagramas.

### Fuera del primer alcance

- gestión financiera completa;
- compras y proveedores como ERP;
- integración automática con Active Directory;
- control remoto de equipos;
- geolocalización obligatoria;
- multicliente avanzado;
- aplicación iOS en la primera versión.

---

## 6. Stakeholders y roles

| Rol | Responsabilidades | Acceso esperado |
|---|---|---|
| Administrador TI | Configurar sistema, gestionar inventario, usuarios y permisos | Completo |
| Técnico de campo | Escanear, consultar, actualizar y reportar | Operativo limitado |
| Supervisor | Revisar indicadores, mantenimientos y reportes | Lectura + aprobación |
| Auditor | Consultar historial y evidencias | Solo lectura |
| Responsable de activo | Consultar información de su equipo | Consulta limitada |
| Supabase | Autenticación, datos, eventos y archivos | Servicio técnico |

---

## 7. Requisitos funcionales

### RF-01 — Autenticación

El sistema debe permitir iniciar y cerrar sesión, mantener sesión activa y restringir módulos según el rol.

### RF-02 — Registro de activos

El administrador debe poder registrar placa, serial, marca, modelo, ubicación, responsable, área, red, garantía, foto y características técnicas.

### RF-03 — Consulta de inventario

El sistema debe permitir buscar por placa, serial, marca, modelo, usuario, área, sede, IP y estado.

### RF-04 — Códigos QR

El sistema debe generar un QR asociado a placa, serial o UUID y permitir leerlo desde la cámara del móvil.

### RF-05 — Ficha técnica

Cada activo debe mostrar identificación, estado, usuario, ubicación, red, componentes, garantía, historial, QR y acciones disponibles.

### RF-06 — Mantenimiento

El sistema debe registrar tipo, descripción, fecha, técnico, estado, prioridad, costo estimado, costo real y observaciones.

### RF-07 — Bajas

El sistema debe registrar motivo, disposición, responsable, observaciones, acta y fotografía/evidencia cuando corresponda.

### RF-08 — Historial

Toda modificación importante debe registrar fecha, activo, evento, descripción y usuario o técnico responsable.

### RF-09 — Importación masiva

El sistema debe leer Excel y CSV, validar filas, mostrar errores y permitir confirmar la importación.

### RF-10 — Exportación

El sistema debe generar reportes PDF, fichas técnicas y archivos Excel/CSV.

### RF-11 — Notificaciones

El sistema debe notificar activos críticos, mantenimientos próximos, nuevas altas, bajas y cambios relevantes.

### RF-12 — Tiempo real

Los clientes deben recibir cambios de técnicos, notificaciones, activos y mantenimientos cuando la conexión esté disponible.

### RF-13 — Trabajo móvil

AssetDesk Field debe permitir consultar activos, escanear QR, ver fichas, tomar fotos y reportar mantenimiento desde un teléfono.

### RF-14 — Trabajo sin conexión

El móvil debe permitir consultar datos previamente sincronizados y guardar operaciones pendientes para enviarlas al recuperar conexión.

---

## 8. Requisitos no funcionales

| Código | Requisito |
|---|---|
| RNF-01 | Interfaz responsive en móvil, tableta y escritorio. |
| RNF-02 | La consulta QR debe responder con rapidez en condiciones normales. |
| RNF-03 | Las operaciones críticas deben mostrar confirmación y resultado. |
| RNF-04 | Las contraseñas y sesiones deben gestionarse mediante Supabase Auth. |
| RNF-05 | Las claves privadas nunca deben estar en el cliente. |
| RNF-06 | El sistema debe registrar errores y eventos importantes. |
| RNF-07 | Los módulos deben ser mantenibles y reutilizar la capa de servicios. |
| RNF-08 | El sistema debe soportar pérdida temporal de internet en campo. |
| RNF-09 | El diseño debe cumplir contraste y legibilidad básicos. |
| RNF-10 | Las migraciones deben ser repetibles y documentadas. |
| RNF-11 | Los respaldos de base y Storage deben formar parte de producción. |
| RNF-12 | La plataforma debe poder desplegarse mediante CI/CD. |

---

## 9. Casos de uso

[[DIAGRAMA_CASOS_USO]]

### CU-01 — Autenticar usuario

**Actor:** administrador, técnico, supervisor.  
**Precondición:** usuario registrado.  
**Flujo principal:** ingresar credenciales → validar en Supabase Auth → crear sesión → mostrar módulo autorizado.  
**Alternos:** contraseña incorrecta, sesión vencida, usuario desactivado.  
**Resultado:** sesión segura y rol disponible.

### CU-02 — Consultar activo por QR

**Actor:** técnico.  
**Precondición:** cámara autorizada y QR registrado.  
**Flujo:** abrir vista de técnico → activar cámara → decodificar QR → buscar placa/serial/UUID → mostrar ficha.  
**Alternos:** QR ilegible, activo inexistente, cámara denegada, modo offline.  
**Resultado:** ficha mostrada o mensaje accionable.

### CU-03 — Registrar activo

**Actor:** administrador.  
**Flujo:** abrir registro → diligenciar datos → validar placa/serial → subir foto opcional → guardar → registrar historial → notificar.  
**Resultado:** activo creado.

### CU-04 — Actualizar activo

**Actor:** administrador o técnico autorizado.  
**Flujo:** abrir ficha → editar campos autorizados → validar → guardar → registrar historial → notificar si aplica.  
**Resultado:** información actualizada en web y móvil.

### CU-05 — Programar mantenimiento

**Actor:** administrador o supervisor.  
**Flujo:** seleccionar activo → crear mantenimiento → elegir fecha, tipo, prioridad y técnico → guardar → programar alerta.  
**Resultado:** mantenimiento visible en ambos clientes.

### CU-06 — Reportar mantenimiento desde móvil

**Actor:** técnico.  
**Flujo:** escanear activo → seleccionar problema → escribir observación → tomar foto → guardar conectado o en cola offline.  
**Resultado:** registro creado o pendiente de sincronización.

### CU-07 — Dar de baja

**Actor:** administrador o supervisor autorizado.  
**Flujo:** seleccionar activo → indicar motivo → registrar disposición → confirmar → mover a historial de bajas.  
**Resultado:** activo excluido del inventario operativo y conservado en auditoría.

### CU-08 — Importar inventario

**Actor:** administrador.  
**Flujo:** descargar plantilla → cargar Excel/CSV → validar filas → corregir errores → confirmar → crear registros e historial.  
**Resultado:** activos importados sin duplicados críticos.

### CU-09 — Generar reporte

**Actor:** administrador, supervisor o auditor.  
**Flujo:** seleccionar filtros → generar vista → exportar PDF o Excel.  
**Resultado:** archivo descargable y trazable.

### CU-10 — Consultar historial

**Actor:** supervisor o auditor.  
**Flujo:** abrir activo → abrir historial → filtrar eventos → consultar usuario, fecha y descripción.  
**Resultado:** trazabilidad disponible.

---

## 10. Arquitectura del sistema

[[DIAGRAMA_ARQUITECTURA]]

### Capas

1. **Presentación:** Next.js App Router, React, Tailwind y componentes reutilizables.
2. **Aplicación:** páginas, formularios, validación, navegación y estado visual.
3. **Servicios:** `assetService`, `maintenanceService`, `notificationService`, `ipService` y servicios relacionados.
4. **Persistencia:** Supabase Browser Client, Auth, PostgreSQL, Realtime y Storage.
5. **Distribución:** navegador web, PWA y futuro contenedor Android con Capacitor.

### Regla de arquitectura

Web y móvil comparten el código de negocio y el backend. La diferencia principal está en navegación, permisos de cámara, almacenamiento local y empaquetado.

---

## 11. Modelo de datos

[[DIAGRAMA_ERD]]

### Entidades principales

- `assets`: activo principal.
- `technicians`: técnicos.
- `asset_history`: eventos y trazabilidad.
- `bajas`: activos retirados y disposición.
- `maintenance_schedules`: mantenimientos.
- `notifications`: alertas.
- `ip_addresses`: inventario de red.
- `printers`: impresoras.
- `cameras`: cámaras y DVR.
- `equipment_groups`: agrupación y analítica.
- `app_settings`: configuración.
- Storage `asset-photos`: fotografías.

### Relaciones

- Un activo puede tener muchos eventos de historial.
- Un activo puede tener muchos mantenimientos.
- Un activo puede tener una baja.
- Un activo puede relacionarse con una IP.
- Un activo puede generar notificaciones.
- Un técnico puede estar asociado a mantenimientos y eventos.

---

## 12. Secuencia del escaneo QR

[[DIAGRAMA_SECUENCIA_QR]]

1. El técnico solicita permiso de cámara.
2. El navegador o APK captura un frame.
3. `jsQR` decodifica el contenido.
4. Se obtiene placa, serial o UUID.
5. `assetService` consulta Supabase.
6. La interfaz muestra la ficha.
7. El técnico consulta, comparte o reporta.
8. Si no hay conexión, se usa caché y se registra una operación pendiente cuando corresponda.

---

## 13. Arquitectura web y Android

### Web

- despliegue Next.js;
- navegación administrativa completa;
- reportes y gestión avanzada;
- acceso desde navegador.

### Móvil

- vista AssetDesk Field;
- navegación inferior;
- escaneo QR;
- cámara y fotos;
- consulta rápida;
- mantenimiento en campo;
- PWA y futuro APK.

### Backend común

```text
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
```

Ambos clientes deben apuntar al mismo proyecto. No se debe guardar una copia separada de la base dentro del APK.

---

## 14. Seguridad

### Situación actual

El proyecto usa Supabase Auth y RLS, pero las migraciones históricas contienen políticas abiertas que deben endurecerse antes de producción.

### Recomendaciones

- exigir autenticación;
- crear roles `admin`, `supervisor`, `tecnico` y `auditor`;
- limitar escritura según rol;
- separar sedes cuando aplique;
- impedir bajas sin autorización;
- proteger Storage;
- validar archivos y tamaño de imágenes;
- no exponer `service_role`;
- rotar credenciales si alguna clave real fue publicada;
- registrar auditoría de cambios;
- usar HTTPS;
- activar respaldos;
- revisar políticas con datos reales.

### Matriz de acceso sugerida

| Módulo | Admin | Supervisor | Técnico | Auditor |
|---|---:|---:|---:|---:|
| Ver activos | Sí | Sí | Sí | Sí |
| Crear activos | Sí | Opcional | No/limitado | No |
| Editar activos | Sí | Limitado | Campos de campo | No |
| Dar de baja | Sí | Aprobar | Solicitar | No |
| Mantenimiento | Sí | Sí | Crear/actualizar asignado | Ver |
| Configuración | Sí | No | No | No |
| Reportes | Sí | Sí | Limitado | Sí |
| Usuarios/roles | Sí | No | No | No |

---

## 15. Modo offline y sincronización

### Consulta offline

El móvil puede conservar activos prioritarios para consulta sin internet.

### Escrituras offline

Para una versión de producción se recomienda IndexedDB con una cola:

```text
Operación local
  ↓
Cola pendiente
  ↓ conexión restaurada
Validar versión y permisos
  ↓
Enviar a Supabase
  ↓
Confirmar / resolver conflicto
  ↓
Actualizar caché
```

Cada operación debe contener tipo, tabla, payload, fecha, usuario, intentos y error.

### Conflictos

Si web y móvil editan el mismo activo, el sistema debe mostrar la fecha de última actualización y permitir conservar la versión más reciente o revisar manualmente.

---

## 16. Pruebas

### Pruebas unitarias

- validación de placa;
- validación de estados;
- cálculo de fechas de mantenimiento;
- filtros;
- transformación de Excel;
- generación de QR;
- generación de PDF;
- cola offline.

### Pruebas de integración

- navegador → Supabase;
- móvil → Supabase;
- Auth → permisos;
- QR → ficha;
- registro → historial;
- baja → exclusión del inventario;
- mantenimiento → notificación;
- Storage → foto.

### Pruebas de aceptación

1. El administrador registra un equipo.
2. El técnico lo encuentra por QR.
3. El técnico reporta mantenimiento.
4. El supervisor ve la novedad desde web.
5. El administrador genera un reporte.
6. Se registra todo en historial.

### Pruebas de producción

- teléfono Android pequeño;
- tableta;
- navegador de escritorio;
- conexión lenta;
- sin conexión;
- cámara sin permiso;
- sesión vencida;
- archivo Excel inválido;
- PDF sin datos;
- usuario sin permisos.

---

## 17. Despliegue

### Entorno de desarrollo

- Node.js;
- npm;
- variables `.env.local`;
- proyecto Supabase de desarrollo;
- navegador con HTTPS local o entorno seguro para cámara.

### Entorno de pruebas

- despliegue web separado;
- base Supabase de staging;
- datos ficticios;
- APK de prueba;
- usuarios de prueba por rol.

### Producción web

1. configurar variables del proyecto;
2. ejecutar migraciones aprobadas;
3. crear buckets y políticas;
4. crear usuarios y roles;
5. ejecutar build;
6. desplegar;
7. probar QR y Realtime;
8. activar monitoreo y respaldo.

### Producción Android

1. instalar Capacitor;
2. crear plataforma Android;
3. configurar permisos;
4. definir icono y nombre;
5. compilar APK de prueba;
6. probar en dispositivos;
7. firmar versión de distribución;
8. generar AAB para Play Store.

---

## 18. Gestión del proyecto

### Fase 1 — Base funcional

- inventario;
- QR;
- ficha;
- Supabase;
- técnicos;
- mantenimientos;
- reportes.

### Fase 2 — Mobile Field

- navegación móvil;
- cámara;
- fotos;
- modo offline de consulta;
- APK;
- pruebas móviles.

### Fase 3 — Seguridad y producción

- roles;
- RLS;
- backups;
- observabilidad;
- CI/CD;
- auditoría.

### Fase 4 — Escalabilidad

- IndexedDB completo;
- conflictos;
- notificaciones push;
- impresión móvil;
- integración con directorio;
- analítica avanzada.

---

## 19. Riesgos y mitigaciones

| Riesgo | Impacto | Mitigación |
|---|---|---|
| Políticas RLS abiertas | Alto | Rediseñar permisos antes de producción. |
| Pérdida de conexión | Alto | Caché, cola y sincronización. |
| Cambios simultáneos | Medio | Versionado y resolución de conflictos. |
| Cámara no disponible | Medio | Búsqueda manual y lector externo. |
| Datos duplicados | Alto | Placa/serial únicos y validación. |
| Fotos pesadas | Medio | Compresión y límites. |
| Migraciones mezcladas | Alto | Elegir una base inicial y documentar orden. |
| Cambios sin pruebas | Alto | Staging, checklist y Pull Request. |

---

## 20. Trazabilidad

| Requisito | Caso de uso | Módulo | Prueba |
|---|---|---|---|
| RF-02 | CU-03 | Inventario | Alta de activo |
| RF-04 | CU-02 | Técnico | QR válido/ inválido |
| RF-06 | CU-05/06 | Mantenimiento | Crear y completar |
| RF-07 | CU-07 | Bajas | Confirmar baja |
| RF-08 | CU-10 | Historial | Consultar evento |
| RF-09 | CU-08 | Importación | Excel con errores |
| RF-10 | CU-09 | Reportes | PDF y Excel |
| RF-12 | CU-04/05 | Realtime | Cambio cruzado web/móvil |
| RF-14 | CU-06 | Offline | Cola y sincronización |

---

## 21. Manual de operación resumido

### Administrador

1. Iniciar sesión.
2. Revisar métricas.
3. Registrar o importar activos.
4. Revisar críticos.
5. Programar mantenimientos.
6. Generar reportes.
7. Auditar bajas e historial.

### Técnico

1. Abrir AssetDesk Field.
2. Escanear QR.
3. Consultar ficha.
4. Revisar estado y ubicación.
5. Reportar novedad.
6. Tomar foto.
7. Sincronizar cuando haya conexión.

### Supervisor

1. Consultar críticos y vencidos.
2. Revisar mantenimientos.
3. Aprobar bajas.
4. Ver reportes.
5. Revisar trazabilidad.

---

## 22. Entregables para universidad

- documento de planteamiento del problema;
- justificación;
- objetivos;
- alcance;
- antecedentes;
- marco conceptual;
- metodología;
- requisitos;
- casos de uso;
- UML;
- arquitectura;
- modelo de datos;
- prototipo;
- pruebas;
- resultados;
- conclusiones;
- trabajo futuro;
- referencias;
- anexos y manual de usuario.

## 23. Entregables para producción

- repositorio versionado;
- README;
- variables de entorno documentadas;
- migraciones;
- políticas RLS;
- control de roles;
- pruebas;
- checklist de despliegue;
- plan de backups;
- monitoreo;
- manual operativo;
- plan de recuperación;
- changelog;
- licencia y atribuciones.

---

## 24. Conclusiones

AssetDesk tiene una base funcional suficiente para presentarse como proyecto académico aplicado y para evolucionar hacia producción. La decisión más importante es mantener una sola fuente de datos: Supabase como backend compartido por web y móvil.

La siguiente etapa técnica es instalar Capacitor, generar Android, configurar permisos y ejecutar pruebas. Antes de producción se deben endurecer RLS, implementar cola offline completa y formalizar roles.

---

## 25. Glosario

- **Activo:** equipo tecnológico registrado.
- **QR:** código de identificación rápida.
- **RLS:** Row Level Security, seguridad por fila en PostgreSQL.
- **Realtime:** eventos enviados en tiempo real a los clientes.
- **PWA:** aplicación web instalable.
- **APK:** paquete instalable de Android.
- **AAB:** formato de distribución para Google Play.
- **Supabase:** plataforma de autenticación, base de datos, archivos y eventos.
- **CRUD:** crear, consultar, actualizar y eliminar.
- **Staging:** entorno de pruebas antes de producción.
