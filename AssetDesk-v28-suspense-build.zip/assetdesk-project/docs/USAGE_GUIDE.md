# Guía de Uso — AssetDesk

## 1. Dashboard Principal

Al ingresar verás el panel principal con:
- **Métricas Bento**: Total de activos, operativos, críticos y en mantenimiento
- **Tabla de Inventario**: Lista completa con filtros por estado, área y sede
- **Gráfica de Tendencias**: Evolución del inventario en el tiempo

### Registrar un Nuevo Equipo
1. Haz clic en **"+ Registrar Equipo"** (botón verde en la barra superior)
2. Completa los campos requeridos: Placa, Serial, Marca, Modelo
3. Opcionalmente agrega: Foto (cámara o upload), GPU, Software, Garantía
4. Haz clic en **"Guardar"**

### Dar de Baja un Equipo
1. En la tabla, haz clic en el ícono de archivo (🗄️) en la fila del equipo
2. Selecciona el motivo de baja y disposición final
3. Agrega observaciones y el técnico responsable
4. Confirma con **"Dar de Baja"**

---

## 2. Vista Técnico de Campo (`/tecnico`)

Optimizada para dispositivos móviles en modo retrato.

### Escaneo QR Automático
1. Haz clic en **"Activar Escáner QR"**
2. Apunta la cámara al código QR del equipo
3. La decodificación es **automática** (jsQR procesa cada frame)
4. Al detectar el QR, busca el equipo en la base de datos automáticamente
5. Si se encuentra, muestra la tarjeta de detalle completa

### Búsqueda Manual
1. Escribe la placa del equipo en el campo de búsqueda
2. Presiona **Enter** o haz clic en **"Buscar"**

### Sincronización de Técnicos en Vivo
- El panel **"Técnicos en Campo"** muestra todos los técnicos registrados
- El indicador **"EN VIVO"** (verde parpadeante) confirma la conexión Realtime
- Los cambios de estado/ubicación se reflejan instantáneamente sin recargar

---

## 3. Ficha Técnica y Tickets de Impresión

### Abrir la Ficha Técnica
1. En la tabla de inventario, haz clic en el ícono QR (📱) de cualquier equipo
2. Se abre el modal con 4 pestañas: Especificaciones, Asignación, Red, Historial

### Imprimir Ticket 12×30mm (Una Sola Hoja)
1. Haz clic en el ícono de impresora (🖨️) en el encabezado de la ficha
2. O usa el botón **"Ticket 12×30mm"** en el pie del modal
3. Se abre una ventana de impresión configurada para papel 30mm × 12mm
4. El ticket incluye: Marca/Modelo, Placa, S/N, IP, Usuario, Ubicación y QR
5. **Todo cabe en una sola hoja** gracias a `@page { size: 30mm 12mm; margin: 0; }`

> ⚠️ **Configuración de impresora**: Asegúrate de seleccionar el tamaño de papel correcto (30×12mm) en el diálogo de impresión. En impresoras térmicas Zebra/Dymo, configura la etiqueta correspondiente.

### Imprimir Ficha Completa (A4)
1. Haz clic en **"Imprimir Ficha"** en el pie del modal
2. Se abre una ventana con la ficha técnica completa en formato A4
3. Incluye todas las especificaciones, asignación, red y un QR

### Exportar PDF
1. Haz clic en **"Exportar PDF"** (botón azul)
2. Se descarga automáticamente `ficha_[PLACA].pdf`
3. El PDF incluye todas las secciones en formato profesional

---

## 4. Importación Masiva de Equipos

### Desde Excel (.xlsx)
1. Ve al Dashboard → botón **"Importar"** (ícono de tabla)
2. Haz clic en **"Descargar Plantilla Excel (.xlsx)"**
3. Completa la plantilla con los datos de tus equipos
4. Arrastra el archivo `.xlsx` al área de carga o haz clic para seleccionar
5. Revisa la vista previa con el estado de cada fila (✅ válido, ⚠️ advertencia, ❌ error)
6. Opcionalmente filtra por área antes de importar
7. Haz clic en **"Importar N equipos"**

### Desde CSV
El proceso es idéntico, pero selecciona un archivo `.csv`.

### Columnas Obligatorias
- **Placa de Inventario** (o Serial Pc como alternativa)

### Columnas Recomendadas
- Marca, Modelo, Sistema Operativo, Usuario responsable, Área, Dirección IP

---

## 5. Gestión de IPs (`/ip-management`)

- **Agregar IP**: Formulario con IP, hostname, área y descripción
- **Eliminar IP**: Botón de eliminación con confirmación
- **Realtime**: Los cambios se sincronizan en tiempo real entre usuarios

---

## 6. Notificaciones (`/notificaciones`)

- Las notificaciones se generan automáticamente al:
  - Registrar un nuevo equipo
  - Cambiar estado a crítico
  - Dar de baja un equipo
  - Reactivar un equipo
- **Marcar como leída**: Clic en la notificación individual
- **Marcar todas**: Botón en la barra superior
- El contador en el sidebar se actualiza cada 30 segundos

---

## 7. Configuración (`/configuracion`)

Parámetros disponibles:
- **Organización**: Nombre, sede principal, responsable TI
- **Red**: Rango de IPs, gateway, DNS
- **Notificaciones**: Alertas de vencimiento de garantía, equipos críticos
- **Inventario**: Campos obligatorios, categorías personalizadas

Cada parámetro se guarda individualmente con el botón **"Guardar"** de su fila.

---

## Atajos de Teclado

| Acción | Atajo |
|--------|-------|
| Buscar en tabla | `Ctrl + F` |
| Nuevo equipo | `Ctrl + N` |
| Cerrar modal | `Escape` |
| Buscar por placa (técnico) | `Enter` en el campo de búsqueda |
