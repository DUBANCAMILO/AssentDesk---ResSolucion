# Recomendación de login y seguridad

## Recomendación

Sí es viable y recomendable usar login antes de conectar AssetDesk con datos reales de una institución. No conviene manejar contraseñas dentro del código ni usar un usuario único compartido.

## Diseño sugerido

- Supabase Auth con correo y contraseña.
- Recuperación de contraseña por correo.
- Roles: administrador, técnico, consulta y aprobador.
- Registro de `created_by`, `updated_by`, `approved_by`.
- RLS por usuario y rol.
- Cámara autorizada solo para el módulo técnico.
- Sin `service_role` en navegador ni APK.
- Variables públicas limitadas a URL y anon key.

## Estado actual

Existe un `AuthContext` inicial con registro, inicio de sesión y cierre de sesión, pero todavía falta conectarlo al layout, crear la pantalla de login y proteger las rutas. Las políticas actuales del esquema son abiertas para pruebas y deben cerrarse antes de producción.

## Orden recomendado

1. Confirmar el proyecto Supabase real.
2. Crear perfiles y roles.
3. Activar login.
4. Proteger rutas web y módulo técnico.
5. Ajustar RLS.
6. Probar web y Android con usuarios de cada rol.
7. Recién después generar APK/AAB de producción.
