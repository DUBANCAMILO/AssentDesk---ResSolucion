# AssetDesk — resumen diferenciado de mejoras

## 1. Formularios automáticos

### Baja

Al elegir **Dar de Baja** desde un activo, AssetDesk:

1. toma automáticamente marca, modelo, serial, placa, cantidad, ubicación, área y responsable;
2. genera un número de documento de baja;
3. guarda la información en `bajas`;
4. cambia el activo a `decommissioned`;
5. libera la IP asociada;
6. registra el evento en el historial;
7. abre el formato listo para imprimir o guardar como PDF.

El formulario permite completar valoración técnica, frecuencia de trabajo y factores institucionales.

### Traslado

El nuevo módulo **Traslados Internos** permite seleccionar un activo existente y autocompletar sus datos. Al guardar:

1. genera número de traslado;
2. llena el formato institucional;
3. registra origen, destino, motivo, área, estado y visto bueno;
4. actualiza el área del activo;
5. registra el evento `transferred` en el historial;
6. abre el documento para imprimir o guardar como PDF.

## 2. Gestión automática de IP

La sincronización ahora se centraliza en `assetService`:

- crear equipo con IP → crea o actualiza el registro de IP como **ocupada**;
- vincula la IP mediante `asset_id`;
- copia nombre, área, tipo, MAC, gateway, DNS y puerto;
- cambiar IP del equipo → libera la anterior y ocupa la nueva;
- borrar IP desde Gestión de Red → limpia la IP del equipo;
- marcar IP como disponible → limpia la IP del activo vinculado;
- dar de baja un equipo → libera su IP automáticamente;
- una IP ocupada por otro activo no se reemplaza silenciosamente.

La pantalla de Gestión de Red ya muestra métricas y filtros de IPs ocupadas, disponibles y reservadas. Las IPs disponibles son las registradas con estado `disponible`; las direcciones que nunca se hayan creado no aparecen todavía como filas individuales.

## 3. QR e impresión

- Los QR de activos codifican la URL completa de la ficha.
- El escáner móvil busca URL, placa, serial, ID o etiqueta.
- El ticket térmico está configurado a **48 × 56 mm**.
- El QR ocupa 26 mm para favorecer la lectura.
- Se muestran placa, serial, IP, responsable y ubicación.

La imagen `diagrams/assetdesk_ticket_qr_48x56_preview.png` es una vista de referencia. El QR que genera la aplicación sí se produce mediante la librería QR del proyecto.

## 4. Cámara del técnico

Se corrigió un error importante: el video se intentaba conectar antes de que el elemento `<video>` existiera en pantalla. Ahora:

- se solicita la cámara al pulsar **Activar Escáner QR**;
- el navegador o Android muestra la solicitud de permiso;
- el stream se conecta después de renderizar el video;
- jsQR se carga una sola vez por sesión de escaneo;
- se muestran mensajes claros si el permiso está bloqueado;
- se detienen correctamente cámara y pistas al salir.

En web se requiere HTTPS o localhost. En Android se debe declarar y aceptar el permiso de cámara.

## 5. Seguridad y login recomendado

Para pruebas internas puede funcionar sin login, pero para datos reales de una institución se recomienda activarlo antes de publicar:

- Supabase Auth con correo y contraseña;
- roles: administrador, técnico, consulta y aprobación;
- RLS por usuario/rol;
- registro de quién crea, modifica, baja o traslada;
- recuperación de contraseña;
- sin claves privadas dentro del APK.

El proyecto ya contiene un `AuthContext` inicial, pero todavía no está conectado al layout ni protege las rutas. Esa es una mejora de seguridad pendiente y debe hacerse junto con el endurecimiento de RLS.

## Imágenes nuevas

- `assetdesk_ip_sync_flow.png`: flujo de sincronización de IP.
- `assetdesk_auto_documents_flow.png`: flujo de documentos automáticos.
- `assetdesk_ticket_qr_48x56_preview.png`: vista del ticket térmico.
- `assetdesk_qr_camera_flow.png`: flujo de permisos y escaneo en técnico.
