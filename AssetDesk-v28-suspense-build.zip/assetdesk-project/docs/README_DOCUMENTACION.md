# Documentación de AssetDesk

## Actualización más reciente

Consulta `MEJORAS_V1_3.md` para el resumen diferenciado de formularios automáticos, sincronización de IP, QR, impresión térmica, cámara del técnico y recomendación de seguridad.

Consulta `AUDITORIA_COMPLETA_WEB_ANDROID.md` para la auditoría web/Android/iOS, el plan de estabilidad, manejo de excepciones, seguridad, pruebas y documentación final.

## Documento principal

- `DOCUMENTACION_COMPLETA.md`: documentación académica, técnica y de producción.
- `TECHNICAL_REFERENCE.md`: referencia técnica de módulos existentes.
- `USAGE_GUIDE.md`: guía de uso.
- `MOBILE_PATCH.md`: preparación móvil.
- `DATA_CONNECTION.md`: conexión web, móvil y Supabase.

## Diagramas

La carpeta `diagrams/` contiene casos de uso, arquitectura, modelo de datos y secuencia de escaneo QR.

## Uso académico

El documento principal cubre problema, justificación, objetivos, alcance, requisitos, actores, casos de uso, UML, arquitectura, base de datos, pruebas, riesgos, despliegue, conclusiones y trabajo futuro.

## Uso de producción

Antes de publicar se deben revisar RLS, roles, variables de entorno, respaldos, monitoreo, migraciones y pruebas de seguridad.
- `ADAPTABILIDAD.md`: mejoras responsive web/móvil y prioridades.
